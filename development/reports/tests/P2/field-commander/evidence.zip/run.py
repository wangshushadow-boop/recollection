"""Reproduce the river UI desktop acceptance run with an isolated Windows profile."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess


def main():
    here = Path(__file__).resolve().parent
    p = argparse.ArgumentParser()
    p.add_argument("project", type=Path)
    p.add_argument("label")
    p.add_argument("--native", action="store_true")
    args = p.parse_args()
    project = args.project.resolve()
    out = here / args.label
    profile = out / "profile"
    profile.mkdir(exist_ok=True, parents=True)
    env = dict(os.environ, APPDATA=str(profile), LOCALAPPDATA=str(profile), RIVER_UI_OUT=str(out),
               RIVER_NATIVE=str(int(args.native)), RECOLLECTION_MOVE_WORKERS="1")
    engine = Path("D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe")
    cmd = [str(engine), "--path", str(project), "--resolution", "960x600", "--log-file", str(out/"engine.log"),
           "--script", str(here/("stand.gd" if args.label.startswith("stand") else "contact.gd" if args.label.startswith("contact") else "desktop.gd")), "--", "--profile=client"]
    run = subprocess.run(cmd, cwd=out, env=env, capture_output=True, timeout=320)
    log = run.stdout + run.stderr
    (out/"console.log").write_bytes(log)
    data = json.loads((out/"result.json").read_text(encoding="utf-8")) if (out/"result.json").exists() else {}
    errors = [line for line in log.decode("utf-8", "replace").splitlines() if line.startswith(("ERROR:", "SCRIPT ERROR:", "FAIL ")) or (line.startswith("P1_BOOT ") and json.loads(line[8:]).get("event") == "failed")]
    files = ["project.godot", "bootstrap/field_setup.gd", "bootstrap/field_desktop.gd", "presentation/ui/field_battle_overlay.gd", "presentation/ui/ports/field_hud.gd", "presentation/input/ports/field_input.gd", "mission/runtime/field_mission.gd", "mission/runtime/field_brains.gd", "mission/runtime/field_pipeline.gd", "mission/ai/individual/ports/field_individual.gd", "infrastructure/engine/queries.gd"]
    data.update(exit_code=run.returncode, command=cmd, errors=errors,
                sha256={f:hashlib.sha256((project/f).read_bytes()).hexdigest() for f in files})
    (out/"evidence.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(args.label,run.returncode,len(data.get("checks",[])),data.get("passed"),errors)
    return int(not data.get("passed") or run.returncode!=0 or bool(errors))

if __name__ == "__main__":
    raise SystemExit(main())


