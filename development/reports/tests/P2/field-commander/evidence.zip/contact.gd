extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func sample(tag: String):
	var gstates: Array = []
	for g: Dictionary in scene._hud_state.formations:
		var active: Variant = g.get("active")
		gstates.append({"id":g.id,"order":active.order_type if active is Dictionary else "", "queued":g.get("queued")})
	var sides := {}
	for actor: Dictionary in scene._visual_state.get("actors",[]):
		if actor.role=="mount":continue
		var k := str(actor.team)
		if not sides.has(k): sides[k]={"mean_x":0.,"n":0,"physical_x_min":INF,"physical_x_max":-INF,"hp_min":INF,"wounded":0,"phases":{}}
		var s:Dictionary=sides[k]
		var p:Vector3=actor.position
		s.mean_x+=p.x;s.n+=1
		s.physical_x_min=minf(s.physical_x_min,p.x);s.physical_x_max=maxf(s.physical_x_max,p.x)
		s.hp_min=minf(s.hp_min,actor.hp)
		if actor.hp<100:s.wounded+=1
		s.phases[actor.phase]=s.phases.get(actor.phase,0)+1
	for s:Dictionary in sides.values():s.mean_x/=s.n
	var local:Dictionary=scene._input_port.view()
	var notice:String=scene._hud._overlay.notice.text
	var row:Dictionary={"tick":main._last_tick,"sides":sides,"formations":gstates,"notice":notice,"mode":local.mode,"selection":local.selection.duplicate(),"page":local.command_page,"feedback":local.feedback.duplicate(true)}
	metrics[tag]=row
	print("SAMPLE ",tag," ",JSON.stringify(row))
	return row

func gear_tests():
	pass

func nearest_visual() -> Dictionary:
	var player:Dictionary=scene._hud_state
	var own:Vector3=player.position
	var nearest:Dictionary={}
	var distance:=INF
	for actor:Dictionary in scene._visual_state.actors:
		if actor.team==player.player.team or actor.role=="mount" or actor.hp<=0:continue
		var dist:=own.distance_to(actor.position)
		if dist<distance:
			distance=dist
			nearest=actor
	return {"actor":nearest,"distance":distance}

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(await click(main._desktop._buttons.field),"enter field via main menu"):return
	scene=main._field_scene
	if not verify(await click(find_node("Deploy")),"start field via deployment button"):return
	for i in 180:
		await process_frame
		if scene.running and main._last_tick>8:break
	if not verify(scene.running and main._last_tick>8,"live desktop session"):return
	sample("initial")
	var phase:=0
	var moving:=false
	var nearest_dist:=INF
	var first_contact:=0
	var start_hp:int=scene._hud_state.player.hp
	var then:=Time.get_ticks_msec()
	while scene.running and main._last_tick<3700 and Time.get_ticks_msec()-then<200000:
		await process_frame
		var read:Dictionary=scene._hud_state
		if read.player.hp<start_hp: break
		var own:Vector3=read.position
		var nearest:=nearest_visual()
		if nearest.actor.is_empty():break
		nearest_dist=minf(nearest_dist,nearest.distance)
		var dest:Vector3=nearest.actor.position
		if phase==0 and own.z<=-24.0: phase=1
		if phase==1 and own.x>=30.:phase=2
		if phase==0:dest=Vector3(own.x,0,-26)
		elif phase==1:dest=Vector3(34,0,-25)
		var delta:=dest-own
		var desired_yaw:=atan2(-delta.x,-delta.z)
		var current:Vector2=scene._input_port.view().preview_aim
		var pixels:=wrapf(current.x-desired_yaw,-PI,PI)/.0025
		if absf(pixels)>.05:move_mouse(root.get_visible_rect().get_center(),Vector2(pixels,0))
		var walk:bool=phase<2 or nearest.distance>1.12
		if walk!=moving: key(KEY_W,walk)
		moving=walk
		if nearest.distance<=1.45 and first_contact==0:
			first_contact=main._last_tick
			metrics["at_contact"]={"distance":nearest.distance,"tick":main._last_tick,"point":str(own),"nearest":nearest.actor.handle,"phase":nearest.actor.phase}
		if first_contact>0 and main._last_tick-first_contact>250:break
	key(KEY_W,false)
	sample("end")
	var read:Dictionary=scene._hud_state
	metrics["no_order_damage"]={"hp":read.player.hp,"start_hp":start_hp,"tick":main._last_tick,"distance":nearest_dist,"at":str(read.position),"route_phase":phase}
	verify(read.player.hp<start_hp,"enemy damaged approaching player without player attack or order",metrics.no_order_damage)
	await snapshot("contact")

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("KIT_CHARGE_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

