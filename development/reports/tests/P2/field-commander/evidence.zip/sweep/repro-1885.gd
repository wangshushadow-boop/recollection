extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func sample(tag: String):
	var gstates: Array = []
	for g: Dictionary in scene._hud_state.formations:
		var active: Variant = g.get("active")
		gstates.append({"id":g.id,"order":active.order_type if active is Dictionary else "", "queued":g.get("queued")})
	var sides := {}
	for actor: Dictionary in scene._visual_state.get("actors",[]):
		if actor.role=="mount":continue
		var k := str(actor.team)
		if not sides.has(k): sides[k]={"mean_x":0.,"n":0,"physical_x_min":INF,"physical_x_max":-INF,"hp_min":INF,"wounded":0,"phases":{}}
		var s:Dictionary=sides[k]
		var p:Vector3=actor.position
		s.mean_x+=p.x;s.n+=1
		s.physical_x_min=minf(s.physical_x_min,p.x);s.physical_x_max=maxf(s.physical_x_max,p.x)
		s.hp_min=minf(s.hp_min,actor.hp)
		if actor.hp<100:s.wounded+=1
		s.phases[actor.phase]=s.phases.get(actor.phase,0)+1
	for s:Dictionary in sides.values():s.mean_x/=s.n
	var local:Dictionary=scene._input_port.view()
	var notice:String=scene._hud._overlay.notice.text
	var row:Dictionary={"tick":main._last_tick,"sides":sides,"formations":gstates,"notice":notice,"mode":local.mode,"selection":local.selection.duplicate(),"page":local.command_page,"feedback":local.feedback.duplicate(true)}
	metrics[tag]=row
	print("SAMPLE ",tag," ",JSON.stringify(row))
	return row

func button_down(code: MouseButton, pressed:bool):
	var e:=InputEventMouseButton.new()
	e.button_index=code;e.pressed=pressed
	e.position=root.get_visible_rect().get_center()
	e.global_position=e.position
	root.push_input(e,true)

func flat(v:Vector3)->Vector3:
	return Vector3(v.x,0,v.z).normalized()

func gear_tests():
	var player:Dictionary=scene._hud_state.player
	var mission:RefCounted=main._root._field_mission.get_ref()
	var actor:Dictionary=scene._hud_state.actor_handle
	var com:Dictionary=mission._com.view(actor).value
	verify(com.get("commander")==true and mission._frame.rows[actor.index].components.hero_id==mission._commander_hero,"controlled actor is actual commander in COM and roster")
	var sight_start:=flat(-scene._camera.global_basis.z)
	var pos_start:Vector3=scene._hud_state.position
	key(KEY_D,true)
	await frames(12)
	key(KEY_D,false)
	var displacement:Vector3=scene._hud_state.position-pos_start
	verify(displacement.length()>.3 and absf(flat(displacement).dot(sight_start))<.15,"first strafe moves sideways",displacement)
	button_down(MOUSE_BUTTON_RIGHT,true)
	await frames(3)
	verify(flat(scene._hud_state.heading).dot(sight_start)>.98 and scene._hud_state.player.phase=="Guard","guard after first strafe aligns with camera",[scene._hud_state.heading,sight_start,scene._hud_state.player.phase])
	button_down(MOUSE_BUTTON_RIGHT,false)
	await frames(16)
	button_down(MOUSE_BUTTON_LEFT,true)
	await frames(4)
	verify(flat(scene._hud_state.heading).dot(sight_start)>.98 and scene._hud_state.player.phase in ["Windup","Hold","Active"],"attack after first strafe follows camera")
	button_down(MOUSE_BUTTON_LEFT,false)
	await frames(25)
	var hp:=find_node("PlayerHealth") as Label
	var rank_label:=find_node("PlayerIdentity") as Label
	var st:=find_node("PlayerStamina") as Label
	if not verify(visible(hp) and player.has("max_hp") and str(int(player.hp)) in hp.text and str(int(player.max_hp)) in hp.text,"commander health and maximum from combat state",hp.text):return
	if not verify(visible(rank_label) and player.has("level") and "等级" in rank_label.text and str(player.level) in rank_label.text,"actual commander level displayed",rank_label.text):return
	if not verify(visible(st) and "体力" in st.text,"explicit stamina state displayed",st.text):return
	if player.get("stamina_enabled")==false:verify("不限" in st.text,"unlimited stamina for drill accurately labelled",st.text)
	else:verify(str(player.stamina) in st.text and str(player.max_stamina) in st.text,"current and maximum stamina displayed",st.text)
	metrics["commander"]={"hp":hp.text,"level":rank_label.text,"stamina":st.text,"equipment":player.equipped_items,"weapons":player.weapons}
	tap(KEY_I)
	await frames(4)
	var kit:=find_node("KitRows")
	if not verify(visible(kit) and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE and scene._input_port.view().mode=="inventory","I opens field backpack and releases pointer"):return
	var rows:=PackedStringArray()
	for c in kit.get_children():
		if c.visible: rows.append(c.text)
	var words:="|".join(rows)
	for item:Dictionary in player.equipped_items:verify(item.name in words,"current item shown "+item.slot,item.name)
	verify(not player.equipped_items.is_empty() and "使用中" in words,"equipment rows label the active slot",words)
	await snapshot("inventory")
	tap(KEY_F1);tap(KEY_F3);key(KEY_W,true);button_down(MOUSE_BUTTON_LEFT,true);await frames(3);key(KEY_W,false);button_down(MOUSE_BUTTON_LEFT,false)
	var inside:Dictionary=scene._input_port.view()
	verify(inside.mode=="inventory" and not inside.orders_open and scene._hud_state.player.phase=="Ready","backpack suppresses combat orders and attacks",inside)
	tap(KEY_ESCAPE)
	await frames(3)
	verify(scene._input_port.view().mode=="battle" and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"Esc closes backpack directly to combat")
	tap(KEY_ESCAPE)
	await frames(2)
	if not verify(await click(find_node("Inventory")) and visible(kit),"backpack also opens through Esc menu"):return
	tap(KEY_I)
	await frames(3)
	verify(scene._input_port.view().mode=="ui" and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"I closes menu-opened backpack back to menu")
	if not verify(await click(find_node("Resume")) and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"resume combat from menu"):return
	var actor_before:Vector3=flat(scene._hud_state.heading)
	var cam_before:Vector3=flat(-scene._camera.global_basis.z)
	move_mouse(root.get_visible_rect().get_center(),Vector2(1190,0))
	await frames(6)
	var cam_after:Vector3=flat(-scene._camera.global_basis.z)
	var body:Vector3=flat(scene._hud_state.heading)
	verify(cam_before.dot(cam_after)<-.85 and body.dot(actor_before)>.99 and body.dot(cam_after)<-.82,"idle third-person camera can face actor while actor still", [cam_before,cam_after,actor_before,body])
	await snapshot("face")
	key(KEY_W,true)
	await frames(1)
	var early:Vector3=flat(scene._hud_state.heading)
	await frames(6)
	var middle:Vector3=flat(scene._hud_state.heading)
	await frames(40)
	key(KEY_W,false)
	var late:Vector3=flat(scene._hud_state.heading)
	verify(early.dot(actor_before)>.70 and middle.dot(actor_before)<.96 and late.dot(cam_after)>.95,"moving turns actor through intermediate angles",[early,middle,late])
	move_mouse(root.get_visible_rect().get_center(),Vector2(400,0))
	await frames(4)
	button_down(MOUSE_BUTTON_RIGHT,true)
	await frames(5)
	var sight:=flat(-scene._camera.global_basis.z)
	verify(flat(scene._hud_state.heading).dot(sight)>.975,"RMB guard aligns actor with rendered sight line",[scene._hud_state.heading,sight])
	button_down(MOUSE_BUTTON_RIGHT,false)
	await frames(20)
	move_mouse(root.get_visible_rect().get_center(),Vector2(-290,0))
	await frames(4)
	button_down(MOUSE_BUTTON_LEFT,true)
	await frames(5)
	sight=flat(-scene._camera.global_basis.z)
	var attack_dir:Vector3=flat(scene._hud_state.heading)
	verify(attack_dir.dot(sight)>.975 and scene._hud_state.player.phase in ["Windup","Hold","Active"],"LMB attack uses sight line",[attack_dir,sight,scene._hud_state.player.phase])
	button_down(MOUSE_BUTTON_LEFT,false)
	await frames(24)
	var held_origin:=flat(scene._hud_state.heading)
	sight=flat(-scene._camera.global_basis.z)
	key(KEY_QUOTELEFT,true)
	move_mouse(root.get_visible_rect().get_center(),Vector2(135,0))
	await frames(4)
	verify(scene._input_port.view().free_look and flat(-scene._camera.global_basis.z).dot(sight)<.98 and flat(scene._hud_state.heading).dot(held_origin)>.99,"held free look orbits without changing body")
	key(KEY_QUOTELEFT,false)
	await frames(4)
	verify(flat(-scene._camera.global_basis.z).dot(sight)>.99,"free look release returns to sight")
	tap(KEY_R)
	move_mouse(root.get_visible_rect().get_center(),Vector2(150,0))
	await frames(5)
	verify(scene._camera.state().mode=="first" and flat(scene._hud_state.heading).dot(flat(-scene._camera.global_basis.z))>.975,"R enters first person and turns with pointer")
	tap(KEY_R)
	await frames(4)
	verify(scene._camera.state().mode=="third","R returns to third person")

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(DisplayServer.get_name()!="headless" and root.size==SMALL,"real 960x600 window",root.size):return
	if not verify(await click(main._desktop._buttons.field),"enter field via main menu"):return
	scene=main._field_scene
	if not verify(await click(find_node("Deploy")),"start field via deployment button"):return
	for i in 180:
		await process_frame
		if scene.running and main._last_tick>8:break
	if not verify(scene.running and main._last_tick>8,"field running",main._last_tick):return
	var initial:Dictionary=sample("initial")
	if not verify(initial.sides["0"].n==250 and initial.sides["1"].n==250,"500 people on the field"):return
	
	tap(KEY_0)
	await frames(2)
	verify(sample("selection").selection.size()==4,"0 selects all four formations")
	tap(KEY_F1)
	await frames(2)
	verify(sample("movement_menu").page=="movement","F1 opens movement family")
	await snapshot("movement")
	tap(KEY_F3)
	await frames(5)
	var issued:Dictionary=sample("issued")
	verify(issued.feedback.get("ok",false),"order received",issued.feedback)
	await snapshot("issued")
	var target_tick:int=main._last_tick+1600
	var damage_by_target:Dictionary={}
	var mission:RefCounted=main._root._field_mission.get_ref()
	var progress_key:int=main._last_tick+200
	var first_blood:Dictionary={}
	var then:=Time.get_ticks_msec()
	while main._last_tick<target_tick and Time.get_ticks_msec()-then<170000:
		await process_frame
		if not is_instance_valid(scene):break
		for hit:Dictionary in mission._frame.combat_report.get("hits",[]):
			if hit.damage>0:
				var who=mission._frame.rows[hit.target.index].components.team_key
				if not damage_by_target.has(str(who)): damage_by_target[str(who)]={"tick":mission._tick,"damage":hit.damage}
		if main._last_tick>=progress_key:
			var stat:Dictionary=sample("tick_"+str(main._last_tick))
			if first_blood.is_empty() and (stat.sides["0"].wounded>0 or stat.sides["1"].wounded>0):
				first_blood=stat
			progress_key+=200
		if damage_by_target.size()==2 and main._last_tick>1000:break
	if not is_instance_valid(scene):
		verify(false,"field scene survived")
		return
	var last:Dictionary=sample("end")
	metrics["sampled_hits"]=damage_by_target
	if OS.get_environment("FIELD_KIT_NEW")=="1":verify(damage_by_target.size()==2,"both armies damage their opponents",damage_by_target)
	verify(last.tick-issued.tick>=180,"simulation keeps advancing",[issued.tick,last.tick])
	var advanced:bool=last.sides["0"].mean_x>initial.sides["0"].mean_x+6
	verify(advanced,"friendly formation closed horizontal distance",last.sides["0"].mean_x-initial.sides["0"].mean_x)
	verify(not first_blood.is_empty(),"units reached a damaging attack by 1600 ticks")
	await snapshot("battle")
	if OS.get_environment("FIELD_KIT_NEW")=="1":await gear_tests()
	var native:=OS.get_environment("RIVER_NATIVE")=="1"
	verify(ClassDB.class_exists(&"FieldMoveKernel")==native,"expected native loader")
	if native: verify(int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))>0,"native DLL executed")
	tap(KEY_ESCAPE)
	await frames(3)
	if not verify(await click(find_node("Withdraw")) and await click(find_node("Confirm")),"leave battle via confirmation"):return
	await frames(4)
	verify(await click(find_node("Leave")),"close results")
	verify(main._field_scene==null,"menu restored")

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("KIT_CHARGE_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

