#include "gdextension_interface.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <limits>
#include <unordered_map>
#include <vector>

namespace {
using Type = GDExtensionVariantType;
constexpr Type names=GDEXTENSION_VARIANT_TYPE_STRING_NAME;
constexpr Type integer=GDEXTENSION_VARIANT_TYPE_INT;
constexpr Type vectors=GDEXTENSION_VARIANT_TYPE_PACKED_VECTOR3_ARRAY;
constexpr Type integers=GDEXTENSION_VARIANT_TYPE_PACKED_INT32_ARRAY;
constexpr Type reals=GDEXTENSION_VARIANT_TYPE_PACKED_FLOAT64_ARRAY;
constexpr Type floating=GDEXTENSION_VARIANT_TYPE_FLOAT;
constexpr Type array=GDEXTENSION_VARIANT_TYPE_ARRAY;
struct Name { alignas(8) unsigned char bytes[8]; };
struct Packed { alignas(8) unsigned char bytes[16]; };
struct Vec {float x,y,z;};
struct Cell {int x,z;};
uint64_t key(Cell c) { return (uint64_t(uint32_t(c.x))<<32)|uint32_t(c.z); }
// Vector components are real_t float; GDScript scalar arithmetic is double.
int cell_at(float p) { return int(std::floor(double(p)/1.2)); }
uint64_t grid_key(Vec p) { return key({cell_at(p.x),cell_at(p.z)}); }
Vec subtract(Vec a,Vec b) {return {a.x-b.x,a.y-b.y,a.z-b.z};}
float dot(Vec a,Vec b) {return a.x*b.x+a.y*b.y+a.z*b.z;}
bool valid(Vec p) {return std::abs(p.x)<1.0e7f && std::abs(p.z)<1.0e7f && std::abs(p.y)<1.0e7f;}
using Grid = std::unordered_map<uint64_t,std::vector<int>>;

int blocker(int i,Vec candidate,const std::vector<Vec>& positions,const double* radii,const Grid& cells,int& checks) {
    const Vec p=positions[i];
    const Vec motion=subtract(candidate,p);
    const double length_sq=dot(motion,motion);
    const float reach=float(std::abs(radii[i])+0.47);
    const Cell first{cell_at(std::min(p.x,candidate.x)-reach),cell_at(std::min(p.z,candidate.z)-reach)};
    const Cell last{cell_at(std::max(p.x,candidate.x)+reach),cell_at(std::max(p.z,candidate.z)+reach)};
    int inspected=0;
    for(int x=first.x;x<=last.x;++x) for(int z=first.z;z<=last.z;++z) {
        const auto bucket=cells.find(key({x,z}));
        if(bucket==cells.end()) continue;
        for(const int other:bucket->second) {
            if(other==i) continue;
            ++checks;
            const Vec separation=subtract(p,positions[other]);
            const double approaching=-dot(separation,motion);
            if(approaching>0) {
                const float t=float(std::min(approaching/length_sq,1.0));
                const Vec closest{separation.x+motion.x*t,separation.y+motion.y*t,separation.z+motion.z*t};
                const double threshold=std::abs(radii[i])+std::abs(radii[other]);
                if(dot(closest,closest)<threshold*threshold) return other;
            }
            if(++inspected>=48) return -2;
        }
    }
    return -1;
}

GDExtensionInterfaceGetProcAddress get;
GDExtensionClassLibraryPtr library;
template<typename T> T api(const char* s) {return reinterpret_cast<T>(get(s));}
GDExtensionPtrBuiltInMethod vec_size, int_size, real_size, resize_ints,resize_vecs,resize_array,normalized;
GDExtensionInterfacePackedVector3ArrayOperatorIndexConst read_vec;
GDExtensionInterfacePackedFloat64ArrayOperatorIndexConst read_real;
GDExtensionInterfacePackedInt32ArrayOperatorIndexConst read_int;
GDExtensionInterfacePackedInt32ArrayOperatorIndex write_int;
GDExtensionInterfacePackedVector3ArrayOperatorIndex write_vec;
GDExtensionInterfaceArrayOperatorIndex array_at;
GDExtensionPtrConstructor new_ints,new_vecs,new_array;
GDExtensionPtrDestructor drop_ints,drop_name,drop_vecs,drop_array;
GDExtensionInterfaceVariantGetType type_of;
GDExtensionInterfaceGetVariantGetInternalPtrFunc internal;
GDExtensionInterfaceGetVariantFromTypeConstructor from_type;
GDExtensionInterfaceVariantDestroy drop_variant;
GDExtensionInterfaceStringNameNewWithLatin1Chars new_name;
Name class_name;
std::atomic<int64_t> calls{0};
int64_t length(GDExtensionPtrBuiltInMethod method,const void* arr) {
    int64_t n=0; method(const_cast<void*>(arr),nullptr,&n,0); return n;
}
bool resize(void* arr,int64_t count,GDExtensionPtrBuiltInMethod fn) {
    const void* args[]={&count};
    int64_t error=0; fn(arr,args,&error,1); return error==0;
}

Vec unit(Vec p) {
    Vec r;
    normalized(&p,nullptr,&r,0);
    return r;
}
Vec foot_step(Vec position,Vec target,double fraction,double scene,double dt,Vec& heading,int32_t& clipped) {
    const Vec delta=subtract(target,position);
    const float len_sq=dot(delta,delta);
    const double distance=std::sqrt(len_sq);
    const Vec direction=unit(delta);
    heading=unit({direction.x,0,direction.z});
    double travel=std::min(distance,3.4*fraction*dt);
    if(scene<0) scene=(len_sq<0.000001 || fraction<=0)?0.0:std::min(distance,3.4*dt);
    clipped=travel>scene;
    if(clipped) travel=scene;
    const float stride=float(travel);
    return {position.x+direction.x*stride,position.y+direction.y*stride,position.z+direction.z*stride};
}
bool solve(const GDExtensionConstTypePtr* args,void* result,void* rebuilt) {
    const int64_t count=length(vec_size,args[0]);
    const int64_t start=*static_cast<const int64_t*>(args[4]), end=*static_cast<const int64_t*>(args[5]);
    const int64_t order_count=length(int_size,args[3]);
    if(count<=0 || count>1000000 || start<0 || start>=end || end>count ||
       length(vec_size,args[1])!=count || length(real_size,args[2])!=count ||
       (order_count!=0 && order_count!=count)) return false;
    const bool foot=rebuilt!=nullptr;
    double dt=0;
    const double* params=nullptr;
    if(foot) {
        if(length(real_size,args[6])!=count*2) return false;
        params=read_real(args[6],0);
        dt=*static_cast<const double*>(args[7]);
        if(!(dt>0 && dt<=0.1)) return false;
    }
    const auto* p=static_cast<const Vec*>(read_vec(args[0],0));
    const auto* candidate=static_cast<const Vec*>(read_vec(args[1],0));
    const auto* radius=read_real(args[2],0);
    const auto* order=order_count?read_int(args[3],0):nullptr;
    std::vector<unsigned char> seen(order_count?count:0);
    std::vector<Vec> positions(p,p+count);
    Grid cells;
    cells.reserve(count);
    for(int k=0;k<count;++k) {
        const int i=order?order[k]:k;
        if(i<0 || i>=count || (order && seen[i]++)) return false;
        if(!valid(p[i]) || !std::isfinite(radius[i]) || std::abs(radius[i])>10.0) return false;
        if(i>=start && i<end && radius[i]>=0) {
            if(!valid(candidate[i])) return false;
            if(foot && (!std::isfinite(params[i*2]) || params[i*2]>1)) return false;
            if(foot && params[i*2]>=0) {
                if(std::isnan(params[i*2+1]) || (params[i*2+1]<0 && params[i*2+1]!=-1)) return false;
            } else if(std::abs(candidate[i].x-p[i].x)>20 || std::abs(candidate[i].z-p[i].z)>20) return false;
        }
        cells[grid_key(p[i])].push_back(i);
    }
    const int64_t span=end-start;
    if(foot && !resize(rebuilt,2*span,resize_vecs)) return false;
    if(!resize(result,(foot?2:1)*span+1,resize_ints)) return false;
    Vec* motion=foot?static_cast<Vec*>(write_vec(rebuilt,0)):nullptr;
    int32_t* answer=write_int(result,0);
    int checks=0;
    for(int i=int(start);i<end;++i) {
        Vec next=candidate[i];
        if(foot) {
            int32_t clipped=0;
            Vec heading{};
            if(radius[i]>=0 && params[i*2]>=0)
                next=foot_step(positions[i],next,params[i*2],params[i*2+1],dt,heading,clipped);
            motion[2*(i-start)]=next;
            motion[2*(i-start)+1]=heading;
            answer[span+i-start]=clipped;
        }
        const int hit=radius[i]<0?-3:blocker(i,next,positions,radius,cells,checks);
        answer[i-start]=hit;
        if(hit!=-1) continue;
        const auto a=grid_key(positions[i]), b=grid_key(next);
        positions[i]=next;
        if(a==b) continue;
        auto& old=cells[a];
        old.erase(std::find(old.begin(),old.end(),i));
        cells[b].push_back(i);
    }
    answer[(foot?2:1)*span]=checks;
    ++calls;
    return true;
}

constexpr Type inputs[]={vectors,vectors,reals,integers,integer,integer,reals,floating};
enum Operation { SOLVE, COUNT, ADVANCE };
Operation operations[]={SOLVE,COUNT,ADVANCE};
void ptr_call(void* tag,GDExtensionClassInstancePtr,const GDExtensionConstTypePtr* args,void* result) {
    Operation op=*static_cast<Operation*>(tag);
    if(op==COUNT) {*static_cast<int64_t*>(result)=calls.load();return;}
    if(op==SOLVE) {solve(args,result,nullptr);return;}
    Packed flags,vecs; new_ints(&flags,nullptr);new_vecs(&vecs,nullptr);
    if(solve(args,&flags,&vecs) && resize(result,2,resize_array)) {
        auto a=array_at(result,0), b=array_at(result,1);
        drop_variant(a); from_type(integers)(a,&flags);
        drop_variant(b); from_type(vectors)(b,&vecs);
    }
    drop_vecs(&vecs);drop_ints(&flags);
}
void var_call(void* tag,GDExtensionClassInstancePtr,const GDExtensionConstVariantPtr* args,int64_t n,void* result,GDExtensionCallError* error) {
    Operation op=*static_cast<Operation*>(tag);
    const int expected=op==COUNT?0:(op==ADVANCE?8:6);
    if(n!=expected) {error->error=n>expected?GDEXTENSION_CALL_ERROR_TOO_MANY_ARGUMENTS:GDEXTENSION_CALL_ERROR_TOO_FEW_ARGUMENTS;error->expected=expected;return;}
    std::array<GDExtensionConstTypePtr,8> plain{};
    for(int i=0;i<n;++i) {
        if(type_of(args[i])!=inputs[i]) {error->error=GDEXTENSION_CALL_ERROR_INVALID_ARGUMENT;error->argument=i;error->expected=inputs[i];return;}
        plain[i]=internal(inputs[i])(const_cast<void*>(args[i]));
    }
    drop_variant(result);
    if(op==COUNT) {
        int64_t value=calls.load();
        from_type(integer)(result,&value);
    } else if(op==SOLVE) {
        Packed output;
        new_ints(&output,nullptr);
        solve(plain.data(),&output,nullptr);
        from_type(integers)(result,&output);
        drop_ints(&output);
    } else {
        Packed output; new_array(&output,nullptr);
        ptr_call(tag,nullptr,plain.data(),&output);
        from_type(array)(result,&output); drop_array(&output);
    }
    error->error=GDEXTENSION_CALL_OK;
}

void start(void*,GDExtensionInitializationLevel level) {
    if(level!=GDEXTENSION_INITIALIZATION_SCENE) return;
    new_name=api<GDExtensionInterfaceStringNameNewWithLatin1Chars>("string_name_new_with_latin1_chars");
    const auto dtor=api<GDExtensionInterfaceVariantGetPtrDestructor>("variant_get_ptr_destructor");
    const auto ctor=api<GDExtensionInterfaceVariantGetPtrConstructor>("variant_get_ptr_constructor");
    const auto method=api<GDExtensionInterfaceVariantGetPtrBuiltinMethod>("variant_get_ptr_builtin_method");
    drop_name=dtor(names); drop_ints=dtor(integers); new_ints=ctor(integers,0);
    new_array=ctor(array,0); new_vecs=ctor(vectors,0); drop_array=dtor(array); drop_vecs=dtor(vectors);
    Name size,resize_name,parent,blank;
    new_name(&size,"size",0); new_name(&resize_name,"resize",0); new_name(&parent,"Object",0); new_name(&blank,"",0);
    new_name(&class_name,"FieldMoveKernel",0);
    vec_size=method(vectors,&size,3173160232LL); int_size=method(integers,&size,3173160232LL); real_size=method(reals,&size,3173160232LL);
    resize_ints=method(integers,&resize_name,848867239LL);
    resize_vecs=method(vectors,&resize_name,848867239LL);
    resize_array=method(array,&resize_name,848867239LL);
    Name unit_name;new_name(&unit_name,"normalized",0);
    normalized=method(GDEXTENSION_VARIANT_TYPE_VECTOR3,&unit_name,1776574132LL);
    drop_name(&unit_name);
    read_vec=api<GDExtensionInterfacePackedVector3ArrayOperatorIndexConst>("packed_vector3_array_operator_index_const");
    read_real=api<GDExtensionInterfacePackedFloat64ArrayOperatorIndexConst>("packed_float64_array_operator_index_const");
    read_int=api<GDExtensionInterfacePackedInt32ArrayOperatorIndexConst>("packed_int32_array_operator_index_const");
    write_int=api<GDExtensionInterfacePackedInt32ArrayOperatorIndex>("packed_int32_array_operator_index");
    write_vec=api<GDExtensionInterfacePackedVector3ArrayOperatorIndex>("packed_vector3_array_operator_index");
    array_at=api<GDExtensionInterfaceArrayOperatorIndex>("array_operator_index");
    internal=api<GDExtensionInterfaceGetVariantGetInternalPtrFunc>("variant_get_ptr_internal_getter");
    from_type=api<GDExtensionInterfaceGetVariantFromTypeConstructor>("get_variant_from_type_constructor");
    drop_variant=api<GDExtensionInterfaceVariantDestroy>("variant_destroy");
    type_of=api<GDExtensionInterfaceVariantGetType>("variant_get_type");
    GDExtensionClassCreationInfo6 info{}; info.is_abstract=true; info.is_exposed=true;
    api<GDExtensionInterfaceClassdbRegisterExtensionClass6>("classdb_register_extension_class6")(library,&class_name,&parent,&info);
    alignas(8) unsigned char empty[8]; ctor(GDEXTENSION_VARIANT_TYPE_STRING,0)(empty,nullptr);
    const char* labels[]={"positions","candidates","radii","order","start","end","foot","dt"};
    Name label[8];
    GDExtensionPropertyInfo params[8]{};
    GDExtensionClassMethodArgumentMetadata metadata[8]{};
    for(int i=0;i<8;++i) {
        new_name(&label[i],labels[i],0);
        params[i]={inputs[i],&label[i],&blank,0,empty,6};
    }
    for(auto& op:operations) {
        Name name;new_name(&name,op==COUNT?"call_count":(op==ADVANCE?"advance":"solve"),0);
        GDExtensionPropertyInfo output{op==COUNT?integer:(op==ADVANCE?array:integers),&blank,&blank,0,empty,6};
        GDExtensionClassMethodInfo m{};m.name=&name;m.method_userdata=&op;
        m.call_func=var_call;m.ptrcall_func=ptr_call;m.method_flags=GDEXTENSION_METHOD_FLAG_NORMAL|GDEXTENSION_METHOD_FLAG_STATIC;
        m.has_return_value=true;m.return_value_info=&output;m.argument_count=op==COUNT?0:(op==ADVANCE?8:6);
        m.arguments_info=params;m.arguments_metadata=metadata;
        api<GDExtensionInterfaceClassdbRegisterExtensionClassMethod>("classdb_register_extension_class_method")(library,&class_name,&m);
        drop_name(&name);
    }
    for(auto& n:label) drop_name(&n);
    for(Name* n:{&parent,&blank,&resize_name,&size}) drop_name(n);
    dtor(GDEXTENSION_VARIANT_TYPE_STRING)(empty);
}
void stop(void*,GDExtensionInitializationLevel level) {
    if(level!=GDEXTENSION_INITIALIZATION_SCENE) return;
    api<GDExtensionInterfaceClassdbUnregisterExtensionClass>("classdb_unregister_extension_class")(library,&class_name);
    drop_name(&class_name);
}
}
extern "C" __declspec(dllexport) GDExtensionBool field_move_init(GDExtensionInterfaceGetProcAddress resolve,GDExtensionClassLibraryPtr lib,GDExtensionInitialization* init) {
    get=resolve; library=lib; init->minimum_initialization_level=GDEXTENSION_INITIALIZATION_SCENE;
    init->initialize=start; init->deinitialize=stop; return true;
}
