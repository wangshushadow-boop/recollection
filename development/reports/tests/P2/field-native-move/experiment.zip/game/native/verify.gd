extends SceneTree

func _initialize() -> void:
	var version := Engine.get_version_info()
	if version.major!=4 or version.minor!=7 or version.patch!=2 or not ClassDB.class_exists(&"FieldMoveKernel"):
		printerr("Expected Godot 4.7.2 Standard with FieldMoveKernel")
		quit(1)
		return
	var before: int = ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")
	var value: Array = ClassDB.class_call_static(&"FieldMoveKernel",&"advance",
		PackedVector3Array([Vector3.ZERO]),PackedVector3Array([Vector3.RIGHT]),
		PackedFloat64Array([0.28]),PackedInt32Array(),0,1,PackedFloat64Array([1.0,-1.0]),1.0/60)
	var after: int = ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")
	var valid: bool = after==before+1 and value.size()==2 and value[0][0]==-1 and value[1][0].x>0.0
	print("Native move startup check: ", "PASS" if valid else "FAIL")
	quit(0 if valid else 1)
