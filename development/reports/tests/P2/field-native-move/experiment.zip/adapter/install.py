"""Apply the native movement experiment to an isolated game project."""
from pathlib import Path
import shutil
import sys

here = Path(__file__).resolve().parent
repo = here.parents[2]
game = Path(sys.argv[1]).resolve()
if game == (repo / 'game').resolve() or not (game / 'project.godot').is_file():
    sys.exit('expected an isolated game directory')
path = game / 'mission/movement/ports/field_movement.gd'
source = path.read_text(encoding='utf-8')
if 'func _native_motion(' in source:
    sys.exit('native adapter already present')

def replace_once(old, new):
    global source
    if source.count(old) != 1:
        raise RuntimeError('unexpected movement baseline at ' + old[:70])
    source = source.replace(old,new)

replace_once('var _checks := 0','''var _native_ai_tokens := {}
var _kernel_ready := false
var _kernel_checked := false
var _native_batches := 0
var _native_rows := 0
var _native_foot_rows := 0
var _native_skipped_rows := 0
var _native_pack_us := 0
var _native_solve_us := 0
var _native_apply_us := 0
var _checks := 0''')
replace_once('_draft._had_drives = _had_drives','_draft._had_drives = _had_drives\n\t_draft._native_ai_tokens = _native_ai_tokens')
replace_once('if not _had_drives and _airborne_count==0:\n\t\tfor b: Body in bodies:', '''_native_batches = 0
	_native_rows = 0
	_native_foot_rows = 0
	_native_skipped_rows = 0
	_native_pack_us = 0
	_native_solve_us = 0
	_native_apply_us = 0
	if not _kernel_checked:
		_kernel_checked = true
		_kernel_ready = ClassDB.class_exists("FieldMoveKernel")
	if _kernel_ready and _had_drives and bodies.size()>=16 and _zones.is_empty() and not _native_ai_tokens.is_empty():
		var advanced := _native_motion(bodies,tick,dt)
		if not advanced.ok: return advanced
	elif not _had_drives and _airborne_count==0:
		for b: Body in bodies:''')
replace_once('"neighbour_checks":_checks,"yielding":_yields}', '''"neighbour_checks":_checks,"yielding":_yields,
		"native_batches":_native_batches,"native_rows":_native_rows,"native_foot_rows":_native_foot_rows,
		"native_mounted_rows":_native_rows-_native_foot_rows,"native_skipped_rows":_native_skipped_rows,
		"native_fallback_rows":bodies.size()-_native_rows-_native_skipped_rows,"native_pack_us":_native_pack_us,
		"native_solve_us":_native_solve_us,"native_apply_us":_native_apply_us}''')

# Reuse the precise script and engine arithmetic for mounted turn integration.
predict = source[source.index('\tvar direction := delta.normalized()',source.index('func _advance(')):source.index('\n\tfor passage in b.passages:',source.index('func _advance('))]
source += (here/'adapter.gd.inc').read_text(encoding='utf-8').replace('@@PREDICT@@',predict)
path.write_text(source,encoding='utf-8')
path = game / 'mission/runtime/field_pipeline.gd'
source = path.read_text(encoding='utf-8')
replace_once('if not setup.ok: return setup','''if not setup.ok: return setup
	# Only the production reader's locally issued AI credentials have no external callback.
	if get_script().resource_path=="res://mission/runtime/field_mission.gd":
		for token in _credentials: _move._native_ai_tokens[token]=true
		_move._native_ai_tokens.make_read_only()''')
path.write_text(source,encoding='utf-8')
native = game / 'native'
native.mkdir(exist_ok=True)
for name in ('field_move.dll','field_move.gdextension'):
    shutil.copy2(here.parent/'kernel'/name,native/name)
extensions = game/'.godot'/'extension_list.cfg'
extensions.parent.mkdir(exist_ok=True)
lines = extensions.read_text(encoding='utf-8').splitlines() if extensions.exists() else []
if 'res://native/field_move.gdextension' not in lines:
    extensions.write_text('\n'.join(lines+['res://native/field_move.gdextension'])+'\n',encoding='utf-8')
