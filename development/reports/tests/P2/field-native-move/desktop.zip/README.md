# 野战原生移动桌面对照

使用 Godot 4.7.2 Standard、RTX 3090、Core Ultra 9 285K、Forward+，分辨率 960×600。保持种子 241124、初始 500 名士兵和 100 匹马、60 Hz 和每显示帧最多补算两步。两次独立启动实际桌面游戏，从主菜单进入河原，在布阵画面等 45 帧后开战。每步存一条阶段汇总，每显示帧记录 frame_post_draw 间隔。

- idle 为无输入站立样本的第 121–440 步。
- march 为命令样本第 121–440 步。第 1 步后向四个阵型分别下达固定目标的移动命令。
- contact 为同一命令样本首次有效命中至第 1260 步。第 900 步发自由攻击。本段含投射物交战。

完整步含全部战斗系统。advance 从 MOV 网格准备结束算到全体推进完成，包含脚本打包、原生调用、归并和脚本回退。physics_stage 为物理代理校验与更新。各段 FPS 与实际每现实秒步数按完整显示帧的总墙钟计算；加载和部署耗时在窗口外。P50、P95 取最近秩。每个版本每种场景各一个进程，行军与接战复用同一进程。

在本仓库 out/native-move/bench/ 下展开该包。 prepare.py 使用指定 Git 提交与本地已导入的 game/.godot 缓存创建隔离副本。基线示例：

```powershell
python out/native-move/bench/prepare.py base 5277bd4
& ./out/native-move/bench/run.ps1 base
python out/native-move/bench/stats.py base
```

运行候选需要相同游戏版本、原生库及专用 MOV 适配脚本。将原生候选源码、已构建 DLL 和适配器放在 out/native-move/kernel 与 out/native-move/adapter 后执行：

```powershell
python out/native-move/bench/prepare.py final 5277bd4 --installer out/native-move/adapter/install.py
& ./out/native-move/bench/run.ps1 final
python out/native-move/bench/stats.py base final
python out/native-move/bench/package.py base final
```

stats.py 比较正式窗口、命令、个体调度、实际让行、代理写回、命中、伤害和发射；如有差异，报告第一处不同的游戏步。归档包含逐步 JSON、逐帧计时、Godot 日志、未插桩脚本和 DLL 哈希与工具源码。各段 native 中的 native_foot_rows 为由 C++ 执行普通地面积分和避让的步兵，native_mounted_rows 为由脚本预测位移、C++ 裁决避让的骑兵，native_rows 为两者合计，native_skipped_rows 为仅作障碍物的行，native_fallback_rows 为其余脚本处理的行。每步可能有多批。native_pack_ms、native_solve_ms 和 native_apply_ms 分别记录打包、全部 DLL 调用和脚本写回，advance_ms 还包含其余脚本推进及调度。
