import hashlib
import json
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
labels = sys.argv[1:] or ["base", "final"]
files = ["prepare.py","run.ps1","stats.py","bench.gd","table.py","package.py","summary.json","README.md"]
for label in labels:
    files += [f"{label}-commit.txt",f"{label}-sources.json",*(f"{label}-{case}.{ext}" for case in ["idle","contact"] for ext in ["json","log"])]
    if (here/f"{label}-build.json").is_file(): files.append(f"{label}-build.json")
    if (here/f"{label}.patch").is_file(): files.append(f"{label}.patch")
manifest = {"git_baselines":{label:(here/f"{label}-commit.txt").read_text().strip() for label in labels},
            "sha256":{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in files}}
(here/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
with zipfile.ZipFile(here/"desktop.zip","w",zipfile.ZIP_DEFLATED) as z:
    for f in ["manifest.json",*files]: z.write(here/f,f)
with zipfile.ZipFile(here/"desktop.zip") as z:
    assert z.testzip() is None
