import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
d = json.loads((root/('summary.json' if len(sys.argv)<2 else sys.argv[1])).read_text())
for label, scenarios in d.items():
    if not isinstance(scenarios, dict) or "idle" not in scenarios: continue
    for case,row in scenarios.items():
        print(label,case,"FPS",row['fps'],"SPS",row['steps_per_second'],
              "P50/P95",*[f"{k} {row[k]['p50']}/{row[k]['p95']}" for k in
              ('frame_ms','field_step_ms','_walk_ms','_think_ms','prepare_ms','advance_ms','physics_stage_ms')],
              "work/step",*[f"{k} {row[k]['mean']}" for k in ('neighbor_checks','physics_writebacks','yielding')])
