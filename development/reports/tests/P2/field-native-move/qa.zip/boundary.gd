extends SceneTree
const Move = preload("res://mission/movement/ports/field_movement.gd")
const Adapter = preload("res://infrastructure/engine/adapter.gd")
const Pipeline = preload("res://mission/runtime/field_pipeline.gd")
const COUNT := 72
const DT := 1.0/60.0
var engine: RefCounted
var pipe: RefCounted
var credential := RefCounted.new()
var scope := ""
var handles: Array = []
var checks := 0
var failed := false

func _initialize() -> void:
	run.call_deferred()

func verify(ok: bool, label: String) -> bool:
	checks+=1
	if not ok and not failed:
		failed = true
		printerr("FAIL ",label)
	return ok

func count_calls() -> int:
	return int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))

func origin(i: int) -> Vector3:
	if i<54: return Vector3(-10,0,-10)
	if i==54: return Vector3(1.19,0,-4)
	if i==55: return Vector3(1.79,0,-4)
	return Vector3(-14.42+(i-56)%4*5.0,0,3+floori((i-56)/4.0)*4)

func staged(field: RefCounted,tick: int) -> Dictionary:
	var opened: Dictionary = field.begin_step(tick)
	if not verify(opened.ok,"open "+str(tick)): return {}
	if tick==0:
		for i in COUNT:
			var drive := {"actor_handle":handles[i],"speed_fraction":1.0,"desired_direction":[1000000,0,0],"stance":null}
			if not verify(field.apply_move_intent(opened.value,drive,credential).ok,"drive "+str(i)):return {}
	if tick==24:
		var brake := {"actor_handle":handles[58],"speed_fraction":0.0,"desired_direction":[0,0,0],"stance":null}
		if not verify(field.apply_move_intent(opened.value,brake,credential).ok,"stop"): return {}
		if not verify(field.request_jump(handles[57],credential,opened.value).ok,"jump"): return {}
	var moved: Dictionary = field.stage_step(tick,DT,opened.value)
	if not verify(moved.ok,"stage "+str(moved.get("error"))):return {}
	if not verify(field.commit_step(opened.value).ok,"commit"):return {}
	return moved.value

func geometry() -> bool:
	var crowd := PackedVector3Array()
	var radii := PackedFloat64Array()
	crowd.resize(50)
	radii.resize(50)
	radii.fill(0.28)
	var before := count_calls()
	var result: PackedInt32Array = ClassDB.class_call_static(&"FieldMoveKernel",&"solve",crowd,crowd,radii,PackedInt32Array(),0,1)
	if not verify(result==PackedInt32Array([-2,48]),"zero-displacement dense cap: "+str(result)):return false
	var positions := PackedVector3Array([Vector3(0,0,0),Vector3(.5,0,0),Vector3(.52,0,0)])
	var candidates := positions.duplicate()
	candidates[0]=Vector3(.1,0,0)
	radii.resize(3)
	for chosen in [[0,1,2],[0,2,1]]:
		result=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",positions,candidates,radii,PackedInt32Array(chosen),0,1)
		if not verify(result==PackedInt32Array([chosen[1],1]),"ordered equal-cell blockers: "+str(result)):return false
	positions=PackedVector3Array([Vector3(1.18,0,0),Vector3.ZERO])
	candidates=PackedVector3Array([Vector3(2.38,0,0),Vector3(1.23,0,0)])
	radii.resize(2)
	result=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",positions,candidates,radii,PackedInt32Array(),0,2)
	return verify(result.size()==3 and result[0]==-1 and result[1]==-1 and count_calls()==before+4,"later actor sees vacated grid cell: "+str(result))

func probe() -> bool:
	var reference_script: Script = load(OS.get_environment("RECOLLECTION_QA_MOV_REFERENCE"))
	if not verify(reference_script!=null,"reference script"):return false
	var reference: RefCounted = reference_script.new(engine,scope,pipe._drive_authorized)
	var candidate: RefCounted = Move.new(engine,scope,pipe._drive_authorized)
	candidate._native_ai_tokens[credential] = true
	candidate._native_ai_tokens.make_read_only()
	var rows := {}
	var profile := ""
	for i in COUNT:
		var h := {"index":i,"generation":1}
		handles.append(h)
		profile = "mounted" if i==56 else "foot"
		for field in [reference,candidate]:
			if not verify(field.spawn(h,origin(i),profile,Vector3.RIGHT).ok,"spawn"):return false
		rows[i]={"handle":h,"source_slot":i,"components":{"team_key":0}}
	pipe._frame={"rows":rows}
	pipe._credentials[credential]={"issuer_id":"ai","team_key":0}
	var calls := 0
	var native_rows := 0
	var yielded := 0
	var moved_cells := 0
	var last_cell := Vector2i.ZERO
	var was_airborne := false
	var landed := false
	var jumped := 0
	var mixed_jump_ticks := 0
	var stopped_at := Vector3.ZERO
	var saddle_travel := 0.0
	var order_asymmetry := false
	for tick in 94:
		var before := count_calls()
		var old := staged(reference,tick)
		if failed or not verify(count_calls()==before,"reference invoked native"): return false
		var current := staged(candidate,tick)
		if failed:return false
		var delta := count_calls()-before
		calls+=delta
		native_rows+=int(current.get("native_rows",0))
		if not verify(current.yielding==old.yielding and current.nav_revision==old.nav_revision and current.total_queried==old.total_queried,"budget/yield differences at "+str(tick)):return false
		yielded+=int(old.yielding)
		for i in COUNT:
			var a: Dictionary = reference.view(handles[i]).value
			var b: Dictionary = candidate.view(handles[i]).value
			if not verify(var_to_bytes(a)==var_to_bytes(b),"pose mismatch tick=%d actor=%d old=%s candidate=%s"%[tick,i,str(a),str(b)]):return false
			if i==56:
				var cell := Vector2i(floori(b.position.x/1.2),floori(b.position.z/1.2))
				if tick>0 and cell!=last_cell:moved_cells+=1
				last_cell=cell
				saddle_travel=b.position.distance_to(origin(i))
			if i==57:
				if b.airborne:
					jumped+=1
					if delta>0 and int(current.get("native_fallback_rows",0))>0:mixed_jump_ticks+=1
				if was_airborne and not b.airborne:landed=true
				was_airborne=b.airborne
			if i==58 and tick==23:stopped_at=b.position
			if i==58 and tick>=24 and not verify(b.position==stopped_at and b.velocity==Vector3.ZERO,"zero-travel stop"):return false
		var rear: Dictionary = reference.view(handles[54]).value
		var front: Dictionary = reference.view(handles[55]).value
		if rear.blocked=="yield" and front.velocity.length()>0:order_asymmetry=true
	var results={"checks":checks,"native_calls":calls,"native_rows":native_rows,"ticks":94,"roster":COUNT,"yielding":yielded,
		"crossed_cells_mounted":moved_cells,"mounted_m":saddle_travel,"jump_ticks":jumped,"mixed_jump_ticks":mixed_jump_ticks,
		"landed":landed,"order_asymmetry":order_asymmetry}
	print("NATIVE_BOUNDARY ",JSON.stringify(results))
	return verify(calls>0 and native_rows>0 and yielded>0 and moved_cells>0 and saddle_travel>2.0 and jumped>0 and mixed_jump_ticks>0 and landed and order_asymmetry,"boundary coverage "+str(results))

func run() -> void:
	if not verify(ClassDB.class_exists(&"FieldMoveKernel") and ClassDB.class_has_method(&"FieldMoveKernel",&"call_count"),"unavailable native extension"):quit(1);return
	engine=Adapter.new(root,true)
	pipe=Pipeline.new(null,engine,"fixture",null,Callable(),Callable())
	scope=pipe._mission
	var opened: Dictionary = engine.open_scope(scope)
	if not verify(opened.ok and engine.load_scene({"id":"base:scene/qa_native","simulation_scene":"res://content/base/field/river_plain.tscn"},opened.value).ok,"river navigation"): quit(1);return
	var ready := false
	for unused in 120:
		await physics_frame
		var synced: Dictionary = engine.sync_navigation(scope)
		if not synced.ok or synced.value.status!="applied":continue
		var sample: Dictionary = engine.query_path_batch([{"from":[-10000,0,0],"to":[-8000,0,0]}],synced.value.applied_revision,scope)
		if sample.ok and sample.value[0].reachable:ready=true;break
	var passed := verify(ready,"navigation ready") and geometry() and probe()
	engine.release_scope(scope)
	print("NATIVE_BOUNDARY_SUMMARY checks=",checks," pass=",passed)
	quit(0 if passed else 1)
