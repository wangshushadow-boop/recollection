extends SceneTree
func record_step(_tick: int, _us: int) -> void:
	pass
## Deterministic 500-soldier, 100-horse field witness; both products run the same script and commands.
const App = preload("res://bootstrap/composition_root.gd")
const Result = preload("res://contracts/result.gd")
const Config = preload("res://bootstrap/boot_config.gd")
const GOALS := {"infantry":[46000,0,-4000],"archer":[31000,0,4000],"cavalry":[52000,0,-14000],"mounted_archer":[37000,0,12000]}
var app: RefCounted
var scope := ""
var tick := 0
var sequence := 0
var orders := []
var sides := {}
var roles := {}
var origins := {}
var distances := {}
var hits_by_side := {}
var total_damage := 0
var first_hit := 0
var shots := 0
var traces := []
var engaged := false
var inject_failure := false
var digest := HashingContext.new()

func _initialize() -> void:
	run.call_deferred()

func fail_check(reason: String) -> bool:
	printerr("FAIL ", reason)
	quit(1)
	return false

func send(groups: Array, kind: String, goal: Variant) -> bool:
	var ids := []
	var revisions := {}
	for item in groups:
		ids.append(item.id)
		revisions[str(item.id)] = item.control_revision
	sequence += 1
	var id := "benchmark-order-%d"%sequence
	var command := {"mission_id":scope,"order_id":id,"issuer_id":"player","formation_ids":ids,
		"order_type":kind,"target_position":goal,"target_formation_id":null,"parameters":{},
		"issued_tick":tick+1,"client_sequence":sequence}
	var result: Dictionary = app.field_command("field.order",{"order":command,"revisions":revisions},tick,id)
	if not result.ok: return fail_check("order "+str(result))
	orders.append([tick,ids,kind,goal,revisions])
	return true

func reject_at_snapshot(_context: Dictionary, _batch: Dictionary) -> Dictionary:
	return Result.fail("Unavailable","qa.late_rollback") if inject_failure else Result.ok()

func native_counter() -> int:
	return int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))

func run() -> void:
	if not ClassDB.class_exists(&"FieldMoveKernel") or not ClassDB.class_has_method(&"FieldMoveKernel",&"call_count"):
		fail_check("native FieldMoveKernel/call_count unavailable");return
	var initial_calls := native_counter()
	var native_steps := 0
	var rollback_calls := 0
	var retry_calls := 0
	Engine.physics_ticks_per_second = 60
	app = App.new(root)
	var cfg := Config.resolve([],DisplayServer.get_name(),{})
	if not cfg.ok or not app.boot(cfg.value).ok: fail_check("boot"); return
	var population := 500 if OS.get_environment("RECOLLECTION_QA_COUNT")=="500" else 40
	var last_tick := 1260 if population==500 else 2100
	var reserved := population if population==500 else population*2
	var battle: Dictionary = app.start_field(population,reserved,241124)
	if not battle.ok: fail_check(str(battle)); return
	scope = battle.value
	var mission: RefCounted = app._field_mission.get_ref()
	if not mission.register_system("snapshot",{"id":"zz.qa.parallel_rollback","run":reject_at_snapshot}).ok:
		fail_check("register failure injection");return
	for attempt in range(last_tick+100):
		await physics_frame
		if tick==985:
			var previous: Dictionary=app.field_view("visual")
			if not previous.ok:fail_check("pre-failure visual");return
			var previous_bytes := var_to_bytes(previous.value)
			var before_reject := native_counter()
			inject_failure=true
			var rejected: Dictionary=app.field_step()
			inject_failure=false
			rollback_calls=native_counter()-before_reject
			if rejected.ok or rejected.error.field!="qa.late_rollback" or mission.view().tick!=tick:
				fail_check("missing late rollback or published failed tick");return
			var after: Dictionary=app.field_view("visual")
			if not after.ok or var_to_bytes(after.value)!=previous_bytes:
				fail_check("visible state changed after late rollback");return
			print("ROLLBACK PASS attempted_tick=",tick+1," last_committed=",tick," visual_unchanged=true")
		var before_commit := native_counter()
		var step: Dictionary = app.field_step()
		if not step.ok:
			if tick==0 and attempt<60 and step.error.code in ["Unavailable","StaleVersion"]:continue
			fail_check(str(step));return
		tick+=1
		var calls_this_tick := native_counter()-before_commit
		if calls_this_tick>0: native_steps+=1
		if tick==986: retry_calls=calls_this_tick
		if step.value.tick!=tick: fail_check("nonsequential tick");return
		for row in step.value.entities:
			sides[row.handle] = row.components.team_key
			if row.source_slot!=null: roles[row.handle]=row.components.troop_def_id.get_file()
		if tick==1 or (not engaged and tick%30==0):
			var hud: Dictionary = app.field_view("hud")
			if not hud.ok: fail_check("hud");return
			var groups: Array = hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
			if tick==1:
				if step.value.entities.size()!=population+population/5 or groups.size()!=4:fail_check("opening roster");return
				for group in groups:
					if not send([group],"move",GOALS[roles[group.members[0]]]):return
			elif not hud.value.targets.is_empty() or tick>=900:
				if not send(groups,"free_attack",null):return
				engaged=true
		var report: Dictionary = app.field_view("visual")
		if not report.ok:fail_check("visual "+str(report));return
		var events := []
		for system in step.value.system_reports:
			if system.id!="field.combat":continue
			for hit in system.value.hits:
				if hit.damage>0 and not hit.blocked and sides[hit.attacker]!=sides[hit.target]:
					if not first_hit: first_hit=tick
					var side: Variant=sides[hit.attacker]
					hits_by_side[side]=hits_by_side.get(side,0)+1
					total_damage+=hit.damage
			for event in system.value.events:
				if event.type=="projectile_launched":shots+=1
			events=[system.value.hits, system.value.events]
		for actor in report.value.actors:
			if not origins.has(actor.handle): origins[actor.handle]=actor.position
			if not roles.has(actor.handle): continue
			var role: String=roles[actor.handle]
			distances[role]=maxf(distances.get(role,0.0),actor.position.distance_to(origins[actor.handle]))
		digest.start(HashingContext.HASH_SHA256)
		digest.update(var_to_bytes([tick,report.value.actors,report.value.projectiles,events]))
		traces.append(digest.finish().hex_encode())
		if tick==last_tick: break
	if tick!=last_tick or shots<1 or total_damage<1 or (population==40 and hits_by_side.size()!=2): fail_check("contact "+str([tick,shots,total_damage,hits_by_side]));return
	for role in GOALS:
		if distances.get(role,0.0)<=2: fail_check("movement "+role);return
	var data:={"ticks":tick,"seed":241124,"hz":Engine.physics_ticks_per_second,"orders":orders,"max_distance_m":distances,
		"first_hostile_damage":first_hit,"positive_hostile_hits_by_side":hits_by_side,"total_hostile_damage":total_damage,
		"shots":shots,"checksums":traces}
	var file := FileAccess.open(OS.get_environment("RECOLLECTION_BEHAVIOR_PROOF"),FileAccess.WRITE)
	if file==null:fail_check("output");return
	file.store_string(JSON.stringify(data))
	file.close()
	print("NATIVE_REPLAY ",JSON.stringify({"calls":native_counter()-initial_calls,"steps":native_steps,"rollback_calls":rollback_calls,"retry_calls":retry_calls}))
	if native_steps<100 or rollback_calls<1 or retry_calls<1:
		fail_check("insufficient native participation or retry was not native");return
	print("PERF_Q PASS ticks=",tick," first_hit=",first_hit," shots=",shots," hostile_hits=",hits_by_side," damage=",total_damage," travel_m=",distances)
	app.shutdown()
	quit(0)
