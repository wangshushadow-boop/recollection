import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

here = Path(__file__).resolve().parent
repo = here.parents[1]
client = "D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"
label = sys.argv[1]
profile = here/"profile"
profile.mkdir(exist_ok=True)
env = dict(os.environ, APPDATA=str(profile),LOCALAPPDATA=str(profile))
suites = [
    ("field_brains",[]),
    ("formation",[]),("formation_transaction",[]),
    ("formation_ai_transaction",[]),("ai_transaction",[]),
    ("field_pipeline",["--mount","--brains=res://mission/runtime/field_brains.gd"]),
]
out=here/label
out.mkdir(exist_ok=True)
status={}
files=[]
for suite, extras in suites:
    path=out/(suite+".log")
    cmd=[client,"--headless","--fixed-fps","60","--path",str(repo/"game"),"--log-file",str(path),
         "--script","res://tests/p2/"+suite+"/run.gd"]
    if extras: cmd.extend(["--",*extras])
    p=subprocess.run(cmd,env=env,check=False,timeout=90,capture_output=True)
    text=p.stdout.decode("utf-8","replace")+p.stderr.decode("utf-8","replace")
    print(suite,p.returncode,text.splitlines()[-1:],flush=True)
    marker = "PASS" if suite in ["formation_transaction","formation_ai_transaction"] else "failures=0"
    status[suite]={"code":p.returncode, "ok":p.returncode==0 and marker in text and "SCRIPT ERROR:" not in text and "ERROR:" not in text,
            "command":cmd, "observed":text.splitlines()[-1:]}
    files.append(path)
    if not status[suite]["ok"]: sys.exit(1)

cmd=[sys.executable,str(here/"run.py"),label,str(repo/"game"),"--count","500","--against","baseline-reference"]
p=subprocess.run(cmd,check=False)
summary=json.loads((out/"summary.json").read_text())
status["battle_500"]=summary["comparison"]
assert summary["status"]=="PASS" and status["battle_500"]["same_ticks"]==1260 and p.returncode==0
paths=["game/mission/runtime/field_brains.gd","game/tests/p2/field_brains/run.gd","game/bootstrap/field_desktop.gd"]
status["source_sha256"]={s:hashlib.sha256((repo/s).read_bytes()).hexdigest() for s in paths}
status["reference"]="verified500 from 079c24e's field-flat-runtime QA archive"
(out/"QA.json").write_text(json.dumps(status,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
files += [here/f for f in ["verify.py","run.py","behavior.gd","baseline-focus.log","baseline-reference/summary.json","baseline-reference/behavior.json"]]
files += [out/f for f in ["QA.json","behavior.log","behavior.json","summary.json"]]
with zipfile.ZipFile(here/(label+".zip"),"w",compression=zipfile.ZIP_DEFLATED) as zf:
    for path in files: zf.write(path,path.relative_to(here))
    zf.write(repo/paths[1],paths[1])
