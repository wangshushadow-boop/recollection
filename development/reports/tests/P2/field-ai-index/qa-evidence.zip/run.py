"""Compare identical fixed-step inputs and exact per-tick game observations."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('project', type=Path)
parser.add_argument('--engine', type=Path, default=Path('D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe'))
parser.add_argument('--against')
parser.add_argument('--count', type=int, choices=(40,500), default=40)
parser.add_argument('--suites', action='store_true')
args = parser.parse_args()

project = args.project.resolve()
if not (project / 'project.godot').is_file():
    raise FileNotFoundError(project)
target = here / args.label
target.mkdir(exist_ok=True)
profile = target / 'profile'
profile.mkdir(exist_ok=True)
env = dict(os.environ, APPDATA=str(profile), LOCALAPPDATA=str(profile), RECOLLECTION_BEHAVIOR_PROOF=str(target/'behavior.json'))
env['RECOLLECTION_QA_COUNT'] = str(args.count)
env['RECOLLECTION_QA_GRAZE'] = str(target/'grazing.json')
summary = {'project':str(project),'label':args.label,'runs':{},'compare_to':args.against}
ok = True

scripts = [('behavior',str(here/'behavior.gd'))]
if args.count==40:
    scripts.append(('capture','res://tests/p2/field/capture.gd'))
if args.suites:
    scripts.extend((name, f'res://tests/p2/{name}/run.gd') for name in ['field_sweep_batch','field_engine','movement','motion_batch'])
    scripts.append(('grazing',str(here/'grazing.gd')))
for test_name, script in scripts:
    cmd = [str(args.engine), '--headless', '--fixed-fps','60','--path',str(project),'--log-file',str(target/f'{test_name}-engine.log'),'--script',script]
    result = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=150, cwd=target)
    (target/f'{test_name}.log').write_bytes(result.stdout)
    lines = result.stdout.decode('utf-8', errors='replace').splitlines()
    text = '\n'.join(lines)
    confirmed = result.returncode == 0 and 'SCRIPT ERROR:' not in text and 'ERROR:' not in text
    marker = {'behavior':'PERF_Q PASS', 'movement':'MOV_QUEUE_CHECKS errors=0'}.get(test_name, 'failures=0')
    confirmed = confirmed and marker in text
    record = {'command':cmd,'exit_code':result.returncode,'pass':confirmed,'last_lines':lines[-2:]}
    if test_name=='capture' and confirmed:
        record['outcome'] = json.loads(next(line for line in lines if line.startswith('NATURAL_CAPTURE ')).split(' ',1)[1])
    if test_name in ['field_sweep_batch','grazing'] and confirmed:
        record['transcript_sha256'] = lines[-1].split('replay_sha256=')[1].strip()
    summary['runs'][test_name] = record
    ok &= confirmed
    print(test_name, result.returncode, lines[-1:] or '[empty]')

if summary['runs']['behavior']['pass']:
    behavior = json.loads((target/'behavior.json').read_text(encoding='utf-8'))
    trace = behavior.pop('checksums')
    summary['behavior'] = behavior
    summary['trace_sha256'] = hashlib.sha256(('\n'.join(trace)+'\n').encode()).hexdigest()
    if args.against:
        ref_dir = here/args.against
        reference = json.loads((ref_dir/'behavior.json').read_text(encoding='utf-8'))
        old = reference.pop('checksums')
        compared = json.loads((ref_dir/'summary.json').read_text(encoding='utf-8'))
        matches = [a==b for a,b in zip(old,trace,strict=True)]
        comparison = {'ticks':len(matches),'same_ticks':sum(matches),'first_different_tick':next((i+1 for i,v in enumerate(matches) if not v),None),
            'orders_movement_damage_equal':reference==behavior}
        if args.count==40:
            comparison['natural_outcome_equal']=summary['runs']['capture'].get('outcome')==compared['runs']['capture'].get('outcome')
        if args.suites and 'field_sweep_batch' in compared['runs']:
            comparison['sweep_transcript_equal']=summary['runs']['field_sweep_batch'].get('transcript_sha256')==compared['runs']['field_sweep_batch'].get('transcript_sha256')
            comparison['grazing_transcript_equal']=summary['runs']['grazing'].get('transcript_sha256')==compared['runs']['grazing'].get('transcript_sha256')
        summary['comparison'] = comparison
        ok &= all(matches) and comparison['orders_movement_damage_equal'] and all(comparison.get(k,True) for k in ['natural_outcome_equal','sweep_transcript_equal','grazing_transcript_equal'])
        print(comparison)
summary['status'] = 'PASS' if ok else 'FAIL'
(target/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
sys.exit(0 if ok else 1)
