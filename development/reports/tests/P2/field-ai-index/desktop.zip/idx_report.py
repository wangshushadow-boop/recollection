import json,zipfile,statistics,subprocess
from pathlib import Path
from flat_stats import summarize
d=Path(__file__).resolve().parent
out=Path("development/reports/tests/P2/field-ai-index")
out.mkdir(parents=True,exist_ok=True)
groups={"base":["IdxA2","IdxA3","IdxA4"],"candidate":["IdxB2","IdxB3","IdxB4"],
        "base_probe":["IdxAd1","IdxAd2"],"candidate_probe":["IdxBd1","IdxBd2"]}
def read(names):
    paths=[d/(name+".json") for name in names]
    s=summarize(paths)
    # The inherited frame aggregator has a MOV-specific counter. This run measures AI.
    s.pop("scene_exact_per_step")
    work=[r[2]["index"] for p in paths for r in json.loads(p.read_text())["steps"] if 120<r[0]<=440 and "index" in r[2]]
    if work:
        s["units_per_step"]=statistics.mean(x[1] for x in work)
        s["index_form_lookups_per_step"]=statistics.mean(x[2] for x in work)
    assert s['frame_step_histogram']=={2:s["frame_samples"]}
    return s
summary={k:read(names) for k,names in groups.items()}
summary["runs"]={name:read([name]) for names in groups.values() for name in names}
summary["initial_runs"]={name:read([name]) for name in ["IdxA1","IdxB1"]}
with zipfile.ZipFile(out/"desktop.zip","w",zipfile.ZIP_DEFLATED) as z:
    for name in list(summary["runs"])+list(summary["initial_runs"]):
        for ext in ["json","log"]:
            f=d/f"{name}.{ext}"
            z.write(f,"raw/"+f.name)
    for name in ["prepare.py","idx_probe.py","idle.gd","flat_stats.py","idx_report.py"]:
        z.write(d/name,name)
    z.writestr("local-2-step.diff",subprocess.check_output(["git","diff","HEAD","--","game/bootstrap/field_desktop.gd"]))
    z.write(d/"Idx-integrated.log","qa/Idx-integrated.log")
(out/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
a,b,ap,bp=(summary[k] for k in groups)
def q(vals):
    return f"{vals[1]:.2f} / {vals[2]:.2f}"
def row(name,vals):
    vals=[f"{v:.2f}" if isinstance(v,float) else str(v) for v in vals]
    return f"| {name} | "+" | ".join(vals)+" |"
table="\n".join(["| 指标 | 修改前 | 修改后 |","|---|---:|---:|",
    row("索引阶段向 FORM 查询成员归属次数 / 步",[v["index_form_lookups_per_step"] for v in [ap,bp]]),
    row("索引阶段平均 ms / 步",[v["phases_ms"]["index"][0] for v in [ap,bp]]),
    row("索引阶段 P50 / P95（ms）",[q(v["phases_ms"]["index"]) for v in [ap,bp]]),
    row("完整 AI 思考平均 ms / 步",[v["phases_ms"]["_think"][0] for v in [ap,bp]]),
    row("完整战斗步平均 ms",[v["step_ms"][0] for v in [a,b]]),
    row("完整战斗步 P50 / P95（ms）",[q(v["step_ms"]) for v in [a,b]]),
    row("显示帧 P50 / P95（ms）",[q(v["frame_ms"]) for v in [a,b]]),
    row("平均 FPS",[v["fps"] for v in [a,b]]),
    row("现实每秒完成步数",[v["sps"] for v in [a,b]])])
print(table)
report=f"""# 单机河原野战 AI 编队成员索引

任务 P2-FIELD-INTEGRATION-023。基线 `079c24e`，候选 `f1bdb4e`，本地桌面客户端每帧最多补算 2 步。两版使用相同的 60 Hz 规则、画质、种子 241124、500 名士兵和 100 匹马。桌面从主菜单进入河原，部署 45 个显示帧后点击开始，玩家全程站立。

## 桌面实测

{table}

Godot 4.7.2 Standard、RTX 3090、Core Ultra 9 285K、960×600、Forward+。采集第 121–440 步，排除资源加载与部署。每版三轮，共 {a['step_samples']} 步。完全落在稳定段的显示帧为 {a['frame_samples']} 和 {b['frame_samples']} 帧，每帧均运行两步。按总墙钟时间计算 FPS 和现实步速。分位数取最近秩。轻量轮顺序 B2、A2、A3、B3、B4、A4，初次试跑 A1/B1 另列。分阶段计时来自每版额外两轮带相同探针的实机运行；探针同时计入完整索引阶段（含校验、动态汇总及 AI 名册发布或推进），每步末记录一次。每轮帧率见[分轮汇总](summary.json)，复跑材料及完整日志见[桌面证据包](desktop.zip)。

## 实现与行为

游戏修改集中在 `game/mission/runtime/field_brains.gd`。AI 每步依然读取编队权威视图，按组使用上次已提交的“兵员编号 → 代际”索引。修订号与成员快照同时匹配才能复用；成员关系变化时重建该编队。提交后才发布候选索引，回滚或拒绝步保留原索引。输入仍逐人校验，实际执行时的撤权、视野、目标、位置、生命、弹药、朝向、命中及步频沿用原有逻辑。

独立 QA 和主 Agent 在最终工作区均运行 `--headless --fixed-fps 60 --path game --script res://tests/p2/field_brains/run.gd`。针对旧代际、错类型、额外字段、重复句柄、转队、重排、撤权和回滚重试的专项前后各通过 1,337 项，均触发 5 个战术、55 个编队、80 个个体任务。编队、事务和真实野战流水线等其余五套回归也全部通过。500 人及 100 匹马的有指令野战与上一版已验证的逐步记录对比，1,260/1,260 步状态摘要相同，第 986 步首次命中，88 次发射、61 次正伤害、总伤害 2,112。[独立验收与原始记录](qa-evidence.zip)

本轮只验收河原 AI 名册优化。混战阶段帧率、1000 人性能、其他 GPU 和完整 P2 门禁本轮未测。30 FPS 目标尚未达成。

## 复跑

解压桌面证据包，分别准备已导入的基线和新版工程，并为两版应用随包的 `local-2-step.diff`。使用 `python prepare.py <label> <game目录>` 生成轻量计时副本。将 `RECOLLECTION_IDLE_CAPTURE` 指向输出 JSON，桌面启动参数为 `--path <label>/game --script <idle.gd绝对路径> -- --profile=client`。附加细采样先执行 `python idx_probe.py <label> <probe-label>`，再从新副本走同一入口。完整战斗步与帧时间可用 `flat_stats.py <原始JSON文件> ...` 复算。
"""
(out/"README.md").write_text(report,encoding="utf-8")
