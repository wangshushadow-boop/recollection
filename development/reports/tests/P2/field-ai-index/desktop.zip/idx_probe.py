"""Measure stable tick work in a disposable prepare.py project."""
import shutil, sys
from pathlib import Path
d=Path(__file__).resolve().parent
source, dest=sys.argv[1:]
root=d/dest/"game"
shutil.copytree(d/source/"game",root)
def change(rel,a,b):
    p=root/rel
    s=p.read_text(encoding="utf-8")
    assert s.count(a)==1,(rel,a)
    p.write_text(s.replace(a,b),encoding="utf-8")
form="mission/formation/ports/field_formation.gd"
change(form,"func member_formation(handle: Dictionary) -> Dictionary:","var bench_calls := 0\nfunc member_formation(handle: Dictionary) -> Dictionary:\n\tbench_calls += 1")
brains="mission/runtime/field_brains.gd"
anchor="func _index(tick: int,nav: int,units: Array) -> Dictionary:"
change(brains,anchor,anchor+'''
	var reads: int = _form.bench_calls
	var started := Time.get_ticks_usec()
	var result := _bench_index(tick,nav,units)
	Engine.get_main_loop().call("record_work","index",Time.get_ticks_usec()-started,units.size(),_form.bench_calls-reads)
	return result

func _bench_index(tick:int, nav:int, units:Array)->Dictionary:''')
pipe="mission/runtime/field_pipeline.gd"
for name in ["_think","_walk"]:
    anchor=f"func {name}(_ctx: Dictionary, batch: Dictionary) -> Dictionary:"
    change(pipe,anchor,anchor+f'''
	var started := Time.get_ticks_usec()
	var result := _bench{name}(_ctx,batch)
	Engine.get_main_loop().call("record_work","{name}",Time.get_ticks_usec()-started,_draft.humans.size(),0)
	return result

func _bench{name}(_ctx: Dictionary, batch: Dictionary) -> Dictionary:''')
