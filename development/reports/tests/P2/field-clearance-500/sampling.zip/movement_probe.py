"""Insert tick-local timing/work counters in an isolated source tree. No production changes."""
from pathlib import Path
import sys


def edit(root):
    def patch(file, pairs):
        path = root / file
        source = path.read_text(encoding="utf-8")
        for old, new in pairs:
            if source.count(old) != 1:
                raise ValueError(f"{file}: expected unique {old!r}")
            source = source.replace(old, new)
        path.write_text(source, encoding="utf-8")

    def emit(key, timer, entities, work):
        return f'Engine.get_main_loop().call("record_work","{key}",Time.get_ticks_usec()-{timer},{entities},{work})'

    start = "var diag_at := Time.get_ticks_usec()"
    again = "diag_at = Time.get_ticks_usec()"
    def step_before(anchor, key, entities, work, indent=1):
        tab = "\t" * indent
        return (tab + anchor, tab + emit(key, "diag_at", entities, work) + "\n" + tab + again + "\n" + tab + anchor)

    patch("mission/movement/ports/field_movement.gd", [
        ("var _checks := 0", "var _checks := 0\nvar _probe_clear_us := 0\nvar _probe_clear_calls := 0\nvar _probe_drivers := 0\nvar _probe_exact := 0\nvar _probe_broad := 0"),
        ("var hits: Dictionary = _engine.query_sweep_batch(queries,", "_probe_broad += queries.size()\n\tvar hits: Dictionary = _engine.query_sweep_batch(queries,"),
        ("var hits: Dictionary = _engine.query_sweep_batch(requests,", "_probe_exact += requests.size()\n\tvar hits: Dictionary = _engine.query_sweep_batch(requests,"),
        ("var request: Dictionary = _direct.request_drive_path", "_probe_drivers += 1\n\t\tvar request: Dictionary = _direct.request_drive_path"),
        ("func _scene_clearances(tick: int, dt: float) -> Dictionary:\n\tvar broad", "func _scene_clearances(tick: int, dt: float) -> Dictionary:\n\t"+start+"\n\tvar broad"),
        ("\tif not broad.ok: return broad\n\tvar requests", "\tif not broad.ok: return broad\n\t"+emit("mov.scene_broad","diag_at","_drivers.size()","_probe_broad")+"\n\t"+again+"\n\tvar requests"),
        ("\tif requests.is_empty(): return R.ok()\n\t# A door", "\t"+emit("mov.scene_build","diag_at","_drivers.size()","requests.size()")+"\n\tif requests.is_empty(): return R.ok()\n\t"+again+"\n\t# A door"),
        ("\tif not hits.ok: return hits\n\tfor hit in hits.value:", "\tif not hits.ok: return hits\n\t"+emit("mov.scene_query","diag_at","actors.size()","hits.value.size()")+"\n\t"+again+"\n\tfor hit in hits.value:"),
        ("\treturn R.ok()\n\n# Admission to a shared corridor", "\t"+emit("mov.scene_apply","diag_at","actors.size()","hits.value.size()")+"\n\treturn R.ok()\n\n# Admission to a shared corridor"),
        ("\tvar ready := _prepare(tick)", "\t"+start+"\n\tvar diag_total := diag_at\n\t_probe_clear_us = 0\n\t_probe_clear_calls = 0\n\t_probe_exact = 0\n\t_probe_broad = 0\n\t_probe_drivers = 0\n\tvar ready := _prepare(tick)"),
        step_before("var joins := _members(tick,", "mov.navigation", "_routes.size()", "_queue.attempts_at(tick)"),
        ("\tvar joins := _members(tick,", "\tvar diag_examined := 0 if _members_ready else _bodies.size()\n\tvar joins := _members(tick,"),
        ("\tif not joins.ok:\n\t\treturn joins", "\tif not joins.ok:\n\t\treturn joins\n\t"+emit("mov.join","diag_at","diag_examined","_access.attempts_at(tick)")+"\n\t"+again),
        step_before("var clearances := _scene_clearances(tick,dt)", "mov.driver_paths", "_drivers.size()", "_probe_drivers", 2),
        ("\t\tif not clearances.ok: return clearances", "\t\tif not clearances.ok: return clearances\n\t\t"+emit("mov.scene_clearance","diag_at","_drivers.size()","_probe_exact+_probe_broad")+"\n\t"+again),
        ("\t_prepare_grid(bodies)\n\tif not _had_drives", "\tvar diag_grid := bodies.size() if not is_same(_cells_lineup,_lineup) else _unsorted_cells.size()\n\t_prepare_grid(bodies)\n\t"+emit("mov.grid","diag_at","bodies.size()","diag_grid")+"\n\t"+again+"\n\tif not _had_drives"),
        ("\tvar shared: int = _queue.attempts_at(tick)", "\t"+emit("mov.advance","diag_at","bodies.size()","_checks")+'\n\tEngine.get_main_loop().call("record_work","mov.clear_step",_probe_clear_us,_probe_clear_calls,_checks)\n\t'+emit("mov.run_step","diag_total","bodies.size()","_yields")+"\n\tvar shared: int = _queue.attempts_at(tick)"),
        ("func _clear_step(b: Body, candidate: Vector3) -> bool:", 'func _clear_step(b: Body, candidate: Vector3) -> bool:\n\tvar t := Time.get_ticks_usec()\n\tvar clear := _probe_clear_step(b,candidate)\n\t_probe_clear_us += Time.get_ticks_usec()-t\n\t_probe_clear_calls += 1\n\treturn clear\n\nfunc _probe_clear_step(b: Body, candidate: Vector3) -> bool:'),
    ])
    patch("mission/runtime/field_pipeline.gd", [
        ("func _walk(_ctx: Dictionary, batch: Dictionary) -> Dictionary:\n", "func _walk(_ctx: Dictionary, batch: Dictionary) -> Dictionary:\n\t"+start+"\n"),
        step_before("var walk: Dictionary = _move.stage_step", "walk.inputs", "_draft.moves.size()+_draft.ai_moves.size()", "_draft.move_receipts.size()"),
        ("\tvar moved_poses:Dictionary=", "\t"+again+"\n\tvar moved_poses:Dictionary="),
        step_before("var physical := []", "walk.read_poses", "_draft.humans.size()", "moved_poses.value.positions.size()"),
        step_before("var stage: Dictionary = _engine.field_stage_bodies", "walk.pack_bodies", "_draft.roster.size()", "physical.size()"),
    ])
    patch("infrastructure/engine/field_bodies.gd", [
        ("func stage(rows: Array) -> Dictionary:\n", "func stage(rows: Array) -> Dictionary:\n\t"+start+"\n\tvar diag_changed := 0\n"),
        ("\t\tnext[h.index] = {\"handle\":owned", "\t\tdiag_changed += 1\n\t\tnext[h.index] = {\"handle\":owned"),
        ("\t_sync(next)\n", "\t"+emit("phys.validate_rows","diag_at","rows.size()","diag_changed")+"\n\t_sync(next)\n"),
        ("func _sync(next: Dictionary) -> void:\n", "func _sync(next: Dictionary) -> void:\n\t"+start+"\n\tvar diag_writes := 0\n"),
        ("\t\t_place(index,row)\n\t_current = next", "\t\t_place(index,row)\n\t\tdiag_writes += 1\n\t"+emit("phys.sync","diag_at","next.size()","diag_writes")+"\n\t_current = next"),
    ])


if __name__ == "__main__":
    root = Path(sys.argv[1]).resolve()
    if root == (Path(__file__).resolve().parents[2] / "game").resolve():
        raise SystemExit("Pass an isolated game directory")
    edit(root)
