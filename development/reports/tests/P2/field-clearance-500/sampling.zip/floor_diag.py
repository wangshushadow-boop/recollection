from pathlib import Path
import sys
root=Path(sys.argv[1])
def change(rel,func):
 p=root/rel;s=p.read_text(encoding='utf-8');p.write_text(func(s),encoding='utf-8')
def only(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def pipe(s):
 s=only(s,'func _walk(_ctx: Dictionary, batch: Dictionary) -> Dictionary:\n','func _walk(_ctx: Dictionary, batch: Dictionary) -> Dictionary:\n\tvar probe_walk_start := Time.get_ticks_usec()\n')
 s=only(s,'\t_draft["physical"]=physical','\tEngine.get_main_loop().call("record_work","walk.total",Time.get_ticks_usec()-probe_walk_start,_draft.humans.size(),physical.size())\n\t_draft["physical"]=physical')
 s=only(s,'\tvar mounted:=_apply_mount_requests(batch.source_tick)','\t_form.probe_copies=true\n\t_form.probe_us=0\n\t_form.probe_calls=0\n\t_form.probe_rows=0\n\tvar mounted:=_apply_mount_requests(batch.source_tick)')
 s=only(s,'\treturn R.ok()\n\nfunc _mount_target','\t_form.probe_copies=false\n\tEngine.get_main_loop().call("record_work","ai.member_copies",_form.probe_us,_form.probe_calls,_form.probe_rows)\n\treturn R.ok()\n\nfunc _mount_target')
 return s
change('mission/runtime/field_pipeline.gd',pipe)
def formation(s):
 s=only(s,'func view(id: int) -> Dictionary:', 'var probe_copies:=false\nvar probe_us:=0\nvar probe_calls:=0\nvar probe_rows:=0\n\nfunc view(id: int) -> Dictionary:')
 s=only(s,'\tvar out := {"id":id, "team_key":g.team_key','\tvar t := Time.get_ticks_usec() if probe_copies else 0\n\tvar members: Array=g.members.duplicate(true)\n\tif probe_copies:\n\t\tprobe_us+=Time.get_ticks_usec()-t\n\t\tprobe_calls+=1\n\t\tprobe_rows+=members.size()\n\tvar out := {"id":id, "team_key":g.team_key')
 return only(s,'"members":g.members.duplicate(true), "members_revision"', '"members":members, "members_revision"')
change('mission/formation/ports/field_formation.gd',formation)
def mov(s):
 return only(s,'\tcells.clear()\n\tfor hit in hits.value:', '''	var count_ground:=0
	for hit in hits.value:
		if hit.region=="ground":count_ground+=1
	Engine.get_main_loop().call("record_work","mov.broad_ground_hits",0,hits.value.size(),count_ground)
	cells.clear()
	for hit in hits.value:''')
change('mission/movement/ports/field_movement.gd',mov)
if '--flat-fixture-only' in sys.argv:
 change('mission/movement/ports/field_movement.gd',lambda s:only(s,'\t\tcells[keys[hit.query_index]] = true','\t\tif hit.region == "ground": continue # Flat river fixture only.\n\t\tcells[keys[hit.query_index]] = true'))
