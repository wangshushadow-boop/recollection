from pathlib import Path
import csv,json,math,statistics as st,sys
from stats import p,stats
d=Path(__file__).resolve().parent
out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True)
def data(name):return json.loads((d/(name+'.json')).read_text(encoding='utf-8'))
def pooled(names):
 ticks=[]; frames=[]; n=0
 for name in names:
  run=data(name)
  ticks.extend(s[1]/1000 for s in run['steps'] if 120<s[0]<=440)
  for last,f in zip(run['frames'],run['frames'][1:]):
   if f['phase']=='battle' and last['tick']>=120 and f['tick']<=440:
    frames.append(f['us']/1000);n+=f['tick']-last['tick']
 return dict(step_mean=st.mean(ticks),step50=p(ticks,.5),step95=p(ticks,.95),frame50=p(frames,.5),frame95=p(frames,.95),fps=1000*len(frames)/sum(frames),sps=n*1000/sum(frames),steps=len(ticks),frames=len(frames),frame_steps=n)
names=[key+str(i) for key in ['A','B'] for i in range(1,7)]
summary={'baseline':pooled(names[:6]),'candidate':pooled(names[6:]),'runs':{key:stats(key)['metrics'] for key in ['T1','AC1','AC2','AC3','C1','C2','C3']+names},'source_base':'0e7fef8','candidate_queries_sha256':'a05e79b963d5bc296844f80b80feec28b40db770bec9eacc9e18eb679d2e315f','rejected':'C1-C3 failed the grazing contact regression'}
summary['subphases']={key:stats(key)['phases'] for key in ['walkA','walkB','floor-only']}
summary['same_requests']=stats('same-keep')['phases']
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
keys=sorted(summary['subphases']['walkA'])
spec="""ai.member_copies|AI 期间完整编队读取次数|深拷贝的成员句柄数
mov.broad_ground_hits|粗筛返回的命中行|地面标记命中数
walk.total|处理兵员|提交物理代理行
mov.navigation|走廊数|共享寻路次数
mov.join|成员路径阶段检查的在册人数（名单就绪时为零）|成员寻路次数
mov.driver_paths|当前有直接控制的兵员|提交的路径请求
mov.scene_broad|当前有直接控制的兵员|粗球扫条数
mov.scene_build|当前有直接控制的兵员|构造的精确球扫条数
mov.scene_query|精扫条数|引擎返回的命中行
mov.scene_apply|精扫条数|应用的命中行
mov.scene_clearance|有直接控制的兵员|粗扫＋精扫条数
mov.grid|在册兵员|重建时登记的兵员或增量排序的格子
mov.advance|运动更新兵员|邻居检查次数（含重复考察）
mov.clear_step|尝试前进或侧让次数|同一批邻居检查次数
mov.run_step|运动更新兵员|让行次数
walk.inputs|玩家与 AI 移动意图|AI 移动回执
walk.read_poses|人类兵员|返回的位置
walk.pack_bodies|含马的名册行|碰撞代理输入行
phys.validate_rows|送检的碰撞行|状态变化行数
phys.sync|当前物理代理|实际设置 body.transform 的次数
ai.think|兵员|本步完成的个体任务
ai.mount_requests|记录的交互|本步记录的交互数
ai.formation_slots|编队|返回的槽位目标（含缓存）
ai.read_poses|兵员|位置返回数
ai.read_combat|兵员|返回的战斗状态数
ai.assemble_units|兵员|构造的 AI 行数
ai.decide|在册兵员|已完成的个体任务数
ai.apply_intents|决策个体|动作、移动及朝向意图
ai.index_members|兵员|建立索引的编队
ai.publish_perception|位置数|生命、弹药或士气变化数
ai.schedule|在册兵员|调度任务数
ai.tactical|阵营|实际战术任务
ai.formation_jobs|编队|实际编队任务
ai.individual_jobs|被调度并成功决策的个体|提交的个体提案
ai.individual_decide|成功个体决策次数|生成意图数
ai.individual_collect|成功个体收集次数|提交意图数
ai.collect_intents|通过的个体批次|动作、移动和朝向意图
ai.sense_scan|真实感知调用次数（含侦察）|扫描过的候选条目（含友军）
ai.los|感知调用数（含侦察）|实际可见性射线
ai.target_eval|调用目标选择次数|遍历的可见敌方候选
ai.acquired_enemy|确认的个体批次|无目标变为有目标
ai.lost_enemy|确认的个体批次|有目标变为无目标
ai.switched_enemy|确认的个体批次|同一个体更换敌方目标"""
desc={r.split('|')[0]:r.split('|')[1:] for r in spec.splitlines()}
if set(keys)!=set(desc): print('key difference',set(keys)^set(desc))
with (out/'stages.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['版本','子阶段','每步平均ms','每步P50_ms','每步P95_ms','处理对象定义','每步平均对象数','工作量定义','每步平均工作量'])
 for label in ['walkA','walkB','floor-only']:
  steps=[r for r in data(label)['steps'] if 120<r[0]<=440]
  for k in keys:
   rows=[r[2].get(k,[0,0,0]) for r in steps]; ms=[r[0]/1000 for r in rows]
   pure=k in ('ai.acquired_enemy','ai.lost_enemy','ai.switched_enemy','mov.broad_ground_hits')
   e,u=desc.get(k,['',''])
   w.writerow([label,k,*(['','',''] if pure else [round(st.mean(ms),5),p(ms,.5),p(ms,.95)]),e,st.mean(r[1] for r in rows),u,st.mean(r[2] for r in rows)])
print(json.dumps({k:summary[k] for k in ['baseline','candidate']}))
