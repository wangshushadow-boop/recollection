from pathlib import Path
import shutil,sys
here=Path(__file__).resolve().parent
root=here/sys.argv[2]/'game'
shutil.copytree(here/sys.argv[1]/'game',root)
engine=root/'infrastructure/engine'
shutil.copyfile(here/'base/game/infrastructure/engine/queries.gd',engine/'diag_baseline_queries.gd')
p=engine/'adapter.gd';s=p.read_text(encoding='utf-8')
s=s.replace('const FieldBodies =','const BaselineQueries = preload("res://infrastructure/engine/diag_baseline_queries.gd")\nconst FieldBodies =',1)
needle='\treturn Queries.sweep(_scopes[stamp.scope_id],queries,field)'
assert s.count(needle)==1
s=s.replace(needle,'''	if not field and stamp.tick>120 and stamp.tick<=440 and queries.size()>=64 and queries[0].get("mask")== (0xffffffff ^ 2 ^ (1 << 29)):
		var scope: Dictionary = _scopes[stamp.scope_id]
		var old: Dictionary
		var candidate: Dictionary
		var t0 := Time.get_ticks_usec()
		var old_us: int
		var new_us: int
		if stamp.tick%2==0:
			old = BaselineQueries.sweep(scope,queries,false)
			var t1 := Time.get_ticks_usec()
			candidate = Queries.sweep(scope,queries,false)
			new_us = Time.get_ticks_usec()-t1
			old_us = t1-t0
		else:
			candidate = Queries.sweep(scope,queries,false)
			var t1 := Time.get_ticks_usec()
			old = BaselineQueries.sweep(scope,queries,false)
			old_us = Time.get_ticks_usec()-t1
			new_us = t1-t0
		var loop := Engine.get_main_loop()
		loop.call("record_work","paired.baseline",old_us,queries.size(),int(old!=candidate))
		loop.call("record_work","paired.candidate",new_us,queries.size(),int(old!=candidate))
		if candidate!=old: return R.fail("Conflict","paired.sweep")
		return candidate
'''+needle)
p.write_text(s,encoding='utf-8')
