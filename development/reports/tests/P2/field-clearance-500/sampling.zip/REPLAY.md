Unzip into a new working directory. Use Godot 4.7.2 Standard, Windows and the base game from git archive 0e7fef8. Import that clean project with Godot --headless --path <game> --import before making measured copies. For B copy B/queries.gd over infrastructure/engine/queries.gd in a separate base project with the same imports. The archived C is a rejected candidate.

In PowerShell, from the unzipped directory (example A):

```powershell
python prepare.py replayA D:/checks/A/game
$env:APPDATA = (New-Item -Force -ItemType Directory sample-user).FullName
$env:LOCALAPPDATA = $env:APPDATA
$env:RECOLLECTION_IDLE_CAPTURE = Join-Path (Get-Location) 'replay-A.json'
& 'D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe' --path replayA/game --script (Resolve-Path idle.gd) -- --profile=client
python stats.py replay-A
```

Repeat for B, alternating order across processes. Use prepare.py <label> <source-game> --detail then python floor_diag.py <label>/game to reproduce all per-tick counters in walkA/walkB. floor_diag.py --flat-fixture-only takes effect only in an isolated project and deliberately ignores all tagged ground for the floor-only estimate; invoke as python floor_diag.py <label>/game --flat-fixture-only. Never use this option for a shipping build.

Raw A1..A6 and B1..B6 are the lightweight display benchmark. AC1..AC3/C1..C3 cover the rejected candidate. The paired diagnostic uses folders base/game and a second prepared project: python paired.py <second-label> <new-paired-label>. Run idle.gd with that new project to alternate query ordering inside each tick. See same-keep.json for the accepted candidate. Work is accumulated per fixed step, written after the run. Physics evidence is in the separate QA archives.
