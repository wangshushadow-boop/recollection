"""Instrument a disposable game directory; emit one record per stage per fixed step."""
import sys
from pathlib import Path


def replace(s, old, new):
    if s.count(old) != 1:
        raise ValueError(f"Expected one matching site: {old!r}")
    return s.replace(old, new)


def mark(key, entities, work, elapsed="Time.get_ticks_usec()-probe_t"):
    return f'\tEngine.get_main_loop().call("record_work","ai.{key}",{elapsed},{entities},{work})\n'


def segment(s, start, stop, key, entities, work):
    s = replace(s, start, "\tprobe_t=Time.get_ticks_usec()\n" + start)
    return replace(s, stop, mark(key, entities, work) + stop)


def prepare(root):
    pipeline = root / "mission/runtime/field_pipeline.gd"
    brains = root / "mission/runtime/field_brains.gd"
    individual = root / "mission/ai/individual/ports/field_individual.gd"
    ai = root / "mission/ai/ports/field_ai.gd"
    p = pipeline.read_text(encoding="utf-8")
    b = brains.read_text(encoding="utf-8")
    i = individual.read_text(encoding="utf-8")
    a = ai.read_text(encoding="utf-8")
    p = replace(p, "\tvar mounted:=_apply_mount_requests(batch.source_tick)",
                "\tvar probe_t:=0\n\tvar mounted:=_apply_mount_requests(batch.source_tick)")
    p = segment(p, "\tvar targets := _formations()", "\tif not targets.ok: return targets",
                "formation_slots", "_draft.groups.size()", "targets.get('value',{}).size()")
    p = segment(p, "\tvar prior:Dictionary=_move.read_poses", "\tif not prior.ok:return prior",
                "read_poses", "_draft.humans.size()", "prior.get('value',{}).get('positions',[]).size()")
    p = segment(p, "\tvar state:Dictionary=_draft.com.field_view", "\tif not state.ok:return state\n\t_draft[",
                "read_combat", "_draft.humans.size()", "state.get('value',{}).get('actors',[]).size()")
    p = segment(p, "\tvar units := []\n\tfor i in _draft.humans.size():", "\tvar player: Variant = _draft.player if",
                "assemble_units", "_draft.humans.size()", "units.size()")
    p = segment(p, "\tvar decision: Dictionary = _brains.decide", "\tif not decision.ok: return decision",
                "decide", "units.size()", "decision.get('value',{}).get('metrics',{}).get('individual',0)")
    p = segment(p, '\t_draft["ai"]=decision.value.actions', '\treturn R.ok()\n\nfunc _mount_target',
                "apply_intents", "decision.value.metrics.individual", "decision.value.actions.size()+decision.value.moves.size()+decision.value.looks.size()")

    b = replace(b, "\tvar identity := []", "\tvar probe_t:=0\n\tvar identity := []")
    b = segment(b, "\tfor row in units:", "\tvar read: Dictionary\n",
                "index_members", "units.size()", "_groups.size()")
    b = segment(b, "\tif _roster.is_empty() or identity!=_identity:", "\t_vitals = vitals",
                "publish_perception", "positions.size()", "changes.size()")
    b = replace(b, "\tvar scheduled: Dictionary = _ai.schedule()", "\tvar probe_t:=0\n\tvar scheduled: Dictionary = _ai.schedule()")
    b = segment(b, "\tvar scheduled: Dictionary = _ai.schedule()", "\tvar jobs: Array = scheduled.value.jobs",
                "schedule", "_units.size()", "scheduled.value.jobs.size()")
    b = segment(b, '\tfor job in jobs:\n\t\tif job.layer!="tactical"', "\tvar tasks := {}",
                "tactical", "_teams.size()", "metrics.tactical")
    b = segment(b, "\tvar tasks := {}", "\tvar states := {}",
                "formation_jobs", "_groups.size()", "metrics.formation")
    b = segment(b, "\tvar states := {}", "\tif not _path_error.is_empty(): return _path_error",
                "individual_jobs", "metrics.individual", "proposals.size()")
    b = segment(b, "\tdrained = _ai.drain()", "\t_action_count = actions.size()",
                "collect_intents", "drained.value.size()", "actions.size()+moves.size()+looks.size()")
    # Fresh _draft is constructed on every decide() via fork(). Detailed counters live
    # there, not on live simulation state. Do not cross the SceneTree boundary per actor.
    i = replace(i, "var _mission: String", """var probe_target_calls := 0
var probe_decision_us := 0
var probe_collect_us := 0
var probe_intents := 0
var probe_target_us := 0
var probe_candidates := 0
var probe_changed := 0
var probe_acquired := 0
var probe_lost := 0
var _mission: String""")
    i = replace(i, "\t\ttarget = _target(perception,rules,local,old,tick)", """		var probe_start := Time.get_ticks_usec()
		target = _target(perception,rules,local,old,tick)
		probe_target_us += Time.get_ticks_usec()-probe_start
		probe_target_calls += 1
		probe_candidates += perception.visible_enemies.size()""")
    i = replace(i, "\t_members[job.subject.index] = next", """	var prev_target: Variant = previous.get("target") if previous.get("handle")==job.subject else null
	var next_target: Variant = next.target
	if prev_target != next_target:
		if prev_target==null: probe_acquired+=1
		elif next_target==null: probe_lost+=1
		else: probe_changed+=1
	_members[job.subject.index] = next""")
    a = replace(a, "func sense(handle: Dictionary,", """var probe_sense_us := 0
var probe_sense_calls := 0

func sense(handle: Dictionary,""")
    a = replace(a, '\tvar result: Dictionary = _board.sense(own.value,radius,limit,_stamp("individual",handle),_los)',
                """	var probe_stamp := _stamp("individual",handle)
	var probe_t := Time.get_ticks_usec()
	var result: Dictionary = _board.sense(own.value,radius,limit,probe_stamp,_los)
	probe_sense_us += Time.get_ticks_usec()-probe_t
	probe_sense_calls += 1""")
    b = replace(b, "\tvar computed := R.ok()", "\t_ai.probe_sense_us = 0\n\t_ai.probe_sense_calls = 0\n\tvar computed := R.ok()")
    b = replace(b, "\tvar decision: Dictionary = _draft.decide(job", "\tvar probe_ind := Time.get_ticks_usec()\n\tvar decision: Dictionary = _draft.decide(job")
    b = replace(b, "\tif not decision.ok: return decision", "\t_draft.probe_decision_us += Time.get_ticks_usec()-probe_ind\n\tif not decision.ok: return decision")
    b = replace(b, "\tvar admitted: Dictionary = _ai.collect(job,decision.value.intents)",
                """	probe_ind = Time.get_ticks_usec()
	var admitted: Dictionary = _ai.collect(job,decision.value.intents)
	_draft.probe_collect_us += Time.get_ticks_usec()-probe_ind
	_draft.probe_intents += decision.value.intents.size()""")
    b = replace(b, "\t_accepted = true", "".join([
        mark("target_eval", "_draft.probe_target_calls", "_draft.probe_candidates", "_draft.probe_target_us"),
        mark("switched_enemy", "_pending.size()", "_draft.probe_changed", "0"),
        mark("acquired_enemy", "_pending.size()", "_draft.probe_acquired", "0"),
        mark("lost_enemy", "_pending.size()", "_draft.probe_lost", "0"),
        "\tvar probe_sense: Dictionary = _ai.metrics()\n",
        mark("sense_scan", "_ai.probe_sense_calls", "probe_sense.examined", "_ai.probe_sense_us"),
        mark("los", "_ai.probe_sense_calls", "probe_sense.rays", "probe_sense.los_us"),
        mark("individual_decide", "_pending.size()", "_draft.probe_intents", "_draft.probe_decision_us"),
        mark("individual_collect", "_pending.size()", "_draft.probe_intents", "_draft.probe_collect_us"),
        "\t_accepted = true"]))
    p = replace(p, "var probe_t:=0\n\tvar mounted:=_apply_mount_requests", "var probe_whole_think:=Time.get_ticks_usec()\n\tvar probe_t:=probe_whole_think\n\tvar mounted:=_apply_mount_requests")
    p = replace(p, "\tif not mounted.ok:return mounted", mark("mount_requests", "_draft.get('interactions',[]).size()", "_draft.get('interactions',[]).size()") + "\tif not mounted.ok:return mounted")
    p = replace(p, "\treturn R.ok()\n\nfunc _mount_target", mark("think", "units.size()", "decision.value.metrics.individual", "Time.get_ticks_usec()-probe_whole_think") + "\treturn R.ok()\n\nfunc _mount_target")
    return {pipeline: p, brains: b, individual: i, ai: a}


if __name__ == "__main__":
    project = Path(sys.argv[1]).resolve()
    if project == (Path(__file__).resolve().parents[2] / "game").resolve():
        raise ValueError("Refusing to instrument the working project")
    for file, contents in prepare(project).items():
        file.write_text(contents, encoding="utf-8")
