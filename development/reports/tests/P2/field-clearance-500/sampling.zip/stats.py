from pathlib import Path
import json,statistics as st,math,sys
d=Path(__file__).parent
def p(xs,k):return sorted(xs)[math.ceil(k*len(xs))-1]
def stats(name):
 a=json.loads((d/(name+'.json')).read_text())
 steps=[r for r in a['steps'] if 120<r[0]<=440]
 assert [r[0] for r in steps]==list(range(121,441))
 assert a['window_size']=='(960, 600)' and sum(a['visible_roles_at_end'].values())==600
 frames=[(f,f['tick']-prev['tick']) for prev,f in zip(a['frames'],a['frames'][1:]) if f['phase']=='battle' and prev['tick']>=120 and f['tick']<=440]
 ms=[f['us']/1000 for f,_ in frames]; steps_ms=[r[1]/1000 for r in steps]
 keys=sorted(set().union(*(r[2] for r in steps)))
 phases={k:[round(st.mean((r[2].get(k) or [0,0,0])[i] for r in steps)/(1000 if i==0 else 1),4) for i in range(3)] for k in keys}
 metrics=dict(steps=len(steps),frames=len(frames),wall_frames_ms=sum(ms),frame_steps=sum(n for _,n in frames),step_mean=st.mean(steps_ms),step50=p(steps_ms,.5),step95=p(steps_ms,.95),frame50=p(ms,.5),frame95=p(ms,.95),fps=1000/st.mean(ms),sps=1000*sum(n for _,n in frames)/sum(ms))
 return {'metrics':metrics,'phases':phases}
if __name__=='__main__':
 for name in sys.argv[1:]:
  result=stats(name)
  print(name,result['metrics'])
  for k,v in result['phases'].items(): print(k,*v)
