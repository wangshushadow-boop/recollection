from pathlib import Path
import json,statistics,hashlib,shutil,zipfile,re
r=Path('out/field-perf2')
d=Path('development/reports/tests/P2/field-clearance-500')
for n,h in [('qa-evidence.zip','b5ab315a17c274e3c7fd6b57802529f7ad88459927d032b9450106ec7a73cf16'),('locomotion-evidence.zip','1d1cd929c90cc51796bcf1103e6f03b3ad11bbd1588f357098f12ff35549545f')]:
 assert hashlib.sha256((r/'qa'/n).read_bytes()).hexdigest()==h
 shutil.copyfile(r/'qa'/n,d/n)
shutil.copyfile(r/'qa'/'qa-report.md',d/'qa-report.md')
q='game/infrastructure/engine/queries.gd'
assert hashlib.sha256(Path(q).read_bytes()).hexdigest()=='a05e79b963d5bc296844f80b80feec28b40db770bec9eacc9e18eb679d2e315f'
summary=json.loads((d/'summary.json').read_text())
entry={}
for prefix in ['A','B']:
 vals=[]
 for i in range(1,7):
  j=json.loads((r/f'{prefix}{i}.json').read_text());vals.append(max(f['us']/1000 for f in j['frames'] if f['phase']=='entry'))
 entry[prefix]=vals
print('entry',entry)
summary['entry_longest_frame_ms_per_run']=entry
summary['_detailed_rows']='Detailed runs use in-process counters. Pure counts have no independent duration in stages.csv.'
summary['step_columns']=['tick','authority_microseconds','stage_triplets: elapsed_microseconds / entities / workload']
summary['fixture_only_desktop']={key:__import__('stats').stats(key)['metrics'] for key in ['walkA','walkB','floor-only']}
(d/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(d/'sampling.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in sorted(r.glob('*')):
  if f.is_file() and f.suffix in ('.json','.log','.py','.md','.gd'):z.write(f,f.name)
 for variant,folder in [('A','base'),('B','opt'),('C','final'),('first-experiment','trial')]:
  z.write(r/folder/q,variant+'/queries.gd')
for z in d.glob('*.zip'):
 with zipfile.ZipFile(z) as f:assert f.testzip() is None;print(z.name,len(f.namelist()))
for md in d.glob('*.md'):
 for l in re.findall(r'\[[^\]]+\]\(([^)]+)\)',md.read_text(encoding='utf-8')):
  if '://' not in l:assert (md.parent/l).is_file(),l
