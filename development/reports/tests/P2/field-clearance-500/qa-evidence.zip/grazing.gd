extends SceneTree
const Queries = preload("res://infrastructure/engine/queries.gd")
var scope := {}
var fixtures := []
var overlap := 0
var outside := 0
var mismatches := 0

func place_shape(shape: Shape3D, at: Vector3, angle: float, name_key: String, local_face: Vector3) -> void:
	var body := StaticBody3D.new()
	var collider := CollisionShape3D.new()
	collider.shape=shape
	body.add_child(collider)
	body.set_meta("entity_handle",name_key)
	body.position=at
	body.rotation.z=angle
	scope.view.add_child(body)
	body.force_update_transform()
	fixtures.append([body.global_transform*local_face,body.global_transform.basis.y.normalized()])

func _initialize() -> void:
	run.call_deferred()

func run() -> void:
	print("QA_PHYSICS singleton_class=",PhysicsServer3D.get_class()," project_engine=",ProjectSettings.get_setting("physics/3d/physics_engine")," version=",Engine.get_version_info())
	var viewport:=SubViewport.new()
	viewport.world_3d=World3D.new()
	root.add_child(viewport)
	scope={"view":viewport}
	var box:=BoxShape3D.new()
	box.size=Vector3(4,.02,4)
	place_shape(box,Vector3.ZERO,0.0,"plate",Vector3.UP*.01)
	place_shape(box,Vector3(10,0,0),0.361,"slope",Vector3.UP*.01)
	var triangle:=ConcavePolygonShape3D.new()
	triangle.set_faces(PackedVector3Array([Vector3(-3,0,-3),Vector3(3,0,-3),Vector3(0,0,3)]))
	place_shape(triangle,Vector3(20,0,0),0.0,"single_face",Vector3.ZERO)
	var ball:=SphereShape3D.new()
	ball.radius=0.83
	place_shape(ball,Vector3(30,0,0),0.0,"round",Vector3.UP*.83)
	await physics_frame
	await physics_frame
	var space: PhysicsDirectSpaceState3D=viewport.world_3d.direct_space_state
	var sweeps: Array=[]
	for fixture in fixtures:
		for radius_mm in [1,6,40,280,470,1200]:
			var sphere:=SphereShape3D.new()
			sphere.radius=radius_mm*.001
			var q:=PhysicsShapeQueryParameters3D.new()
			q.shape=sphere
			q.collision_mask=1
			for side in [-1,1]:
				for micro in [-4000,-1000,-500,-100,-50,-10,-1,0,1,10,50,100,500,1000,4000]:
					var pos:Vector3=fixture[0]+fixture[1]*side*(sphere.radius+micro*.000001)
					q.transform=Transform3D(Basis.IDENTITY,pos)
					var any_overlap:=not space.intersect_shape(q,1).is_empty()
					var any_rest:=not space.get_rest_info(q).is_empty()
					if any_overlap:overlap+=1
					else:outside+=1
					if any_rest and not any_overlap:mismatches+=1
					var mm:=Vector3i((pos*1000.0).round())
					sweeps.append({"from":[mm.x,mm.y,mm.z],"to":[mm.x+8,mm.y+2,mm.z+1],"radius_mm":radius_mm,"mask":1})
	var rows: Array=[]
	for row: Dictionary in sweeps:
		rows.append([row, Queries.sweep(scope,[row])])
	var file:=FileAccess.open(OS.get_environment("RECOLLECTION_QA_GRAZE"),FileAccess.WRITE)
	file.store_string(JSON.stringify(rows))
	file.close()
	var hashed:=HashingContext.new()
	hashed.start(HashingContext.HASH_SHA256)
	hashed.update(var_to_bytes(rows))
	var success:bool=overlap>0 and outside>0 and rows.size()==sweeps.size()
	print("GRAZE queries=",overlap+outside," overlaps=",overlap," empty=",outside," empty_intersect_but_rest_hit=",mismatches,
		" observed=",rows.size()," failures=",0 if success else 1," replay_sha256=",hashed.finish().hex_encode())
	viewport.free()
	quit(0 if success else 1)
