"""Run existing flat ground, wall and landing fixtures on independently extracted games."""
import argparse,json,os,subprocess,sys
from pathlib import Path

here=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument("first",type=Path)
parser.add_argument("second",type=Path)
parser.add_argument("out",type=Path)
parser.add_argument("--engine",type=Path,default=Path("D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"))
args=parser.parse_args()
out=args.out.resolve()
out.mkdir(parents=True,exist_ok=True)
prefixes=("PROFILE_GROUP ","PROFILE_DRIVE ","FIELD_JUMP ","JUMP_OBSTACLES ","JUMP_RIVER ","MOVE_JOLT ","MOVE_NAV ","MOVE_INTENTS checks=","MOUNT_PROFILE checks=","P2-FIELD-INTEGRATION-006 ")
rows={}
success=True
for label, project in [("A",args.first),("candidate",args.second)]:
    project=project.resolve()
    profile=out/label/"profile"
    profile.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile))
    ran={}
    for suite,options in [("mount_profile",[]),("move_intents",[]),("field_pipeline",["--","--mount","--brains=res://mission/runtime/field_brains.gd"])]:
        cmd=[str(args.engine),"--headless","--fixed-fps","60","--path",str(project),"--log-file",str(out/label/(suite+"-engine.log")),"--script","res://tests/p2/"+suite+"/run.gd",*options]
        result=subprocess.run(cmd,env=env,cwd=out/label,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        (out/label/(suite+".log")).write_bytes(result.stdout)
        log=result.stdout.decode('utf-8',errors='replace')
        observations=[line for line in log.splitlines() if line.startswith(prefixes)]
        good=result.returncode==0 and 'ERROR:' not in log and any('failures=0' in line for line in observations)
        if suite=='mount_profile':
            good &= all(any(line.startswith(prefix) for line in observations) for prefix in ['JUMP_RIVER ','JUMP_OBSTACLES ','FIELD_JUMP ','PROFILE_DRIVE ','PROFILE_GROUP '])
        if suite=='field_pipeline':
            good &= 'real_brains=true' in log
        if suite=='move_intents':
            good &= 'MOVE_JOLT wall_x=' in log
        success &=good
        ran[suite]={'exit_code':result.returncode,'status':'PASS' if good else 'FAIL','command':cmd,'observations':observations}
        print(label,suite,result.returncode,observations[-1:],flush=True)
    rows[label]=ran
matches={suite:pair['observations']==rows['candidate'][suite]['observations'] for suite,pair in rows['A'].items()}
success &=all(matches.values())
report={'status':'PASS' if success else 'FAIL','same_observations':matches,'runs':rows}
(out/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('Motion observations identical',matches)
sys.exit(0 if success else 1)
