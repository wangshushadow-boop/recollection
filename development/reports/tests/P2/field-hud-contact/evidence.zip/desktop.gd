extends SceneTree
var main: Node
var scene: Node
var results := []
var seen := {}
var failed := false

func _initialize() -> void: run.call_deferred()

func check(ok: bool, label: String, evidence: Variant=null) -> bool:
	results.append({"ok":ok,"check":label,"observed":str(evidence) if evidence!=null else ""})
	if not ok:
		printerr("FAIL ",label," observed=",evidence)
		failed=true
	return ok

func button(text: String) -> Button:
	for n in main.find_children("*","Button",true,false):
		if n.text==text and n.is_visible_in_tree():return n
	return null

func node_button(id: String) -> Button:return main.find_child(id,true,false) as Button

func key(code: Key,down: bool) -> void:
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key) -> void:
	key(code,true);key(code,false)

func motion(v: Vector2,p: Vector2=Vector2(480,300)) -> void:
	var e:=InputEventMouseMotion.new()
	e.position=p;e.global_position=p;e.relative=v;e.screen_relative=v
	root.push_input(e,true)

func mouse(index: MouseButton,down: bool,p:Vector2=Vector2(480,300)) -> void:
	var e:=InputEventMouseButton.new()
	e.button_index=index;e.pressed=down;e.position=p;e.global_position=p
	root.push_input(e,true)

func click(control: Control) -> bool:
	if control==null or not control.is_visible_in_tree():return false
	var anc=control.get_parent()
	while anc!=null:
		if anc is ScrollContainer:anc.ensure_control_visible(control)
		anc=anc.get_parent()
	await frames(2)
	var p:=control.get_global_rect().get_center()
	motion(Vector2.ZERO,p)
	var hovered:=root.gui_get_hovered_control()
	seen.last_click=[control.name, p, hovered.get_path() if hovered else "",control.get_global_rect(),root.get_visible_rect()]
	mouse(MOUSE_BUTTON_LEFT,true,p);mouse(MOUSE_BUTTON_LEFT,false,p)
	return true

func frames(n: int) -> void:
	for i in n:await process_frame

func hud() -> Dictionary:
	return main._root.field_view("hud").value

func committed(ticks:int) -> bool:
	var initial: int=main._last_tick
	for i in 80:
		await process_frame
		if main._last_tick>=initial+ticks:return true
	return check(false,"simulation advances",initial)

func screenshot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img:=root.get_texture().get_image()
	if img!=null: img.save_png(OS.get_environment("FIELD_CONTROLS_CAPTURE")+"/"+name+".png")

func visible(id: String) -> Control:
	var control := scene._hud.find_child(id,true,false) as Control
	return control if control and control.is_visible_in_tree() else null

func rect(id: String) -> Rect2:
	var control := visible(id)
	return control.get_global_rect() if control else Rect2()

func visible_copy() -> String:
	var words := PackedStringArray()
	for n in scene._hud.find_children("*","Control",true,false):
		if n.is_visible_in_tree() and (n is Button or n is Label): words.append(n.text)
	return " | ".join(words)

func no_debug() -> bool:
	var words := visible_copy()
	for raw in ["field-captain-", "field.deployment", "InvalidState", "field/"]:
		if raw in words: return false
	return true

var hit_log := []

func observe_hits() -> void:
	var mission: Variant=main._root._field_mission.get_ref()
	if mission==null or mission._frame.is_empty():return
	for hit in mission._frame.get("combat_report",{}).get("hits",[]):
		if hit.get("target")!=scene._hud_state.get("actor_handle"):continue
		var handle: Dictionary=hit.attacker
		var pose: Dictionary=mission._frame.pose.get(handle.index,{})
		var row: Dictionary=mission._frame.rows.get(handle.index,{})
		var position: Vector3=scene._hud_state.position
		hit_log.append({"tick":scene._hud_state.tick,"report":hit,"attacker_team":row.get("components",{}).get("team_key"),"attacker_role":mission._frame.roles.get(handle.index),"distance":position.distance_to(pose.get("position",position))})

func walk_to_enemy() -> void:
	var initial: Dictionary=scene._hud_state
	var initial_hp: int=initial.player.hp
	var contact_tick := -1
	var nearest := INF
	var min_distance := INF
	var samples := []
	var player_handle: Dictionary=initial.actor_handle
	var on_flank:=false
	var across_field:=false
	var me_team: int=initial.player.team
	seen.player_handle=player_handle
	seen.health_at_start=initial_hp
	physics_frame.connect(observe_hits)
	key(KEY_W,true)
	while main._last_tick<3600 and (contact_tick<0 or main._last_tick<contact_tick+240):
		await process_frame
		var authority: Dictionary=scene._hud_state
		if authority.get("actor_handle")!=player_handle or authority.get("player",{}).get("hp",0)==0:break
		var target := {}
		var near_any := {}
		var closest := INF
		nearest=INF
		for a in scene._visual_state.get("actors",[]):
			if a.team==me_team or a.role=="mount" or a.hp<=0:continue
			var d: float=authority.position.distance_to(a.position)
			if d<closest:
				closest=d
				near_any=a
			if a.role=="infantry" and d<nearest:
				target=a
				nearest=d
		if target.is_empty():continue
		min_distance=minf(min_distance,nearest)
		if contact_tick<0 and nearest<=1.27:
			contact_tick=main._last_tick
			key(KEY_W,false)
			seen.contact={"tick":contact_tick,"distance":nearest,"enemy":target.handle,"enemy_position":target.position,"player_position":authority.position,"enemy_heading":target.heading,"enemy_team":target.team}
			await screenshot("contact")
		if contact_tick<0:
			var pos: Vector3=authority.position
			if pos.z < -24.0:on_flank=true
			if pos.x > 30.0:across_field=true
			var goal: Vector3=target.position
			if not on_flank:goal=Vector3(pos.x,0,-26)
			elif not across_field:goal=Vector3(34,0,-25)
			var d: Vector3=goal-pos
			var yaw: float=scene._input_port.view().preview_aim.x
			var turn: float=angle_difference(yaw,atan2(-d.x,-d.z))
			if absf(turn)>.003:motion(Vector2(-turn/.0025,0))
		if samples.is_empty() or main._last_tick-int(samples.back().tick)>=48:
			samples.append({"tick":main._last_tick,"player_position":authority.position,"hp":authority.player.hp,"enemy":target.handle,"enemy_position":target.position,"enemy_heading":target.heading,"enemy_phase":target.phase,"distance":nearest,"nearest_role":near_any.role,"nearest_id":near_any.handle,"nearest_distance":closest})
			if samples.size()%6==1:print("field approach ",main._last_tick," ",authority.position," enemy distance=",nearest)
		if contact_tick>=0 and not hit_log.is_empty() and authority.player.hp<initial_hp:
			var local_hit: bool=hit_log.any(func(h):return h.tick>=contact_tick and h.attacker_team!=me_team and h.distance<=2.0 and h.report.damage>0)
			if local_hit:break
	key(KEY_W,false)
	physics_frame.disconnect(observe_hits)
	seen.hit_log=hit_log
	seen.route=samples
	seen.min_infantry_distance=min_distance
	seen.last_tick=main._last_tick
	seen.health_after=scene._hud_state.player.hp
	check(contact_tick>=0,"unassisted player reached an enemy infantryman in melee range",seen.get("contact",min_distance))
	check(hit_log.any(func(h):return contact_tick>=0 and h.tick>=contact_tick and h.attacker_team!=me_team and h.distance<=2.0 and h.report.damage>0),"nearby hostile hits stationary player after arrival",hit_log)
	await screenshot("after-contact")

func checks() -> void:
	var native := OS.get_environment("FIELD_CONTROLS_NATIVE")=="1"
	if not check(DisplayServer.get_name()!="headless" and root.size==Vector2i(960,600),"real 960x600 desktop",[DisplayServer.get_name(),root.size]):return
	if not check(ClassDB.class_exists(&"FieldMoveKernel")==native,"expected extension mode",native):return
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(4)
	if not check(await click(button("进入河原野战")),"enter from main menu"):return
	await frames(5)
	scene=main._field_scene
	if not check(scene!=null and not scene.running,"deployment"):return
	if OS.get_environment("FIELD_CONTACT")=="1":
		if not check(await click(button("开始野战")),"start default river battle"):return
		if not await committed(8):return
		await walk_to_enemy()
		return
	await screenshot("deployment")
	var starters := []
	for n in main.find_children("*","Button",true,false):
		if n.is_visible_in_tree() and n.text in ["开始野战","开战"]: starters.append(n)
	if not check(starters.size()==1,"one visible battle start button",starters):return
	if not check(await click(starters[0]),"click start without a deployment draft"):return
	if not await committed(8):return
	await frames(3)
	if not check(scene.running and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"battle controls captured"):return
	if not check(scene._visuals.report().visible_actors==600,"full scene, 500 soldiers and 100 horses",scene._visuals.report()):return
	if not check(no_debug() and scene._hud._receipt.find("field.deployment")<0,"no deployment error after default start",scene._hud._receipt):return
	var top:=rect("Balance")
	var equipment:=rect("Equipment")
	if not check(top.has_area() and top.get_center().y<140 and absf(top.get_center().x-480)<120,"friendly/enemy balance is top-centred",top):return
	if not check(equipment.has_area() and equipment.get_center().x>640 and equipment.get_center().y>390 and root.get_visible_rect().encloses(equipment),"player vitals and equipment in lower right",equipment):return
	await screenshot("battle")
	key(KEY_TAB,true)
	await frames(3)
	if not check(visible("ScorePanel")!=null and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"Tab reveals scoreboard",visible_copy()):return
	await screenshot("score")
	key(KEY_TAB,false)
	await frames(2)
	if not check(visible("ScorePanel")==null,"releasing Tab closes the board"):return
	tap(KEY_1);tap(KEY_F1)
	await frames(3)
	if not check(visible("OrderCards")!=null and visible("FormationCards")!=null and scene._input_port.view().command_page=="movement","formation and movement command cards",visible_copy()):return
	await screenshot("orders")
	tap(KEY_F3)
	if not await committed(4):return
	var selected: Array=scene._input_port.view().selection
	var charge:=false
	for row in hud().formations:
		if row.id in selected and row.get("active") is Dictionary and row.active.order_type in ["free_attack","charge"]: charge=true
	if not check(charge,"command reached formation authority",selected):return
	tap(KEY_ESCAPE)
	await frames(3)
	if not check(Input.mouse_mode==Input.MOUSE_MODE_VISIBLE and scene._input_port.view().mode=="ui","Esc releases cursor"):return
	var resume:=rect("Resume")
	if not check(resume.has_area() and absf(resume.get_center().x-480)<96 and visible("CommandBook")!=null and visible("Settings")!=null and visible("Withdraw")!=null and visible("Group1")==null,"centred compact menu with four reachable actions",visible_copy()):return
	if not check(no_debug(),"menu contains player-facing language",visible_copy()):return
	await screenshot("menu")
	if not check(await click(visible("CommandBook")),"open command book"):return
	await frames(3)
	if not check(visible("Group1")!=null and visible("BackMenu")!=null and no_debug(),"command book shows formations on demand",visible_copy()):return
	await screenshot("formations")
	if not check(await click(visible("BackMenu")),"back from commands"):return
	await frames(2)
	if not check(await click(visible("Settings")),"open display/input settings"):return
	await frames(3)
	if not check(visible("Large")!=null and visible("BackMenu")!=null,"accessible settings shown",visible_copy()):return
	if not check(await click(visible("BackMenu")),"back from settings"):return
	await frames(2)
	if not check(await click(visible("Resume")),"resume from compact menu"):return
	await frames(2)
	if not check(Input.mouse_mode==Input.MOUSE_MODE_CAPTURED and visible("Resume")==null,"returns to combat"):return
	if native:
		var calls: int=ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")
		if not check(calls>0,"native movement kernel active",calls):return
	tap(KEY_ESCAPE)
	await frames(3)
	if not check(await click(visible("Withdraw")),"withdraw"):return
	await frames(3)
	if not check(visible("Confirm")!=null and await click(visible("Confirm")),"confirm withdrawal"):return
	for i in 80:
		await process_frame
		if main._root.session().query().value.state=="Results":break
	if not check(main._root.session().query().value.state=="Results" and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"battle results"):return
	await frames(3)
	await screenshot("result")
	if not check(await click(visible("Leave")),"leave results"):return
	await frames(2)
	check(main._field_scene==null and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"back to main menu")

func run() -> void:
	await checks()
	var data={"checks":results,"extra":seen,"passed":not failed,"renderer":DisplayServer.get_name()}
	var out:=FileAccess.open(OS.get_environment("FIELD_CONTROLS_CAPTURE")+"/result.json",FileAccess.WRITE)
	out.store_string(JSON.stringify(data,"  "))
	out.close()
	print("FIELD_CONTROL_QA checks=",results.size()," pass=",not failed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(failed))
