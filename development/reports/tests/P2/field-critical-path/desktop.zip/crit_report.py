from pathlib import Path
import json,statistics,zipfile
from crit_stats import aggregate
d=Path(__file__).resolve().parent
repo=d.parent.parent
dest=repo/"development/reports/tests/P2/field-critical-path"
dest.mkdir(exist_ok=True,parents=True)
def data(*names): return aggregate([d/(name+".json") for name in names])
groups={"control":["crit26clean1","crit26clean2"],"sections":["crit26d1","crit26d2"],"commit_sections":["crit26extra"],
        "serial_ab":["crit26s1","crit26s2"],"thread_ab":["crit26p1","crit26p2"]}
results={k:data(*v) for k,v in groups.items()}
results["individual"]={n:data(n) for names in groups.values() for n in names}
(dest/"summary.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
with zipfile.ZipFile(dest/"desktop.zip","w",zipfile.ZIP_DEFLATED) as z:
    for names in groups.values():
        for n in names:
            for ext in ["log","json"]: z.write(d/(n+"."+ext),"raw/"+n+"."+ext)
    for script in ["prepare.py","flat_probe.py","crit_probe.py","crit_commit.py","idle.gd","flat_stats.py","crit_stats.py","crit_report.py"]:
        z.write(d/script,script)
    qa=repo/"out/crit-parallel-qa"
    for rel in ["run.py","behavior.gd","baseline-reference/summary.json","baseline-reference/behavior.json","pose8/summary.json","pose8/behavior.json","pose8/behavior.log"]:
        z.write(qa/rel,"qa/"+rel)
ctrl=results["control"]; det=results["sections"]; extra=results["commit_sections"]; ab=results["serial_ab"]; th=results["thread_ab"]
t=det['matched_phase_ms_per_frame']; v=det['frame_spans_mean_ms']; w=det['exclusive_wall_ms']; q=extra['matched_phase_ms_per_frame']
upper=det['ideal_fps_if_AI_MOV_improve']
labels=dict(AI="AI 思考",movement="移动",combat="战斗结算",other_simulation="其余战斗步工作",presentation="显示刷新与插值",input_and_after="步前输入与步后客户端更新",remainder="其余墙钟时间")
rows="\n".join(f"| {labels[k]} | {x:.2f} | {x/sum(w.values())*100:.1f}% |" for k,x in w.items())
qa=json.loads((repo/"out/crit-parallel-qa/pose8/summary.json").read_text())
assert qa['comparison']['same_ticks']==qa['comparison']['ticks']==1260
report=f"""# 单机河原野战关键路径与并行可行性

采样时工作区是 `eea134c` 加野战客户端补算上限 2；期间该设置进入 `ec87e24`，已核对脚本哈希一致。本次只在独立副本添加探针、试用线程池。原有 60 Hz 规则，500 人、100 马、种子 241124，RTX 3090、Core Ultra 9 285K、Godot 4.7.2 Standard、Forward+、960×600。主菜单进入河原，布阵等 45 帧，开始后站立。取 121–440 步，不含资源加载或部署。

## 显示帧按墙钟时间分账

两轮轻量实测平均 {ctrl['fps']:.2f} FPS，{ctrl['sps']:.2f} 步/现实秒，帧时间均值、P50、P95 分别为 {ctrl['frame_ms'][0]:.2f}、{ctrl['frame_ms'][1]:.2f}、{ctrl['frame_ms'][2]:.2f} ms。每帧实际执行两步，占 {ctrl['field_step_per_frame_ms']:.2f} ms。每步分别从上一帧的末尾步号加一匹配至这一帧的末尾；跳过跨稳定窗口边缘的帧。

下表来自额外两轮同场细采样，共 {det['frame_samples']} 个完整显示帧，平均 {det['frame_ms'][0]:.2f} ms/帧。行互不重叠。根视口 GPU 计时平均 {det['gpu_viewport_ms'][0]:.2f} ms，仅用于对照，不与墙钟表相加。

| 每显示一帧 | 平均 ms | 占比 |
|---|---:|---:|
{rows}

## 热点里在做什么

- AI 每步汇集 500 人。按每个显示帧算，读取战斗状态 {t['ai_actor_read']:.2f} ms，构造 AI 输入 {t['ai_input']:.2f} ms，索引与动态汇总 {t['roster_index']:.2f} ms，个体感知、提案和收集 {t['individual_jobs']:.2f} ms。平均每步实际执行 {det['matched_step_work']['individual_jobs']:.1f} 个个体任务。
- 移动每帧推进与避让 {t['move_advance']:.2f} ms（每步约 {det['matched_step_work']['move_advance']:.0f} 次邻居检查）；水平净空 {t['clearance']:.2f} ms；打包每步 600 行物理代理 {t['physics_pack']:.2f} ms，物理侧校验、准备和同步 {t['physics_stage']:.2f} ms。战斗阶段把这些位置转为整数位姿又用 {t['combat_pose']:.2f} ms。
- 显示刷新中：可视筛选 {v['visual_filter']:.2f} ms，包含句柄解析和对敌可见性检测；取 COM 视图 {v['visual_com']:.2f} ms，装配可见角色 {v['visual_pack']:.2f} ms，应用快照 {v['apply_snapshot']:.2f} ms，插值显示回调 {v['_process']:.2f} ms。AI 输入、物理行、战斗位姿和显示角色这四处数据装配合计约 {t['ai_input']+t['physics_pack']+t['combat_pose']+v['visual_pack']:.2f} ms/帧；其中包含必要的业务工作。
- 对其余战斗步开销另做一轮探针。两步的移动提交前校验及提交共 {q['seal']:.2f} ms，各系统提交回调共 {q['commit']:.2f} ms，含引擎提交 {q['eng_commit']:.2f} ms、结果和 AI 提交 {q['brains_results_commit']:.2f} ms。该轮总体帧时间 {extra['frame_ms'][0]:.2f} ms，数字不与上表跨轮相加。

## 线程池的直接实验

在三个独立无头进程中回放早期实战 1197 行位姿样本。取其中前 600 行，在主线程串行、2 块、4 块、8 块运行同一套投影。包含调度、等待和有序合并，P50 分别 0.824、0.691、0.582、0.559 ms。1197 行串行与 8 块为 1.671 与 1.003 ms。2784 个批次输出值及键顺序完全一致；样本读取、构造骑手集合和事后校验不计时。[无头数据、完整脚本及桌面试验差异](workers.zip)

另在真实当前桌面场景的隔离副本中保留原输入、队伍和规则，只将 `_fight` 的位姿计算拆为八块。线程只读本步数据，分别写私有结果，主线程等待并按原索引顺序合并。按“并行、串行、串行、并行”顺序运行独立进程，各版本两轮。第 119 和 441 步额外对当前场景的完整 600 行逐字段、逐键顺序对照，两次并行进程均通过。这些步均在计时窗口外。

| 桌面对照 | 串行 | 八块并行 |
|---|---:|---:|
| 完整战斗步平均 ms | {ab['step_ms'][0]:.2f} | {th['step_ms'][0]:.2f} |
| 平均 FPS | {ab['fps']:.2f} | {th['fps']:.2f} |
| 现实每秒实际步数 | {ab['sps']:.2f} | {th['sps']:.2f} |
| 帧时间 P50 / P95（ms） | {ab['frame_ms'][1]:.2f} / {ab['frame_ms'][2]:.2f} | {th['frame_ms'][1]:.2f} / {th['frame_ms'][2]:.2f} |

第一对串行/并行各 12.30/12.33 FPS，第二对各 12.86/12.63 FPS。首对和次对方向相反，整场未观察到稳定收益。600 行无头测试平均仅省约 0.27 ms/步，折合两步帧约 0.54 ms，即使完全兑现也小于本组的轮间波动。

用同一隔离并行副本另外回放有指令的 500 人、100 马战斗，{qa['comparison']['same_ticks']}/1260 步与既有串行权威摘要一致。真实桌面数据只代表站立开局，接战时的帧率未经测量。[逐轮汇总](summary.json) · [原始帧、步、接战结果与复跑脚本](desktop.zip)

## 哪些工作适合并行

现有战斗入口依序执行 AI、移动、动作和提交，下一步读前一步已经发布的状态。移动在推进一个单位后会立即更新空间格，并可能给邻兵写入让行动作。直接把全军移动拆给线程会改变顺序。现有引擎适配器对视线、物理和导航查询检查调用线程。项目已有 Worker 队列，当前野战主流程没有向该队列提交任务；默认并发上限 1，也会复制任务快照。仅调整线程数不会改变上述调用链。[Godot 线程安全 API](https://docs.godotengine.org/en/stable/tutorials/performance/thread_safe_apis.html) · [WorkerThreadPool](https://docs.godotengine.org/en/stable/classes/class_workerthreadpool.html)

下一次优先验证全军位姿的数据传递：保持稳定的编号与代际，明确移动前、移动后和已提交快照；先用串行批量数据减少反复装配，再在同一数据布局上试 2/4/8 块。将候选计算与必须顺序执行的授权、场景查询、移动冲突裁决和最终提交分开。比较端到端墙钟、实际步速、尾帧和接战逐步摘要，计入准备、等待、合并、回滚与释放。如果只加速 AI 和移动，其他成本固定，在本次细采样上两者整体快 2 倍约 {upper['2x']:.1f} FPS，即便两者耗时为零也只约 {upper['zero_cost']:.1f} FPS。这是固定负载下的时间预算推算。
"""
(dest/"README.md").write_text(report,encoding="utf-8")
