from pathlib import Path
import shutil
d=Path(__file__).resolve().parent
root=d/'crit26commit'/'game'
shutil.copytree(d/'crit26profile'/'game',root)
def section(rel,a,b,name):
    p=root/rel
    s=p.read_text(encoding='utf-8')
    assert s.count(a)==1 and s.count(b)==1,(a,b)
    indent=a[:len(a)-len(a.lstrip())]
    s=s.replace(a,indent+'var t_'+name+':=Time.get_ticks_usec()\n'+a)
    indent=b[:len(b)-len(b.lstrip())]
    s=s.replace(b,indent+f'Engine.get_main_loop().call("record_work","{name}",Time.get_ticks_usec()-t_{name},1,0)\n'+b)
    p.write_text(s,encoding='utf-8')
r='mission/runtime/runtime.gd'
section(r,'\tvar sealed := _seal_tick()','\tfor system in attempted:',"seal")
section(r,'\tfor system in attempted:', '\t_entities = staged\n\t_retry_wave', "commit")
p='mission/runtime/field_pipeline.gd'
section(p,'\t_engine.field_commit_bodies(_mission)','\t_results.commit()','eng_commit')
section(p,'\t_results.commit()','\t_form.commit_tick()\n\t_com=', 'brains_results_commit')
section(p,'\t_frame={"roster":','\tif not _input.is_empty(): _consumed=', 'publish_free')
section(r,'\t\t\tif not C.encode(report.get("value")).ok:', '\t\t\tif phase == "objectives"', 'encode')
section(r,'\t\t\tvar entry := {"id":id','\t\t\treports.append(entry)','freeze')
