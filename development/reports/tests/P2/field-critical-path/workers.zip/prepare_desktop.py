"""Generate a disposable threaded variant from an existing lightweight capture."""
from pathlib import Path
import shutil
import sys

d=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve()
target=Path(sys.argv[2]).resolve()
if target.exists(): raise FileExistsError(target)
shutil.copytree(src,target)
p=target/"mission/runtime/field_pipeline.gd"
source=p.read_text(encoding="utf-8")
probe=(d/"bench.gd").read_text(encoding="utf-8")
chunk=probe[probe.index("class Chunk extends"):probe.index("\nvar rows: Array\n")]
chunk=chunk.replace("class Chunk extends","class PoseChunk extends")
helper=probe[probe.index("func parallel("):probe.index("func _initialize()")]
helper=helper.replace("func parallel(count: int, workers: int)","static func _worker_poses(rows: Array, poses: Dictionary, riders: Dictionary, workers: int)")
helper=helper.replace("var jobs: Array[Chunk]=[]","var count := rows.size()\n\tvar jobs: Array[PoseChunk]=[]").replace("Chunk.new()","PoseChunk.new()")
start="func _fight(ctx: Dictionary, batch: Dictionary) -> Dictionary:\n"
assert source.count(start)==1
idx=source.index(start)
loop=source.index("\tfor row in _draft.roster:",idx)
end=source.index("\tvar actions: Array =",loop)
# Keep the exact original for comparison in two out-of-window ticks.
serial=source[loop:end].replace("poses[row.handle.index]","expected[row.handle.index]")
serial="\n".join("\t"+line for line in serial.splitlines())+"\n"
replace='''	poses = _worker_poses(_draft.roster,_draft.pose,riders,8)
	if poses.size()!=_draft.roster.size():return R.fail("InvalidState","thread_poses")
	if batch.source_tick==119 or batch.source_tick==441:
		var expected := {}
'''+serial+'''		var equal := poses==expected and poses.keys()==expected.keys()
		print("THREAD_DESKTOP_EQUAL tick=",batch.source_tick," actors=",poses.size()," equal=",equal)
		if not equal:return R.fail("InvalidState","thread_poses_match")
'''
source=source[:loop]+replace+source[end:]
source=source.replace(start,chunk+"\n"+helper+start)
p.write_text(source,encoding="utf-8")
