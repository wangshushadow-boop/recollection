extends SceneTree

# Workers read the archived snapshot for one synchronous batch.
# Each job owns its result until the caller has joined the task.
class Chunk extends RefCounted:
	var rows: Array
	var poses: Dictionary
	var riders: Dictionary
	var first: int
	var stop: int
	var result: Dictionary

	static func mm(v: Vector3, scale: int = 1000) -> Array:
		return [roundi(v.x*scale),roundi(v.y*scale),roundi(v.z*scale)]

	static func project(rows_: Array, poses_: Dictionary, riders_: Dictionary, start_row: int, end_row: int) -> Dictionary:
		var out := {}
		for i in range(start_row,end_row):
			var id: int = rows_[i].handle.index
			var p: Dictionary = poses_[id]
			var origin: Vector3 = p.position+Vector3.UP
			if riders_.has(id): origin+=Vector3.UP*.8
			out[id] = {"position_mm":mm(origin),"facing_ppm":mm(p.heading,1000000),
				"speed_mm_tick":roundi(p.velocity.length()*1000.0/60.0)}
		return out

	func run() -> void:
		result=project(rows,poses,riders,first,stop)

var rows: Array
var poses: Dictionary
var riders: Dictionary

func parallel(count: int, workers: int) -> Dictionary:
	var jobs: Array[Chunk]=[]
	var ids := PackedInt64Array()
	for n in workers:
		var job:=Chunk.new()
		job.rows=rows
		job.poses=poses
		job.riders=riders
		job.first=n*count/workers
		job.stop=(n+1)*count/workers
		jobs.append(job)
		ids.append(WorkerThreadPool.add_task(job.run))
	var output := {}
	for n in workers:
		if WorkerThreadPool.wait_for_task_completion(ids[n])!=OK: return {}
		output.merge(jobs[n].result)
	return output

func _initialize() -> void:
	var args:=OS.get_cmdline_user_args()
	var data:Dictionary=FileAccess.open("res://snapshot.bin",FileAccess.READ).get_var(false)
	rows=data.rows
	poses=data.poses
	riders=data.riders
	var modes:=[1,2,4,8]
	var results:={}
	const WARM:=16
	const N:=100
	for count:int in [600,rows.size()]:
		var expected:Dictionary={}
		for row:Dictionary in rows.slice(0,count):
			expected[row.handle.index]=data.expected[row.handle.index]
		var sample:Dictionary={}
		for workers in modes: sample[workers]=[]
		for repeat in WARM+N:
			for offset in modes.size():
				var n:int=modes[(repeat+offset+int(args[0]))%modes.size()]
				var start:=Time.get_ticks_usec()
				var output:=Chunk.project(rows,poses,riders,0,count) if n==1 else parallel(count,n)
				var us:=Time.get_ticks_usec()-start
				if output!=expected or output.keys()!=expected.keys():
					printerr("Mismatch count=",count," workers=",n)
					quit(1)
					return
				if repeat>=WARM: sample[n].append(us)
				output.clear()
		results[count]=sample
	var file:=FileAccess.open(args[1],FileAccess.WRITE)
	file.store_string(JSON.stringify({"cpu":OS.get_processor_name(),"processors":OS.get_processor_count(),
		"engine":Engine.get_version_info().string,"snapshot_tick":data.tick,"seed":data.seed,
		"total_rows":rows.size(),"riders":riders.size(),"warmup":WARM,"iterations":N,
		"times_us":results}))
	file.close()
	print("THREAD_POSE_PASS complete_equivalence_batches=",(WARM+N)*modes.size()*2)
	quit(0)
