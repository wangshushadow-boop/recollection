import json
import math
import os
from pathlib import Path
import statistics
import subprocess

d=Path(__file__).resolve().parent
profile=d/"profile"
profile.mkdir(exist_ok=True)
engine="D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"
rows={}
def quantiles(samples):
    samples=sorted(samples)
    return {
        "mean_ms":round(statistics.mean(samples)/1000,4),
        "p50_ms":round(statistics.median(samples)/1000,4),
        "p95_ms":round(samples[math.ceil(.95*len(samples))-1]/1000,4)}
for trial in (1,2,3):
    result=d/f"trial-{trial}.json"
    cmd=[engine,"--headless","--path",str(d),"--log-file",str(d/f"trial-{trial}.log"),
         "--script","res://bench.gd","--",str(trial),str(result)]
    p=subprocess.run(cmd,capture_output=True,timeout=150,env={**os.environ,"APPDATA":str(profile),"LOCALAPPDATA":str(profile)})
    text=(p.stdout+p.stderr).decode("utf-8",errors="replace")
    print(trial,p.returncode,text[-500:],flush=True)
    if p.returncode or "THREAD_POSE_PASS" not in text or "SCRIPT ERROR:" in text or "ERROR:" in text:
        raise SystemExit(1)
    record=json.loads(result.read_text(encoding="utf-8"))
    for n,variants in record["times_us"].items():
        for workers,samples in variants.items():
            rows.setdefault((n,workers),[]).append(samples)
summary={str(n):{str(w):{"pooled":quantiles(sum(rows[(str(n),str(w))],[])),
    "per_process":[quantiles(seq) for seq in rows[(str(n),str(w))]]} for w in [1,2,4,8]} for n in [600,1197]}
(d/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
for n in summary: print(n,{w:v["pooled"] for w,v in summary[n].items()})
