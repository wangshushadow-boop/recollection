"""Generate isolated desktop scenarios from a lightweight, serial pose build."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
PIPELINE = Path("mission/runtime/field_pipeline.gd")
JOB = """class BenchPoseJob extends RefCounted:
	var compute: Callable
	var result: Dictionary
	func run() -> void:
		result = compute.call()

"""


def variant(source, workers):
    walk = "func _walk(_ctx: Dictionary, batch: Dictionary) -> Dictionary:"
    start = source.index(walk)
    collection = source.index("\tvar projections: Array[PoseProjection]", start)
    loop = source.index("\tfor i in _draft.humans.size():\n", collection)
    after = source.index("\tfor row in _draft.horses:\n", loop)
    serial_loop = source[loop:after]
    assert "_project_actor(" in serial_loop and "ridden[index]=true" in serial_loop
    assert source.count(walk) == 1
    method = """func _bench_chunk(begin: int, end: int, previous: Dictionary, positions: PackedVector3Array, velocities: PackedVector3Array, headings: PackedVector3Array) -> Dictionary:
"""
    method += source[collection:loop] + serial_loop.replace("for i in _draft.humans.size()", "for i in range(begin,end)")
    method += '\treturn {"projections":projections,"ridden":ridden}\n\n'
    launch = f"""	const BENCH_CHUNKS := {workers}
	var jobs: Array[BenchPoseJob] = []
	var task_ids := PackedInt64Array()
	var count: int = _draft.humans.size()
	for part in BENCH_CHUNKS:
		var job := BenchPoseJob.new()
		job.compute = _bench_chunk.bind(part*count/BENCH_CHUNKS,(part+1)*count/BENCH_CHUNKS,previous,positions,velocities,headings)
		jobs.append(job)
		task_ids.append(WorkerThreadPool.add_task(job.run))
	var completed := true
	for part in BENCH_CHUNKS:
		if WorkerThreadPool.wait_for_task_completion(task_ids[part]) != OK:
			completed = false
		else:
			projections.append_array(jobs[part].result.projections)
			ridden.merge(jobs[part].result.ridden)
	if not completed:
		return R.fail("InvalidState","pose.workers")
	if batch.source_tick in [118,119]:
		var expected: Array[PoseProjection] = []
		var expected_ridden := {{}}
"""
    # Check complete row values, row ordering and prior-cache reuse, outside the measured window.
    renamed = serial_loop.replace("projections.append(", "expected.append(").replace("ridden[index]", "expected_ridden[index]")
    launch += "".join("\t"+line for line in renamed.splitlines(keepends=True))
    launch += """		var equal := projections.size()==expected.size() and ridden==expected_ridden and ridden.keys()==expected_ridden.keys()
		for i in expected.size():
			if not equal:break
			var actual := projections[i]
			var want := expected[i]
			var prior: PoseProjection = previous.get(want.source.handle.index)
			equal = is_same(actual.source,want.source) and actual.pose==want.pose and actual.body==want.body and actual.combat==want.combat and is_same(actual,prior)==is_same(want,prior)
		print("POSE_CHUNK_EQUAL workers=",BENCH_CHUNKS," tick=",batch.source_tick," entities=",projections.size()," equal=",equal)
		if not equal:
			return R.fail("InvalidState","pose.worker_projection")
"""
    return source[:start]+JOB+method+source[start:loop]+launch+source[after:]


def generate(serial_game, workers, output):
    serial_game = serial_game.resolve()
    if not (serial_game / "project.godot").exists():
        raise FileNotFoundError(serial_game)
    source = (serial_game / PIPELINE).read_text(encoding="utf-8")
    assert "record_step" in (serial_game / "bootstrap/composition_root.gd").read_text(encoding="utf-8")
    result = variant(source, workers)
    target = output / "game"
    if target.exists():
        raise FileExistsError(target)
    shutil.copytree(serial_game, target)
    (target / PIPELINE).write_text(result, encoding="utf-8")
    metadata = {"chunks": workers, "source": str(serial_game),
                "serial_sha256": hashlib.sha256(source.encode()).hexdigest(),
                "worker_sha256": hashlib.sha256(result.encode()).hexdigest()}
    (output / "variant.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("serial_game", type=Path)
    parser.add_argument("--workers", nargs="+", type=int, default=[2, 4, 8], choices=[2, 4, 8])
    parser.add_argument("--prefix", default="w")
    args = parser.parse_args()
    if not args.prefix.isalnum():
        parser.error("--prefix must be alphanumeric")
    for n in args.workers:
        generate(args.serial_game, n, HERE / f"{args.prefix}{n}")
