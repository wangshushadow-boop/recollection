"""Summarize sequential desktop trials and check each worker's out-of-window witnesses."""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "field-perf2"))
from flat_stats import summarize


def assess(n, files):
    paths = [Path(p).resolve() for p in files]
    trials = []
    for path in paths:
        if n != "serial":
            log_path = path.with_suffix(".log")
            content = log_path.read_text(encoding="utf-8-sig", errors="replace")
            matches = re.findall(r"POSE_CHUNK_EQUAL workers=(\d+) tick=(\d+) entities=(\d+) equal=(true|false)", content)
            assert matches == [(n, str(t), "600", "true") for t in (118, 119)], (log_path, matches)
        result = summarize([path])
        assert result["step_samples"] == 320
        assert set(result["frame_step_histogram"]) == {2}
        trials.append(result)
    return {"workers": n, "pooled": summarize(paths), "trials": trials}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", nargs="+", action="append", required=True, metavar="ARG")
    parser.add_argument("--save", type=Path)
    args = parser.parse_args()
    summary = [assess(mode[0], mode[1:]) for mode in args.mode]
    data = json.dumps(summary, indent=2, ensure_ascii=False)
    if args.save:
        args.save.write_text(data + "\n", encoding="utf-8")
    else:
        print(data)
