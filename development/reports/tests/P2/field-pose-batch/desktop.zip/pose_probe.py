"""Add the same phase timers as the original profile around the new fused loop."""
import sys
from pathlib import Path

root=Path(sys.argv[1]).resolve()
old=Path(__file__).with_name("crit_probe.py").read_text(encoding="utf-8")
# Both versions begin physical packing immediately after read_poses succeeds.
old=old.replace('"var physical :="',"""'_draft["motion"]'""")
# _walk now supplies the finished COM input. Its time is included in physics_pack.
old='\n'.join(line for line in old.splitlines() if not ('"combat_pose"' in line))
exec(compile(old,__file__,"exec"))
p=root/"mission/runtime/field_pipeline.gd"
s=p.read_text(encoding="utf-8")
a='\tfor projection in projections:\n'
b='if is_same(next.get(index),projection):continue'
assert s.count(a)==s.count(b)==1
s=s.replace(a,'\tvar reused := 0\n'+a).replace(b,'if is_same(next.get(index),projection):\n\t\t\treused+=1\n\t\t\tcontinue')
t='\t_draft["projections"]=next'
s=s.replace(t,'\tEngine.get_main_loop().call("record_work","reuse",0,projections.size(),reused)\n'+t)
p.write_text(s,encoding="utf-8")
p=root/"infrastructure/engine/field_bodies.gd"
s=p.read_text(encoding="utf-8")
s=s.replace("\tvar next := {}\n","\tvar next := {}\n\tvar reused_inputs := 0\n",1)
t="\t\t\tif previous_row != null and is_same(previous_row.source,row):"
assert s.count(t)==1
s=s.replace(t,t+"\n\t\t\t\treused_inputs+=1")
t="\t_sync(next)\n\t_staged = true"
assert s.count(t)==1
s=s.replace(t,'\tEngine.get_main_loop().call("record_work","body_reuse",0,rows.size(),reused_inputs)\n'+t)
p.write_text(s,encoding="utf-8")
