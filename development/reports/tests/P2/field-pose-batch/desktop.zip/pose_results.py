"""Aggregate independent Godot processes; keep window and elapsed-time weighting identical."""
from pathlib import Path
from collections import Counter
import json
import statistics
import sys
import zipfile
import hashlib
import re
from crit_stats import aggregate

d=Path(__file__).resolve().parent
repo=d.parents[1]
dest=repo/"development/reports/tests/P2/field-pose-batch"
dest.mkdir(parents=True,exist_ok=True)
groups={}
for name,tag in [("baseline","A"),("projections","B"),("final","C"),("worker2","W2"),("worker4","W4"),("worker8","W8"),("before_detail","AD"),("after_detail","CD")]:
    files=sorted(d.glob("PoseV"+tag+"*.json"))
    groups[name]=[p for p in files if re.fullmatch(re.escape("PoseV"+tag)+r"(\d+|[ab])",p.stem)]
assert all(groups.values())
result={name:aggregate(files) for name,files in groups.items()}
result["individual"]={}
for name, files in groups.items():
    for path in files:
        log=path.with_suffix(".log").read_text(encoding="utf-8-sig",errors="replace")
        assert "SCRIPT ERROR:" not in log and "ERROR:" not in log and "IDLE_CAPTURE" in log,(path,log[-1000:])
        if name.startswith("worker"):
            for t in [118,119]:
                assert f"POSE_CHUNK_EQUAL workers={name[6:]} tick={t} entities=600 equal=true" in log
        data=aggregate([path])
        result["individual"][path.stem]={k:data[k] for k in ["fps","sps","frame_ms","step_ms","frame_samples","step_samples","frame_step_histogram"]}
rows=Counter()
for p in groups["after_detail"]:
    raw=json.loads(p.read_text(encoding="utf-8"))
    for tick,_,work in raw["steps"]:
        if 120 < tick <= 440:
            for stat in ["reuse","body_reuse"]:
                rows[stat+"_total"]+=work[stat][1]
                rows[stat]+=work[stat][2]
            rows["samples"]+=1
result["rows_per_step"]={k:v/rows["samples"] for k,v in rows.items() if k!="samples"}
result["source"]={p:hashlib.sha256((repo/"game"/p).read_bytes()).hexdigest() for p in ["mission/runtime/field_pipeline.gd","mission/runtime/field_mission.gd","infrastructure/engine/field_bodies.gd"]}
(dest/"summary.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
with zipfile.ZipFile(dest/"desktop.zip","w",zipfile.ZIP_DEFLATED) as z:
    for files in groups.values():
        for p in files:
            z.write(p,"raw/"+p.name)
            z.write(p.with_suffix(".log"),"raw/"+p.stem+".log")
    for script in ["prepare.py","idle.gd","flat_probe.py","crit_probe.py","pose_probe.py","flat_stats.py","crit_stats.py","pose_results.py"]:
        z.write(d/script,script)
    for script in ["prepare.py","assess.py"]:
        z.write(repo/"out/pose-workers"/script,"workers/"+script)
    for log in (repo/"out/pose-integrated").glob("*.log"):
        z.write(log,"integration/"+log.name)
for k in groups:
    g=result[k]
    print(k, g["step_ms"], g["frame_ms"], round(g["fps"],3), round(g["sps"],3))
print(result["rows_per_step"])
