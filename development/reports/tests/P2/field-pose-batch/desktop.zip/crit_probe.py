"""Add nested section timers only to a flat_probe.py disposable project."""
from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve()
assert root.parent.parent==Path(__file__).resolve().parent
pipe="mission/runtime/field_pipeline.gd"
brains="mission/runtime/field_brains.gd"
mov="mission/movement/ports/field_movement.gd"
vis="mission/runtime/field_mission.gd"
def span(rel,f,begin,end,key,count='0',frame=False):
    p=root/rel
    s=p.read_text(encoding="utf-8")
    pos=s.index("func "+f+"(")
    a=s.index("\n\t"+begin,pos)+1
    b=s.index("\n\t"+end,a)+1
    assert "\nfunc " not in s[a:b],(f,key)
    cb=(f'Engine.get_main_loop().call("record_span","{key}",Time.get_ticks_usec()-c_{key})' if frame else
        f'Engine.get_main_loop().call("record_work","{key}",Time.get_ticks_usec()-c_{key},{count},0)')
    s=s[:a]+f"\tvar c_{key}:=Time.get_ticks_usec()\n"+s[a:b]+"\t"+cb+"\n"+s[b:]
    p.write_text(s,encoding="utf-8")
for b,e,k,n in [
    ("var targets :=","if not targets","formation_slots",'_draft.groups.size()'),
    ("var state:","if not state","ai_actor_read",'_draft.humans.size()'),
    ("var units :=","var player:","ai_input",'units.size()'),
    ("var decision:","if not decision","brains_total",'_draft.humans.size()')]:
    span(pipe,"_bench__think",b,e,k,n)
span(brains,"_dispatch","for job in jobs:\n\t\tif job.layer!=\"individual","if not _path_error","individual_jobs","metrics.individual")
span(brains,"_index","var identity :=","var read: Dictionary","roster_index","units.size()")
span(pipe,"_bench__walk","var physical :=","var stage: Dictionary","physics_pack","physical.size()")
span(pipe,"_bench__walk","var stage: Dictionary","if not stage","physics_stage","physical.size()")
span(mov,"_run_step","if not _had_drives","var shared:","move_advance","_checks")
span(pipe,"_bench__fight","var poses :=","var actions:","combat_pose","poses.size()")
span(pipe,"_bench__fight","var combat:","if not combat","combat_sim")
span(vis,"_visual","var handles :=","var read:","visual_filter",frame=True)
span(vis,"_visual","var read:","if not read","visual_com",frame=True)
span(vis,"_visual","var actors :=","var visible_shots:","visual_pack",frame=True)
# Cover all named authority systems, including phases registered outside the pipeline file.
p=root/"mission/runtime/runtime.gd"
s=p.read_text(encoding="utf-8")
anchor="var report: Variant = system.run.call(phase_context,batch.value)"
assert s.count(anchor)==1
p.write_text(s.replace(anchor,'var phase_us:=Time.get_ticks_usec()\n\t\t\t'+anchor+'\n\t\t\tEngine.get_main_loop().call("record_work","sys."+str(id),Time.get_ticks_usec()-phase_us,1,0)'),encoding="utf-8")
