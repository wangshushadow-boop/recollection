"""Match each frame to exactly the fixed steps completed during it."""
from pathlib import Path
import json,sys,statistics,collections
from flat_stats import summarize
def aggregate(paths):
    s=summarize(paths)
    s.pop("scene_exact_per_step")
    times=collections.Counter()
    work=collections.Counter()
    for path in paths:
        raw=json.loads(Path(path).read_text(encoding="utf-8"))
        assert raw['visible_roles_at_end']==dict(archer=150,cavalry=50,infantry=250,mount=100,mounted_archer=50)
        ticks={t:vals for t,total,vals in raw["steps"]}
        for last,f in zip(raw["frames"],raw["frames"][1:]):
            if f['phase']!='battle' or last['tick']<120 or f['tick']>440:continue
            assert f['tick']-last['tick']==2
            for tick in range(last['tick']+1,f['tick']+1):
                for k,(us,n,qty) in ticks[tick].items():
                    times[k]+=us
                    work[k]+=n
    n=s['frame_samples']
    s['matched_phase_ms_per_frame']={k:v/n/1000 for k,v in times.items()}
    s['matched_step_work']={k:v/(2*n) for k,v in work.items()}
    if times:
        by=s['matched_phase_ms_per_frame']
        stages={'AI':by['_think'],'movement':by['_walk'],'combat':by['_fight']}
        stages['other_simulation']= s['field_step_per_frame_ms']-sum(stages.values())
        spans=s['frame_spans_mean_ms']
        stages['presentation']=spans['present_frame']+spans['_process']
        stages['input_and_after']=spans['before_step']+spans['after_step']
        stages['remainder']=s['outside_field_step_ms']-stages['presentation']-stages['input_and_after']
        s['exclusive_wall_ms']=stages
        mean=s['field_step_per_frame_ms']+s['outside_field_step_ms']
        s['ideal_fps_if_AI_MOV_improve']={k:1000/(mean-(stages['AI']+stages['movement'])*saved) for k,saved in [('2x',.5),('4x',.75),('zero_cost',1)]}
    return s
if __name__=='__main__': print(json.dumps(aggregate(sys.argv[1:]),indent=2))
