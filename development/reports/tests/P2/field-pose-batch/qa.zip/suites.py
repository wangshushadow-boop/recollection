"""Run the candidate's public field cross-module regressions with isolated app data."""
from pathlib import Path
import json
import os
import subprocess
import sys

here = Path(__file__).resolve().parent
project = Path(sys.argv[1]).resolve()
out = here/sys.argv[2]
out.mkdir(exist_ok=True)
profile = out/"profile"
profile.mkdir(exist_ok=True)
env = dict(os.environ, APPDATA=str(profile),LOCALAPPDATA=str(profile))
engine = "D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"
suite_ids = [
    ("projection",str(here/"pose_projection.gd"),"failures=0",[]),
    ("field_engine","field_engine","failures=0",[]),
    ("field_brains","field_brains","failures=0",[]),
    ("formation","formation","failures=0",[]),
    ("formation_ai_transaction","formation_ai_transaction","PASS",[]),
    ("ai_transaction","ai_transaction","failures=0",[]),
    ("field_combat_batch","combat_batch","errors=0",[]),
    ("field_sweep","field_sweep_batch","failures=0",[]),
    ("move_intents","move_intents","failures=0",[]),
    ("motion_batch","motion_batch","failures=0",[]),
    ("field_revision","field_revision","failures=0",[]),
    ("field_pipeline_real","field_pipeline","failures=0",["--mount","--brains=res://mission/runtime/field_brains.gd"]),
    ("field_pipeline_reserves","field_pipeline","failures=0",["--casualties","--mount"]),
    ("camera","camera",'"failures":0',[]),
    ("visuals","visuals","failures=0",[]),
]
status = {}
for name,script,marker,extra in suite_ids:
    if name!="projection":
        script = "res://tests/p2/"+script+"/run.gd"
    cmd = [engine,"--headless","--fixed-fps","60","--path",str(project),"--log-file",str(out/(name+"-engine.log")),"--script",script]
    if extra:
        cmd.extend(["--",*extra])
    p = subprocess.run(cmd,env=env,capture_output=True,timeout=200)
    text = (p.stdout+p.stderr).decode("utf-8","replace")
    (out/(name+".log")).write_text(text,encoding="utf-8")
    ok = p.returncode==0 and marker in text and "SCRIPT ERROR:" not in text and "ERROR:" not in text
    status[name] = {"command":cmd,"ok":ok,"code":p.returncode,"last_line":text.splitlines()[-1:]}
    print(name, p.returncode, ok,text.splitlines()[-1:],flush=True)
    (out/"suites.json").write_text(json.dumps(status,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
sys.exit(int(not all(s["ok"] for s in status.values())))
