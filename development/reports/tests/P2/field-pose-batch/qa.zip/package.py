from pathlib import Path
import hashlib
import json
import sys
import zipfile

here = Path(__file__).resolve().parent
repo = here.parents[1]
dest = here/"qa.zip"
labels = sys.argv[1:] or ["baseline","final"]
with zipfile.ZipFile(dest,"w",compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ["run.py","suites.py","behavior.gd","pose_projection.gd","package.py"]:
        archive.write(here/name,name)
    for label in labels:
        for f in sorted((here/label).iterdir()):
            if f.is_file() and not f.name.endswith("-engine.log"):
                archive.write(f,f.relative_to(here).as_posix())
    paths = ["mission/runtime/field_pipeline.gd","mission/runtime/field_mission.gd","infrastructure/engine/field_bodies.gd"]
    for label,project in [("baseline",repo/"out/field-perf2/PoseVBase/game"),("final",repo/"game")]:
        archive.writestr(label+"/source_sha256.json",json.dumps({p:hashlib.sha256((project/p).read_bytes()).hexdigest() for p in paths},indent=2))
print(dest, dest.stat().st_size)
