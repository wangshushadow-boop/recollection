"""Drive each game through a real Windows viewport, with an isolated player profile."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
here=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument("project",type=Path);p.add_argument("label");p.add_argument("--native",action="store_true")
args=p.parse_args();project=args.project.resolve()
out=here/args.label;out.mkdir(exist_ok=True)
profile=out/"profile";profile.mkdir(exist_ok=True)
engine=Path("D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe")
env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile),FIELD_CONTROLS_CAPTURE=str(out),FIELD_CONTROLS_NATIVE=str(int(args.native)),RECOLLECTION_MOVE_WORKERS="1")
cmd=[str(engine),"--path",str(project),"--resolution","960x600","--log-file",str(out/"engine.log"),"--script",str(here/"desktop.gd"),"--","--profile=client"]
pr=subprocess.run(cmd,cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=160)
(out/"console.log").write_bytes(pr.stdout)
lines=pr.stdout.decode("utf-8","replace").splitlines()
summary=json.loads((out/"result.json").read_text(encoding="utf-8")) if (out/"result.json").exists() else {}
modules=["bootstrap/field_desktop.gd","presentation/input/ports/field_input.gd","presentation/input/field_profile.gd","presentation/ui/ports/field_hud.gd","presentation/camera/ports/field_camera.gd","presentation/visuals/ports/field_visuals.gd"]
data={"command":cmd,"exit_code":pr.returncode,"project":str(project),"native":args.native,"result":summary,"source_sha256":{mod:hashlib.sha256((project/mod).read_bytes()).hexdigest() for mod in modules}}
bad=[l for l in lines if l.startswith(("ERROR:","SCRIPT ERROR:","FAIL "))]
data["diagnostic"]=bad
(out/"evidence.json").write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding="utf-8")
print(pr.returncode, "checks",len(summary.get("checks",[])),"pass",summary.get("passed"),bad,flush=True)
sys.exit(0 if summary.get("passed")==True and pr.returncode==0 and not bad else 1)
