extends SceneTree
var main: Node
var scene: Node
var results := []
var seen := {}
var failed := false

func _initialize() -> void: run.call_deferred()

func check(ok: bool, label: String, evidence: Variant=null) -> bool:
	results.append({"ok":ok,"check":label,"observed":str(evidence) if evidence!=null else ""})
	if not ok:
		printerr("FAIL ",label," observed=",evidence)
		failed=true
	return ok

func button(text: String) -> Button:
	for n in main.find_children("*","Button",true,false):
		if n.text==text and n.is_visible_in_tree():return n
	return null

func node_button(id: String) -> Button:return main.find_child(id,true,false) as Button

func key(code: Key,down: bool) -> void:
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key) -> void:
	key(code,true);key(code,false)

func motion(v: Vector2,p: Vector2=Vector2(480,300)) -> void:
	var e:=InputEventMouseMotion.new()
	e.position=p;e.global_position=p;e.relative=v;e.screen_relative=v
	root.push_input(e,true)

func mouse(index: MouseButton,down: bool,p:Vector2=Vector2(480,300)) -> void:
	var e:=InputEventMouseButton.new()
	e.button_index=index;e.pressed=down;e.position=p;e.global_position=p
	root.push_input(e,true)

func click(control: Control) -> bool:
	if control==null or not control.is_visible_in_tree():return false
	var anc=control.get_parent()
	while anc!=null:
		if anc is ScrollContainer:anc.ensure_control_visible(control)
		anc=anc.get_parent()
	await frames(2)
	var p:=control.get_global_rect().get_center()
	motion(Vector2.ZERO,p)
	var hovered:=root.gui_get_hovered_control()
	seen.last_click=[control.name, p, hovered.get_path() if hovered else "",control.get_global_rect(),root.get_visible_rect()]
	mouse(MOUSE_BUTTON_LEFT,true,p);mouse(MOUSE_BUTTON_LEFT,false,p)
	return true

func frames(n: int) -> void:
	for i in n:await process_frame

func hud() -> Dictionary:
	return main._root.field_view("hud").value

func committed(ticks:int) -> bool:
	var initial: int=main._last_tick
	for i in 80:
		await process_frame
		if main._last_tick>=initial+ticks:return true
	return check(false,"simulation advances",initial)

func wait_phase(phases: Array,budget:=25) -> bool:
	var until: int=main._last_tick+budget
	while main._last_tick<=until:
		var phase: String=hud().player.phase
		if phase in phases:return true
		if not await committed(1):return false
	return false

func order_kind(id: int) -> String:
	for row in hud().formations:
		if row.id==id and row.get("active") is Dictionary and row.active.get("issuer_id")=="player":
			return row.active.order_type
	return ""

func body_parts(first: bool) -> bool:
	var h: Dictionary=hud().actor_handle
	var p: Variant=scene._visuals._actors.get(h.index)
	if p==null or p.figure==null or not p.figure.root.is_visible_in_tree():return false
	var found := 0
	var equipment := 0
	for part: MeshInstance3D in p.figure.root.find_children("*","MeshInstance3D",true,false):
		var only_shadow := part.cast_shadow==GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
		if part.name in [&"body",&"garment-hair",&"garment-helmet",&"garment-hat",&"garment-beard",&"garment-scarf"]:
			found+=1
			if only_shadow!=first:return false
		elif part.is_visible_in_tree() and not only_shadow:equipment+=1
	seen["own_parts"]="head/body=%d, visible equipment=%d"%[found,equipment]
	return found>0 and equipment>0

func screenshot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img:=root.get_texture().get_image()
	if img!=null: img.save_png(OS.get_environment("FIELD_CONTROLS_CAPTURE")+"/"+name+".png")

func checks() -> void:
	var expected_native := OS.get_environment("FIELD_CONTROLS_NATIVE")=="1"
	if not check(DisplayServer.get_name()!="headless" and root.size==Vector2i(960,600),"desktop at 960x600",[DisplayServer.get_name(),root.size]):return
	if not check(ClassDB.class_exists(&"FieldMoveKernel")==expected_native,"expected loader and extension mode",expected_native):return
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(3)
	if not check(await click(button("进入河原野战")),"menu opens real field via pointer"):return
	await frames(3)
	scene=main._field_scene
	if not check(scene!=null and not scene.running and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"deployment pointer free"):return
	var group:=node_button("Group1")
	if not check(await click(group),"deployment formation button click"):return
	await frames(1)
	if not check(scene._input_port.view().selection.size()>0,"deployment picks formation",scene._input_port.view()):return
	if not check(await click(button("开始野战")),"start field via visible button"):return
	if not await committed(5):return
	await frames(2)
	var actor_handle: Dictionary=hud().actor_handle
	if not check(hud().formations.size()>=4 and scene.running and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"battle captured",Input.mouse_mode):return
	if not check(scene._visuals.report().visible_actors>=500,"full-size scene presented",scene._visuals.report()):return
	var prev_pose:=hud()
	var previous_forward: Vector3=-scene._camera.global_basis.z
	var previous_right: Vector3=scene._camera.global_basis.x
	main.set_physics_process(false)
	var fixed_tick: int=main._last_tick
	motion(Vector2(45,-36))
	await frames(3)
	var looking: Vector3=-scene._camera.global_basis.z
	if not check(main._last_tick==fixed_tick and (looking-previous_forward).dot(previous_right)>.025 and looking.y>previous_forward.y+.02,"same committed tick: pointer right/up turns rendered camera right/up",[previous_forward,looking,main._last_tick]):return
	main.set_physics_process(true)
	if not await committed(2):return
	var before: Dictionary=hud()
	key(KEY_W,true)
	if not await committed(12):return
	seen.w_input = scene._input_port._last_result
	seen.w_start = [before.tick, before.position, scene._input_port.view().mode]
	var movement: Variant = main._root._field_mission.get_ref()._move
	seen.w_trace = []
	for i in 30:
		seen.w_trace.append([main._last_tick, movement.view(actor_handle).value])
		if hud().position.distance_to(before.position)>.3:break
		if not await committed(4):return
	seen.w_end = [hud().tick, hud().position]
	key(KEY_W,false)
	var after:=hud()
	var move_dir:Vector3=after.position-before.position
	var flat:=Vector3(looking.x,0,looking.z).normalized()
	if not check(move_dir.dot(flat)>.23 and move_dir.normalized().dot(flat)>.9,"W advances along visible camera heading",[move_dir,flat,before.tick,after.tick]):return
	tap(KEY_CAPSLOCK);key(KEY_W,true);await committed(2)
	var walking: Dictionary=scene._input_port._last_result.value.batch.inputs[-1]
	if not check(walking.get("stance")=="walk" and walking.get("speed_fraction")==1.0,"Caps Lock and W send walking to the battle",walking):return
	key(KEY_Z,true);await committed(2)
	var crouching: Dictionary=scene._input_port._last_result.value.batch.inputs[-1]
	if not check(crouching.get("stance")=="crouch" and crouching.get("speed_fraction")==1.0,"Z and W send crouching to the battle",crouching):return
	key(KEY_Z,false);key(KEY_W,false);tap(KEY_CAPSLOCK)
	var view:=scene._input_port.view() as Dictionary
	var combat_dir: Variant=view.direction
	var view_forward: Vector3=-scene._camera.global_basis.z
	var head_before:Vector3=hud().heading
	var aim_before:Variant=view.preview_aim
	key(KEY_QUOTELEFT,true);motion(Vector2(55,12))
	await frames(3)
	view=scene._input_port.view()
	if not check(view.free_look and (-scene._camera.global_basis.z).distance_to(view_forward)>.045 and view.preview_aim==aim_before and view.direction==combat_dir and hud().heading.is_equal_approx(head_before),"free look rotates camera without changing aim or attack direction",view):return
	key(KEY_QUOTELEFT,false)
	await frames(8)
	if not check(not scene._input_port.view().free_look and (-scene._camera.global_basis.z).distance_to(view_forward)<.025,"free-look release recentres",[view_forward,-scene._camera.global_basis.z]):return
	var normal_fov:float=scene._camera.fov
	key(KEY_SHIFT,true);await frames(3)
	if not check(scene._input_port.view().zoom_held and scene._camera.fov<normal_fov-1,"Shift narrows camera FOV",[normal_fov,scene._camera.fov]):return
	key(KEY_SHIFT,false);await frames(4)
	if not check(absf(scene._camera.fov-normal_fov)<.1,"zoom restored on release",scene._camera.fov):return
	var base_distance: float=scene._camera._chase_distance
	tap(KEY_KP_SUBTRACT);await frames(2)
	if not check(is_equal_approx(scene._camera._chase_distance,base_distance+.35),"keypad minus pulls the chase camera back",[base_distance,scene._camera._chase_distance]):return
	tap(KEY_KP_ADD);await frames(2)
	if not check(is_equal_approx(scene._camera._chase_distance,base_distance),"keypad plus restores chase distance",scene._camera._chase_distance):return
	if not check(body_parts(false),"visible own figure in third person",actor_handle):return
	tap(KEY_R);await frames(3)
	if not check(scene._camera.state().mode=="first" and body_parts(true),"first-person own geometry hidden",scene._camera.state()):return
	var nearby_visible:=0
	for p in scene._visuals._actors.values():
		if p.index!=actor_handle.index and p.figure!=null and p.figure.root.is_visible_in_tree():
			for skin: MeshInstance3D in p.figure.root.find_children("body","MeshInstance3D",true,false):
				if skin.cast_shadow!=GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY:nearby_visible+=1
	if not check(nearby_visible>0,"other characters remain visible in first person",nearby_visible):return
	await screenshot("first")
	tap(KEY_R);await frames(4)
	if not check(scene._camera.state().mode in ["third","mounted"] and body_parts(false),"third-person figure restored"):return
	await screenshot("third")
	motion(Vector2(42,1));mouse(MOUSE_BUTTON_LEFT,true)
	if not check(await wait_phase(["Windup","Hold"]),"left press begins authoritative attack",hud().player):return
	if not await committed(8):return
	if not check(hud().player.direction=="right","right mouse motion selected right swing",hud().player):return
	mouse(MOUSE_BUTTON_LEFT,false)
	if not check(await wait_phase(["Active","Recovery"]),"left release swings",hud().player):return
	if not check(await wait_phase(["Ready"],65),"melee recovers"):return
	motion(Vector2(-38,1));mouse(MOUSE_BUTTON_RIGHT,true)
	if not check(await wait_phase(["Guard"]) and hud().player.direction=="left","right press guards left",hud().player):return
	mouse(MOUSE_BUTTON_RIGHT,false)
	if not check(await wait_phase(["Ready"]),"guard releases"):return
	key(KEY_TAB,true);await frames(3)
	var board:Label=scene._hud.find_child("FieldInfo",true,false)
	if not check(scene._input_port.view().score_held and board.is_visible_in_tree() and not board.text.is_empty() and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"Tab shows strength while retaining combat capture",board.text):return
	key(KEY_TAB,false);await frames(2)
	if not check(not scene._input_port.view().score_held,"Tab release closes scoreboard"):return
	tap(KEY_1)
	var selected: Array=scene._input_port.view().selection
	if not check(selected.size()==1,"1 selects first formation",selected):return
	tap(KEY_F1);tap(KEY_F3)
	if not await committed(5):return
	seen.charge=order_kind(selected[0])
	if not check(seen.charge in ["charge","free_attack"] and Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"F1/F3 formation attack published while captured",seen.charge):return
	motion(Vector2(0,190));await frames(3)
	tap(KEY_F1);tap(KEY_F1)
	if not await committed(5):return
	seen.move=order_kind(selected[0])
	if not check(seen.move=="move","F1/F1 publishes move to centre-screen terrain",scene._input_port.view()):return
	tap(KEY_ESCAPE);await frames(2)
	if not check(Input.mouse_mode==Input.MOUSE_MODE_VISIBLE and scene._input_port.view().mode=="ui","Esc opens HUD and releases cursor",scene._input_port.view()):return
	await screenshot("hud")
	var heading_at_ui: Vector3=hud().heading
	motion(Vector2(55,0));await committed(2)
	if not check(hud().heading.is_equal_approx(heading_at_ui),"pointer motion in HUD leaves aim unchanged"):return
	tap(KEY_ESCAPE);await frames(2)
	if not check(Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"Esc returns to combat"):return
	key(KEY_W,true);await committed(2)
	root.gui_embed_subwindows=false
	var focus_probe := Window.new()
	focus_probe.title="field controls QA focus"
	focus_probe.size=Vector2i(240,96)
	focus_probe.position=root.position+Vector2i(40,40)
	root.add_child(focus_probe)
	focus_probe.show()
	focus_probe.grab_focus()
	await frames(4)
	if not check(not root.has_focus() and focus_probe.has_focus(),"real auxiliary OS window takes focus",[root.has_focus(),focus_probe.has_focus()]):return
	if not check(Input.mouse_mode==Input.MOUSE_MODE_VISIBLE and scene._input_port.view().mode=="ui","window focus loss releases capture and opens controls"):return
	key(KEY_W,false)
	focus_probe.hide()
	focus_probe.queue_free()
	root.grab_focus()
	await frames(4)
	if not check(root.has_focus(),"main OS window regained focus"):return
	if not check(Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"focus regain awaits explicit resume"):return
	node_button("Resume").pressed.connect(func(): seen.resume_pressed=true)
	if not check(await click(node_button("Resume")),"click Continue after focus return"):return
	await frames(2)
	if not check(Input.mouse_mode==Input.MOUSE_MODE_CAPTURED,"explicit resume recaptures after focus return",[seen.last_click,seen.get("resume_pressed"),scene._input_port.view().mode,scene._hud._view.phase]):return
	var stopped: Vector3=hud().position
	await committed(4)
	if not check(hud().position.distance_to(stopped)<.01,"held W cleared on focus loss",[stopped,hud().position]):return
	if expected_native:
		var calls: int=ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")
		if not check(calls>0,"optimized real native movement executed",calls):return
	tap(KEY_ESCAPE);await frames(2)
	if not check(await click(node_button("Withdraw")),"click HUD withdraw"):return
	await frames(2)
	if not check(await click(node_button("Confirm")),"click withdraw confirmation"):return
	for i in 80:
		await process_frame
		if main._root.session().query().value.state=="Results":break
	if not check(main._root.session().query().value.state=="Results" and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"results cursor free",[main._root.session().query().value.state,scene._hud._receipt,scene._hud._view.phase,Input.mouse_mode,seen.last_click]):return
	await frames(3)
	if not check(await click(node_button("Leave")),"leave results through HUD"):return
	await frames(2)
	check(main._field_scene==null and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE,"returned to menu with normal cursor")

func run() -> void:
	await checks()
	var data={"checks":results,"extra":seen,"passed":not failed,"renderer":DisplayServer.get_name()}
	var out:=FileAccess.open(OS.get_environment("FIELD_CONTROLS_CAPTURE")+"/result.json",FileAccess.WRITE)
	out.store_string(JSON.stringify(data,"  "))
	out.close()
	print("FIELD_CONTROL_QA checks=",results.size()," pass=",not failed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(failed))
