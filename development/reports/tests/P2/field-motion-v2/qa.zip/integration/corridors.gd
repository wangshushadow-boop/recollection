extends "res://tests/p2/field_pipeline/run.gd"

func phase_result(_key,_value): pass
func member_rows(_n): pass
func ai_metrics(_metrics): pass

class CountMovement extends "res://mission/movement/ports/field_movement.gd":
	var updates := {}
	var slots := 0

	func set_corridor(group: String, origin: Vector3, goal: Vector3, profile: String = "foot", stage: Variant = null) -> Dictionary:
		if stage != null: updates[group] = updates.get(group,0) + 1
		return super.set_corridor(group,origin,goal,profile,stage)

	func assign(handle: Dictionary, group: String, offset: Vector3 = Vector3.ZERO, stage: Variant = null) -> Dictionary:
		if stage != null: slots += 1
		return super.assign(handle,group,offset,stage)

func run() -> void:
	var compiler:=Compiler.new()
	var compiled:=compiler.compile(compiler.scan_packages([Compiler.BASE_PACKAGE,"res://content/base/field"]),{})
	if ok(compiled,"load field definitions"):
		registry=compiled.value.registry
		adapter=EngineAdapter.new(root,true)
		site_positions=[[],[]]
		for i in 6:
			site_positions[0].append([-6000,0,(i-2)*1800])
			site_positions[1].append([6000,0,(i-2)*1800])
		if await open(battle(["infantry","cavalry"],[3,3],6)):
			var observed := CountMovement.new(adapter,scope,mission._drive_authorized)
			mission._move = observed
			if ok(mission.step_fixed(1,[]),"commit opening layouts"):
				check(observed.slots==12 and observed.updates.size()==4,"all soldiers assigned in four lanes")
				print("FORM_CORRIDORS slots=",observed.slots," group_calls=",observed.updates)
	if mission!=null: mission.dispose()
	quit(int(failed>0))
