extends "res://tests/p2/field_pipeline/run.gd"
func run() -> void:
	var compiler := Compiler.new()
	var definitions := compiler.compile(compiler.scan_packages([Compiler.BASE_PACKAGE,"res://content/base/field"]),{})
	if ok(definitions,"load field definitions"):
		registry=definitions.value.registry
		adapter=EngineAdapter.new(root,true)
		await hero_and_mount()
		await real_jump()
		check(adapter.counts().scopes==0,"both Mission scopes released")
	print("MOTION_V2_MOUNT_JUMP checks=",checks," failures=",failed)
	quit(int(failed>0))
