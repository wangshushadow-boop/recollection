import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


here=Path(__file__).resolve().parent
repo=here.parents[1]
game=(Path(sys.argv[1]) if len(sys.argv)>1 else repo/"game").resolve()
target=here/"final"
target.mkdir(exist_ok=True)
profile=target/"profile"
profile.mkdir(exist_ok=True)
env=dict(os.environ,APPDATA=str(profile),LOCALAPPDATA=str(profile))
engine="D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"
baseline=here/"baseline"
baseline.mkdir(exist_ok=True)
for name in ["summary.json","behavior.json"]:
    if not (baseline/name).is_file():
        (baseline/name).write_bytes((repo/"out/sparse-qa/final"/name).read_bytes())

trace=[sys.executable,str(here/"run.py"),"final",str(game),"--against","baseline","--count","500"]
status={}
retry_move="--retry-move-only" in sys.argv
if retry_move:
    status=json.loads((target/"checks.json").read_text(encoding="utf-8"))["runs"]
    (target/"move-original-wrapper.log").write_bytes((target/"move.log").read_bytes())
    status["move_wrapper_attempt"]=dict(status["move"])
scripts=[(name,str(here/(name+".gd"))) for name in ["field_engine","move","mount_jump"]]
for name,script in scripts:
    if retry_move and name!="move": continue
    command=[engine,"--headless","--fixed-fps","60","--path",str(game),"--log-file",str(target/(name+"-engine.log")),"--script",script]
    result=subprocess.run(command,capture_output=True,timeout=120,env=env)
    out=(result.stdout+result.stderr).decode("utf-8",errors="replace")
    (target/(name+".log")).write_text(out,encoding="utf-8")
    status[name]={"command":command,"exit":result.returncode,"pass":result.returncode==0 and " failures=0" in out and "ERROR:" not in out,"last_line":out.strip().splitlines()[-1]}
    print(name,status[name],flush=True)
result=None if retry_move else subprocess.run(trace,check=False)
summary=json.loads((target/"summary.json").read_text(encoding="utf-8"))
trace_exit=result.returncode if result is not None else status["behavior"]["exit"]
status["behavior"]={"command":trace,"exit":trace_exit,"pass":trace_exit==0 and summary["comparison"]["same_ticks"]==1260 and summary["trace_sha256"]=="8f52df5f89f6d652ff9beaa6cdc7ee0132c90bf2056f3de366747d6c1b8405a8" and "ROLLBACK PASS attempted_tick=986 last_committed=985 visual_unchanged=true" in (target/"behavior.log").read_text(encoding="utf-8")}
hashes={}
# Record both the timed modules and any additional game code in this candidate.
changes=subprocess.run(["git","diff","--name-only","d073df6","--","game"],cwd=game.parent,capture_output=True,text=True)
changed=changes.stdout.splitlines() if changes.returncode==0 else []
rels={"mission/movement/ports/field_movement.gd","infrastructure/engine/field_bodies.gd","mission/runtime/field_pipeline.gd"}
rels.update(path.removeprefix("game/") for path in changed if path.endswith(".gd"))
for rel in sorted(rels):
    hashes[rel]=hashlib.sha256((game/rel).read_bytes()).hexdigest()
(target/"checks.json").write_text(json.dumps({"runs":status,"sha256":hashes},indent=2),encoding="utf-8")
with ZipFile(here/"qa.zip","w",ZIP_DEFLATED) as z:
    for name in ["check_and_pack.py","behavior.gd","field_engine.gd","move.gd","mount_jump.gd","run.py","baseline/summary.json","baseline/behavior.json","final/summary.json","final/checks.json","final/behavior.json","final/behavior.log"]+[f"final/{name}.log" for name,_ in scripts]:
        z.write(here/name,name)
    if retry_move:z.write(target/"move-original-wrapper.log","final/move-original-wrapper.log")
ok=all(v["pass"] for k,v in status.items() if k!="move_wrapper_attempt")
print("PASS" if ok else "FAIL",flush=True)
sys.exit(int(not ok))
