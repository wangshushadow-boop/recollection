extends "res://tests/p2/field_engine/run.gd"

func unchanged_bodies() -> void:
	super.unchanged_bodies()
	var left := frozen_actor(91,1,-11)
	var right := frozen_actor(92,1,11)
	var lost := frozen_actor(91,2,-5)
	check(engine.field_stage_bodies(A,[left,right]).ok and engine.field_commit_bodies(A).ok,"start ordered body snapshot")
	check(engine.field_stage_bodies(A,[right,lost]).ok,"same-size reordered snapshot can replace generation")
	check(regions(sweep(A,-5,1.1),lost.handle)==["body"] and sweep(A,-11,1.1).is_empty(),"reordered target is visible to staged physics")
	check(engine.field_rollback_bodies(A).ok and regions(sweep(A,-11,1.1),left.handle)==["body"] and sweep(A,-5,1.1).is_empty(),"rollback restores the old ordering and transforms")
	check(engine.field_stage_bodies(A,[right,left]).ok and engine.field_commit_bodies(A).ok,"commit permutation of the original immutable inputs")
	check(engine.field_stage_bodies(A,[right,lost]).ok and engine.field_commit_bodies(A).ok,"only one changed slot in committed new order")
	var stale: Dictionary=engine.field_stage_bodies(A,[right,left])
	check(not stale.ok and stale.error.code=="StaleVersion" and regions(sweep(A,-5,1.1),lost.handle)==["body"],"old frozen source rejected after replacement")
