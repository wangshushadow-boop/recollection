extends "res://tests/p2/field_pipeline/run.gd"

const HALF := 16
const TICKS := 180
var work := {}

func phase_result(key: String, value: int) -> void:
	work[key]=value

func member_rows(_n:int) -> void: pass
func ai_metrics(_metrics:Dictionary) -> void: pass

func run()->void:
	var compiler:=Compiler.new()
	var defs:=compiler.compile(compiler.scan_packages([Compiler.BASE_PACKAGE,"res://content/base/field"]),{})
	if not ok(defs,"compile definitions"):quit(1);return
	registry=defs.value.registry
	adapter=EngineAdapter.new(root,true)
	brain_script=load("res://mission/runtime/field_brains.gd")
	site_positions=[[],[]]
	for side in 2:
		var sign_x:=1 if side==1 else -1
		for i in HALF:
			site_positions[side].append([sign_x*(600+int(i/8)*900),0,(i%8)*900-3150])
	var spec:=battle(["infantry"],[HALF],HALF)
	spec.rules.wave_size=HALF
	if not await open(spec):quit(1);return
	var side_by_index:={}
	var origin:={}
	var hitters:={}
	var damaged:={}
	var samples:=[]
	var first_hit:=0
	var shots:=0
	var digest:=HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	for tick in range(1,TICKS+1):
		await physics_frame
		work={}
		var start:=Time.get_ticks_usec()
		var step:Dictionary=mission.step_fixed(tick,[])
		var elapsed:=Time.get_ticks_usec()-start
		if not ok(step,"fixed step"):quit(1);return
		for row in step.value.entities:
			side_by_index[row.handle.index]=row.components.team_key
		if tick==1:
			if not check(side_by_index.size()==2*HALF,"full infantry deployment"):quit(1);return
			if not ok(mission.gateway("field.order",checked_order("player",1,"free_attack",{},hud().formations[0].control_revision),token),"free attack"):quit(1);return
		var view:Dictionary=mission.gateway("field.view",{"projection":"visual"},token)
		if not ok(view,"poses"):quit(1);return
		var left:=[]
		var right:=[]
		var pairs:=0
		var neighbors:={}
		var moved:=0
		for actor in view.value.actors:
			if not origin.has(actor.handle.index):origin[actor.handle.index]=actor.position
			if actor.position.distance_squared_to(origin[actor.handle.index])>0.01:moved+=1
			if actor.get("phase","")=="Downed" or actor.get("hp",1)==0:continue
			if is_same(side_by_index[actor.handle.index],0):left.append(actor)
			else:right.append(actor)
		for a in left:
			for b in right:
				if a.position.distance_squared_to(b.position)<=4.0:
					pairs+=1
					neighbors[a.handle.index]=true
					neighbors[b.handle.index]=true
		var hits:=0
		var damage:=0
		var events:=[]
		for report in step.value.system_reports:
			if report.id!="field.combat":continue
			events=[report.value.hits,report.value.events]
			for hit in report.value.hits:
				if hit.damage>0 and not hit.blocked and not is_same(side_by_index[hit.attacker.index],side_by_index[hit.target.index]):
					hits+=1
					damage+=hit.damage
					hitters[hit.attacker.index]=true
					damaged[hit.target.index]=true
					if not first_hit:first_hit=tick
			for event in report.value.events:
				if event.type=="projectile_launched":shots+=1
		digest.update(var_to_bytes([tick,view.value.actors,events]))
		samples.append([tick,elapsed,work,pairs,neighbors.size(),moved,hits,damage])
	var result:={"samples":samples,"first_melee_hit":first_hit,"distinct_attackers":hitters.size(),"distinct_victims":damaged.size(),"projectiles":shots,"trace_sha256":digest.finish().hex_encode()}
	var output:=FileAccess.open(OS.get_environment("DENSE_CAPTURE"),FileAccess.WRITE)
	output.store_string(JSON.stringify(result))
	output.close()
	ok(mission.dispose(),"dispose")
	check(shots==0 and first_hit>0 and hitters.size()>=2 and damaged.size()>=2,"actual multi-soldier melee contacts")
	print("DENSE checks=",checks," failures=",failed," first=",first_hit," attackers=",hitters.size()," victims=",damaged.size()," trace=",result.trace_sha256)
	quit(int(failed>0))
