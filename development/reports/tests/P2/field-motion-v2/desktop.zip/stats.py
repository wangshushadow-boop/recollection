import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path

here = Path(__file__).resolve().parent
def dist(rows):
    samples = sorted(rows)
    return {"mean":round(statistics.mean(samples),3), **{f"p{q}":round(samples[math.ceil(len(samples)*q/100)-1],3) for q in (50,95)}}

def segment(data, lo, hi):
    ticks = [s for s in data["steps"] if lo <= s[0] <= hi]
    assert [s[0] for s in ticks] == list(range(lo,hi+1))
    by_tick = {s[0]: s[1] for s in ticks}
    frames = [(b[1]-a[1],b[2],b[3],sum(by_tick[t] for t in range(a[1]+1,b[1]+1))) for a,b in zip(data["frames"],data["frames"][1:]) if b[0]=="battle" and lo-1<=a[1]<=b[1]<=hi]
    assert frames and max(f[0] for f in frames)<=2
    seconds = sum(f[1] for f in frames)/1e6
    return {"range":[lo,hi],"frames":len(frames),"per_frame_steps":Counter(f[0] for f in frames),
        "frame_ms":dist(f[1]/1000 for f in frames),"gpu_ms":dist(f[2] for f in frames),
        "outside_field_step_ms_per_frame":dist((f[1]-f[3])/1000 for f in frames),
        "fps":round(len(frames)/seconds,3),"steps_per_second":round(sum(f[0] for f in frames)/seconds,3),
        "field_step_ms":dist(s[1]/1000 for s in ticks), **{k+"_ms":dist(s[2][k]/1000 for s in ticks) for k in ["_think","_walk","_fight","prepare","grid","advance","read_poses","physics_stage"]},
        **{k:dist(s[2][k] for s in ticks) for k in ["neighbor_checks","yielding","physics_writebacks"]},
        "full_ai_rows_per_step":dist(s[2].get("full_rows",0) for s in ticks),"steps_with_full_ai_rows":sum(bool(s[2].get("full_rows")) for s in ticks),
        "admitted_individuals_per_step":dist(s[2]["due"] for s in ticks),"positive_hits":sum(s[3] for s in ticks),"damage":sum(s[4] for s in ticks),"shots":sum(s[5] for s in ticks)}

def load(label,scenario):
    path=here/f"{label}-{scenario}.json"
    d=json.loads(path.read_text(encoding="utf-8"))
    assert d["cap"]==2 and d["window"]=="(960, 600)" and d["hz"]==60 and d["soldiers"]==500 and d["entities"]==600
    assert len(d["commands"]) == (5 if scenario=="contact" else 0)
    return d

def summarize(label):
    data={}
    for scenario in ["idle","contact"]:
        d=load(label,scenario)
        bounds=[121,440] if scenario=="idle" else [d["first_hit"],1260]
        if scenario=="contact":
            assert 1<bounds[0]<1260
        data[scenario]=dict(first_hit=d["first_hit"],cpu=d["cpu"],gpu=d["gpu"],**segment(d,*bounds))
        if scenario=="contact":
            assert d["first_hit"]>440
            data["march"]=dict(first_hit=d["first_hit"],cpu=d["cpu"],gpu=d["gpu"],**segment(d,121,440))
    return data

if __name__=="__main__":
    labels=sys.argv[1:]
    all_data={label:summarize(label) for label in labels}
    if len(labels)==2:
        for scenario in ["idle","contact"]:
            a,b=[load(label,scenario) for label in labels]
            n=440 if scenario=="idle" else 1260
            assert a["commands"]==b["commands"] and a["first_hit"]==b["first_hit"] and a["gpu"]==b["gpu"] and a["cpu"]==b["cpu"]
            assert [(s[0],s[2]["due"],s[3:]) for s in a["steps"][:n]]==[(s[0],s[2]["due"],s[3:]) for s in b["steps"][:n]]
            for field in ("yielding","physics_writebacks"):
                assert [s[2][field] for s in a["steps"][:n]]==[s[2][field] for s in b["steps"][:n]], (scenario,field)
        all_data["workload_check"]="Commands, tick-by-tick admitted individuals, yields, actual proxy placements, positive hostile hit counts, damage and projectile counts match across each entire scenario."
    out=json.dumps(all_data,indent=2,ensure_ascii=False)
    (here/("summary.json" if len(labels)==2 else labels[0]+"-summary.json")).write_text(out,encoding="utf-8")
    print(out)
