# 河原野战移动第二版桌面采样

Godot 4.7.2 Standard，Windows 桌面 Vulkan Forward+，960×600。种子 241124、500 名士兵和 100 匹马，60 Hz，每显示帧最多补算 2 步。独立进程从主菜单进入河原，等待部署 45 帧，点击开始。站立场景无输入，取 121–440 步。接战场景在第 1 步后对四个阵型分别下达移动命令，第 900 步发自由攻击，取首次有效命中到 1260 步。玩家在两个场景中均站立。每个版本、每种场景各采样一次，不含资源初始化时间。

在仓库的 out/motion-v2-bench/ 下展开压缩包，使用项目的已导入资源缓存。基线提交在 manifest.json 的 git_base 中，final.patch 记录从该提交到采样候选的冻结差异，final-sources.json 是加入探针前的脚本校验和。复现时使用交付的代码提交，或在独立检出中应用 final.patch 后将候选参数设为 worktree。prepare.py 建立新项目副本，运行前须选择对应副本目录尚未建立的工作目录，或将旧副本移到另一个名称。

march 为接战进程内第 121–440 步的前进窗口。contact 按有效命中选取，可能含远程命中。另有 16 对 16 步兵近距离无头诊断，使用生产 AI、Mission 和 Jolt。以 8 列两排间距 0.9 m 的站位开局，双方前排相距 1.2 m，第一步向己方发自由攻击，之后运行 180 步。每步在计时外统计敌对近邻（≤2 m）和血量伤害，核对零投射物、多个独立攻击者与目标，以及同样的位姿／事件轨迹。该夹具使用测试平坦导航地面，不与 500 人桌面帧率混算。无头耗时采样仅作诊断。

```powershell
python out/motion-v2-bench/prepare.py base d073df6
& ./out/motion-v2-bench/run.ps1 base
python out/motion-v2-bench/prepare.py final <交付代码提交>
& ./out/motion-v2-bench/run.ps1 final
python out/motion-v2-bench/stats.py base final
$env:DENSE_CAPTURE="$pwd/out/motion-v2-bench/base-dense.json"
& 'D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe' --headless --fixed-fps 60 --path out/motion-v2-bench/base/game --script "$pwd/out/motion-v2-bench/dense.gd"
$env:DENSE_CAPTURE="$pwd/out/motion-v2-bench/final-dense.json"
& 'D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe' --headless --fixed-fps 60 --path out/motion-v2-bench/final/game --script "$pwd/out/motion-v2-bench/dense.gd"
python out/motion-v2-bench/dense_stats.py
python out/motion-v2-bench/package.py base final
```

每步记录阶段总耗时及工作量，每帧记录 frame_post_draw 时间。只纳入两个帧边界均在采样区间的完整帧，按墙钟时间算 FPS 与每秒实际推进的战斗步数。帧分位数与战斗步分位数分别统计。GPU 时间取 Godot viewport 渲染监测值。计时点和日志仅出现在采样副本。

阶段 prepare 为 MOV 路线、成员接入、直接驱动和水平障碍检查；grid 为 MOV 准备空间网格；advance 为地面或空中推进、避让及相关处理；read_poses 为提交前读取位姿列；physics_stage 为物理代理的所有校验、运动与增删。neighbor_checks 和 yielding 取 MOV 内置计数；physics_writebacks 计入实际调用 _place 的代理个数，涵盖多个碰撞形状的代理只计一次。stats.py 校验所有步上的个体 AI 调度数、命中、伤害、发射以及下达的命令。summary.json 为分布与各段均值，原始 JSON 和日志可逐步、逐帧审查。
