import io
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
label = sys.argv[1]
dest = here / label / "game"
commit = sys.argv[2]
assert label!="base" or commit=="d073df6"
revision = "HEAD" if commit=="worktree" else commit
archive = subprocess.check_output(["git", "archive", "--format=zip", revision, "game"], cwd=repo)
zipfile.ZipFile(io.BytesIO(archive)).extractall(dest.parent)
if commit=="worktree":
    dirty = subprocess.check_output(["git","diff","--name-only","HEAD","--","game"],cwd=repo,text=True).splitlines()
    for rel in dirty:
        shutil.copy2(repo/rel,dest.parent/rel)
    (here/f"{label}.patch").write_bytes(subprocess.check_output(["git","diff","--binary","HEAD","--","game"],cwd=repo))
shutil.copytree(repo/"game/.godot",dest/".godot")
(here/f"{label}-commit.txt").write_text(subprocess.check_output(["git","rev-parse",revision],cwd=repo,text=True).strip(),encoding="utf-8")
sources = {str(p.relative_to(dest)).replace('\\','/'):hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in dest.rglob('*.gd')}
(here/f"{label}-sources.json").write_text(json.dumps(sources,indent=2),encoding="utf-8")

def replace(path, old, new):
    p = dest / path
    src = p.read_text(encoding="utf-8")
    assert src.count(old) == 1, (p, old)
    p.write_text(src.replace(old, new), encoding="utf-8")

root = "bootstrap/composition_root.gd"
sig = "func field_step() -> Dictionary:"
replace(root, sig, sig + '''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench_field_step()
	var elapsed := Time.get_ticks_usec() - begin_us
	if reply.ok: Engine.get_main_loop().call("step_complete",self,reply.value,elapsed)
	return reply

func _bench_field_step() -> Dictionary:''')
pipeline = "mission/runtime/field_pipeline.gd"
for name in ["_think","_walk","_fight"]:
    ctx = "ctx" if name == "_fight" else "_ctx"
    sig = f"func {name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:"
    replace(pipeline, sig, sig+f'''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench{name}({ctx},batch)
	var elapsed := Time.get_ticks_usec()-begin_us
	Engine.get_main_loop().call("phase_result","{name}",elapsed)
	return reply

func _bench{name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:''')
brains = "mission/runtime/field_brains.gd"
replace(brains, 'var published := _index(tick,nav,rows)', 'Engine.get_main_loop().call("member_rows",rows.size())\n\tvar published := _index(tick,nav,rows)')
replace(pipeline, 'return _brains.decide(tick,_draft.nav,units,_draft.com,player)', 'Engine.get_main_loop().call("member_rows",units.size())\n\treturn _brains.decide(tick,_draft.nav,units,_draft.com,player)')
mov = "mission/movement/ports/field_movement.gd"
def record(name,expr):
    return 'Engine.get_main_loop().call("phase_result","'+name+'",'+expr+')'
def timed(path, marker, next_marker, key):
    replace(path,marker,'var bench_'+key+' := Time.get_ticks_usec()\n\t'+marker)
    replace(path,next_marker,record(key,'Time.get_ticks_usec()-bench_'+key)+'\n\t'+next_marker)
timed(mov,'var ready := _prepare(tick)','_tick = tick\n\t_checks = 0','prepare')
timed(mov,'var bodies := _bodies.values()\n\t_prepare_grid(bodies)','if not _had_drives and _airborne_count==0:', 'grid')
timed(mov,'if not _had_drives and _airborne_count==0:', 'var shared: int = _queue.attempts_at(tick)', 'advance')
replace(mov, 'var shared: int = _queue.attempts_at(tick)', record('neighbor_checks','_checks')+'\n\t'+record('yielding','_yields')+'\n\tvar shared: int = _queue.attempts_at(tick)')
timed(pipeline,'var moved_poses:Dictionary=_move.read_poses(_draft.token,_draft.stage)','_draft["motion"]=moved_poses.value','read_poses')
bodies = "infrastructure/engine/field_bodies.gd"
sync='func _sync(next: Dictionary) -> void:'
replace(bodies,sync,sync+'\n\tvar placed_count := 0')
replace(bodies,'\t\t_place(index,row)\n\t_current = next','\t\tplaced_count += 1\n\t\t_place(index,row)\n\t'+record('physics_writebacks','placed_count')+'\n\t_current = next')
signature='func stage(rows: Array) -> Dictionary:'
replace(bodies,signature,signature+'\n\tvar begin := Time.get_ticks_usec()\n\tvar result := _bench_stage(rows)\n\t'+record('physics_stage','Time.get_ticks_usec()-begin')+'\n\treturn result\n\nfunc _bench_stage(rows: Array) -> Dictionary:')
replace(pipeline, '_draft["metrics"]=decision.value.metrics', '_draft["metrics"]=decision.value.metrics\n\tEngine.get_main_loop().call("ai_metrics",decision.value.metrics)')
shutil.copyfile(here/"bench.gd",dest/"bench.gd")
