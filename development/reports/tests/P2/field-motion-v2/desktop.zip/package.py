import hashlib
import json
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
labels = sys.argv[1:] or ['base','final']
files = ['prepare.py','run.ps1','stats.py','bench.gd','package.py','summary.json','README.md','dense.gd','dense_stats.py','dense-summary.json']
for label in labels:
    files += [f'{label}-commit.txt', *(f'{label}-{case}.{ext}' for case in ('idle','contact') for ext in ('json','log'))]
    files += [f'{label}-dense.json',f'{label}-dense.log']
    for extra in [f'{label}.patch',f'{label}-sources.json']:
        if (here/extra).is_file():
            files.append(extra)
manifest = {
    'git_base':{label:(here/f'{label}-commit.txt').read_text().strip() for label in labels},
    'working_tree_patches':{label:f'{label}.patch' for label in labels if (here/f'{label}.patch').exists()},
    'sha256':{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in files}
}
(here/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(here/'desktop.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in ['manifest.json',*files]:
        z.write(here/f,f)
with zipfile.ZipFile(here/'desktop.zip') as z:
    assert z.testzip() is None
