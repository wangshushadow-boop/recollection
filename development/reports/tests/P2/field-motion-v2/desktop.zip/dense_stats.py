from pathlib import Path
import json
import statistics
from stats import dist
root=Path(__file__).resolve().parent
dense={}
reference=None
for label in ["base","final"]:
    d=json.loads((root/f"{label}-dense.json").read_text())
    r=d.pop("samples")
    assert [s[0] for s in r]==list(range(1,181))
    observed=[s[3:] for s in r]
    if reference is not None:
        assert (d['trace_sha256'],observed)==reference
    reference=d['trace_sha256'],observed
    assert d['projectiles']==0 and min(d['distinct_victims'],d['distinct_attackers'])>=2 and d['first_melee_hit']>0
    assert statistics.mean(s[3] for s in r)>=32 and statistics.mean(s[4] for s in r)>=16
    dense[label]={**d,'ticks':len(r),'soldiers':32,'melee_positive_hits':sum(s[6] for s in r),'melee_damage':sum(s[7] for s in r),
                  'opposing_pairs_within_2m':dist(s[3] for s in r),'unique_infantry_with_enemy_within_2m':dist(s[4] for s in r),
                  'max_soldiers_that_moved_10cm':max(s[5] for s in r),
                  'field_step_ms':dist(s[1]/1000 for s in r),
                  **{k+'_ms':dist(s[2][k]/1000 for s in r) for k in ["_think","_walk","prepare","advance","physics_stage"]},
                  **{k:dist(s[2][k] for s in r) for k in ['neighbor_checks','yielding','physics_writebacks']}}
(root/'dense-summary.json').write_text(json.dumps(dense,indent=2),encoding='utf-8')
