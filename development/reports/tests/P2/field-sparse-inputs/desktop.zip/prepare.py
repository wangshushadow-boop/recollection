import io
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
repo = here.parents[1]
label = sys.argv[1]
dest = here / label / "game"
shutil.copytree(repo / "game", dest)
if label == "base":
    archive = subprocess.check_output(["git", "archive", "--format=zip", "9f8f7a7", "game"], cwd=repo)
    zipfile.ZipFile(io.BytesIO(archive)).extractall(dest.parent)
else:
    paths = ["game/mission/runtime/field_brains.gd","game/mission/runtime/field_pipeline.gd","game/mission/combat/ports/field_combat.gd"]
    (here/f"{label}-source.json").write_text(json.dumps({p:hashlib.sha256((dest.parent/p).read_bytes()).hexdigest() for p in paths}),encoding="utf-8")
    (here/f"{label}.patch").write_bytes(subprocess.check_output(["git","diff","--no-ext-diff","--binary","9f8f7a7","--",*paths],cwd=repo))

def replace(path, old, new):
    p = dest / path
    src = p.read_text(encoding="utf-8")
    assert src.count(old) == 1, (p, old)
    p.write_text(src.replace(old, new), encoding="utf-8")

root = "bootstrap/composition_root.gd"
sig = "func field_step() -> Dictionary:"
replace(root, sig, sig + '''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench_field_step()
	var elapsed := Time.get_ticks_usec() - begin_us
	if reply.ok: Engine.get_main_loop().call("step_complete",self,reply.value,elapsed)
	return reply

func _bench_field_step() -> Dictionary:''')
pipeline = "mission/runtime/field_pipeline.gd"
for name in ["_think","_walk","_fight"]:
    ctx = "ctx" if name == "_fight" else "_ctx"
    sig = f"func {name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:"
    replace(pipeline, sig, sig+f'''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench{name}({ctx},batch)
	var elapsed := Time.get_ticks_usec()-begin_us
	Engine.get_main_loop().call("phase_result","{name}",elapsed)
	return reply

func _bench{name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:''')
if label == "base":
    replace(pipeline, 'var player: Variant = _draft.player if', 'Engine.get_main_loop().call("member_rows", units.size())\n\tvar player: Variant = _draft.player if')
else:
    brains = "mission/runtime/field_brains.gd"
    # All-full publication on a roster/formation boundary, and the row-port fallback.
    replace(brains, 'var published := _index(tick,nav,rows)', 'Engine.get_main_loop().call("member_rows",rows.size())\n\tvar published := _index(tick,nav,rows)')
    replace(pipeline, 'return _brains.decide(tick,_draft.nav,units,_draft.com,player)', 'Engine.get_main_loop().call("member_rows",units.size())\n\treturn _brains.decide(tick,_draft.nav,units,_draft.com,player)')
replace(pipeline, '_draft["metrics"]=decision.value.metrics', '_draft["metrics"]=decision.value.metrics\n\tEngine.get_main_loop().call("ai_metrics",decision.value.metrics)')
shutil.copyfile(here/"bench.gd",dest/"bench.gd")
