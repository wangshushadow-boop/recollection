extends SceneTree

const GOALS := {"infantry":[46000,0,-4000],"archer":[31000,0,4000],"cavalry":[52000,0,-14000],"mounted_archer":[37000,0,12000]}
var contact := OS.get_environment("SPARSE_SCENARIO") == "contact"
var main: Node
var frames := []
var steps := []
var work := {}
var last_us := 0
var phase := "menu"
var phase_frames := 0
var done := false
var sequence := 0
var scope := ""
var sides := {}
var roles := {}
var engaged := false
var commands := []
var first_hit := 0
var opening_count := 0
var ending_tick := 0

func fail(reason: String) -> void:
	printerr("DESKTOP FAIL ",reason)
	quit(2)

func _initialize() -> void:
	start.call_deferred()

func start() -> void:
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	RenderingServer.viewport_set_measure_render_time(root.get_viewport_rid(),true)
	RenderingServer.frame_post_draw.connect(on_draw)

func press(caption: String) -> void:
	for n in main.find_children("*","Button",true,false):
		if n.text==caption and n.is_visible_in_tree():
			n.pressed.emit()
			return
	fail("missing "+caption)

func on_draw() -> void:
	if done:return
	var now := Time.get_ticks_usec()
	if last_us:
		frames.append([phase,main._last_tick,now-last_us,RenderingServer.viewport_get_measured_render_time_gpu(root.get_viewport_rid())])
	last_us=now
	phase_frames+=1
	if phase=="menu" and phase_frames==12:
		phase="entry"
		phase_frames=0
		press.call_deferred("进入河原野战")
	elif phase=="entry" and phase_frames==2:
		phase="deployment"
		phase_frames=0
	elif phase=="deployment" and phase_frames==45:
		phase="battle"
		phase_frames=0
		press.call_deferred("开始野战")
	elif phase=="battle" and main._last_tick >= (1260 if contact else 440):
		done=true
		save.call_deferred()
	elif phase=="battle" and (phase_frames>3000 or not main._running):
		fail("timeout or step failure")

func phase_result(layer: String, us: int) -> void:
	work[layer]=us

func member_rows(n: int) -> void:
	work["full_rows"]=n

func ai_metrics(metrics: Dictionary) -> void:
	work.due=metrics.individual
	for key in metrics:
		if key not in ["tick","individual","modes","role_modes"] and metrics[key] is int:
			work[key]=metrics[key]

func send(app: RefCounted, tick: int, groups: Array, kind: String, goal: Variant) -> void:
	var ids := []
	var revisions := {}
	for item in groups:
		ids.append(item.id)
		revisions[str(item.id)]=item.control_revision
	sequence+=1
	var id:="benchmark-order-%d"%sequence
	var order := {"mission_id":scope,"order_id":id,"issuer_id":"player","formation_ids":ids,
		"order_type":kind,"target_position":goal,"target_formation_id":null,"parameters":{},
		"issued_tick":tick+1,"client_sequence":sequence}
	var result: Dictionary=app.field_command("field.order",{"order":order,"revisions":revisions},tick,id)
	if not result.ok: fail(str(result)); return
	commands.append([tick,ids,kind,goal,revisions])

func step_complete(app: RefCounted,value: Dictionary,us: int) -> void:
	var tick: int=value.tick
	if tick==1:
		scope=app.session().query().value.mission_id
		opening_count=value.entities.size()
		for row in value.entities:
			sides[row.handle]=row.components.team_key
			if row.source_slot!=null: roles[row.handle]=row.components.troop_def_id.get_file()
		if opening_count!=600 or roles.size()!=500:fail("roster");return
	if contact and (tick==1 or (not engaged and tick%30==0)):
		var hud: Dictionary=app.field_view("hud")
		if not hud.ok:fail(str(hud));return
		var groups: Array=hud.value.formations.filter(func(g):return g.controllable and not g.members.is_empty())
		if tick==1:
			if groups.size()!=4:fail("formation count");return
			for group in groups:send(app,tick,[group],"move",GOALS[roles[group.members[0]]])
		elif not hud.value.targets.is_empty() or tick>=900:
			send(app,tick,groups,"free_attack",null)
			engaged=true
	var hits := 0
	var damage := 0
	var shots := 0
	for system in value.system_reports:
		if system.id!="field.combat":continue
		for hit in system.value.hits:
			if hit.damage>0 and not hit.blocked and sides.get(hit.attacker)!=sides.get(hit.target):
				hits+=1
				damage+=hit.damage
				if not first_hit:first_hit=tick
		for event in system.value.events:
			if event.type=="projectile_launched":shots+=1
	steps.append([tick,us,work,hits,damage,shots])
	work={}

func save() -> void:
	var file:=FileAccess.open(OS.get_environment("SPARSE_CAPTURE"),FileAccess.WRITE)
	if file==null: fail("capture output"); return
	file.store_string(JSON.stringify({"steps":steps,"frames":frames,"window":str(root.size),"hz":Engine.physics_ticks_per_second,
		"cap":Engine.max_physics_steps_per_frame,"cpu":OS.get_processor_name(),"gpu":RenderingServer.get_video_adapter_name(),
		"tick":main._last_tick,"first_hit":first_hit,"commands":commands,"soldiers":roles.size(),"entities":opening_count}))
	file.close()
	if contact and not first_hit:fail("no positive hostile hit");return
	print("DESKTOP PASS tick=",main._last_tick," first_hit=",first_hit," commands=",commands.size()," frames=",frames.size())
	main.notification(Node.NOTIFICATION_WM_CLOSE_REQUEST)
