import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

here=Path(__file__).resolve().parent
repo=here.parents[1]
files=["game/mission/runtime/field_brains.gd","game/mission/runtime/field_pipeline.gd","game/mission/combat/ports/field_combat.gd"]
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)
release=sys.argv[1] if len(sys.argv)>1 else "release"
patch=(here/f"{release}.patch").read_bytes()
(here/"candidate.patch").write_bytes(patch)
manifest={"base_commit":git("rev-parse","9f8f7a7").decode().strip(),"candidate_original_sources_sha256":json.loads((here/f"{release}-source.json").read_text()),"candidate_patch_sha256":hashlib.sha256(patch).hexdigest(),
"probe_sources_sha256":{str(p.relative_to(here)).replace(chr(92),"/"):hashlib.sha256(p.read_bytes()).hexdigest() for label in ["base",release] for rel in files+["game/bootstrap/composition_root.gd","game/bench.gd"] for p in [here/label/rel]}}
if len(sys.argv)>2:
    candidate=git("rev-parse",sys.argv[2]).decode().strip()
    for p in files:
        raw=(repo/p).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==manifest["candidate_original_sources_sha256"][p]
        assert raw.replace(b"\r\n",b"\n")==git("show",candidate+":"+p).replace(b"\r\n",b"\n")
    manifest["candidate_commit"]=candidate
(here/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
with zipfile.ZipFile(here/"desktop.zip","w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in ["README.md","bench.gd","prepare.py","stats.py","run.ps1","package.py","summary.json","manifest.json","candidate.patch"]:
        z.write(here/f,f)
    for label in ["base",release]:
        for scenario in ["idle","contact"]:
            for ext in ["json","log"]:
                f=f"{label}-{scenario}.{ext}"
                z.write(here/f,f)
