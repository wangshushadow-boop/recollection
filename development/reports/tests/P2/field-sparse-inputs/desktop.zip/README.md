# P2-FIELD-INTEGRATION-029 · 河原野战桌面对照

Godot 4.7.2 Standard，Windows 桌面 Vulkan Forward+，RTX 3090 / Core Ultra 9 285K，960×600。河原单机默认种子 241124，开场 500 名士兵和 100 匹马，60 Hz，最多每显示帧 2 个物理步。参照提交见 manifest.json，候选生产差异见 candidate.patch。

每版本各启动两次，自动从主菜单点击“进入河原野战”和“开始野战”。

- idle 维持站立且不下达指令，统计 121..440 步。
- contact 保持玩家角色站立。在第 1 步后，按兵种分别给四个可控队形下达同一组前进指令。每 30 步查看 HUD；首次看见敌方目标或达到 900 步时发出一次自由攻击。统计从首个真实敌对有效伤害起到 1260 步结束的连续区间，也纳入期间没有命中的步。两版各自的命令、首击、每步有效命中数/总伤害/发射数及完成的个体决策数由 stats.py 比对。初始兵力相同，运行时伤亡照常处理。

时间采在临时副本，正式源文件没有采样器。应用真实 field_step、_think、_walk、_fight 入口以同一种微秒计时器包围。计数对象为 AI 全行构建和收集成功的 individual 决策；稳定路径以列读取的任务不会计入全行数，名册或队形版本触发的全量构建仍会计入。AI full_rows 默认值 0。workload_check 仅覆盖列明的数据；全状态回滚对照另见独立 QA。

frame_post_draw 存储帧间隔和对应提交步号。FPS = 完整显示帧数 / 实时时间，steps/s = 这些帧完成的战斗步数 / 同一实时时间。帧必须完整落入稳定区间；单步指标包括区间内所有已提交步。GPU ms 来自窗口 viewport 测量。P50/P95 取排序后的 nearest-rank。初始化和调试打印均在计时窗外。每种组合实测一轮，没有跨次波动置信区间。

## 重跑

将归档解压到本仓库空的 out/sparse-bench/ 路径。使用已导入的 game 项目，以 Python 3 运行 prepare.py base。候选源码应与 manifest 指纹匹配，可在隔离检出中对 9f8f7a7 应用 candidate.patch，再运行 prepare.py final。副本目录已经存在时准备脚本会退出，防止误覆盖之前的运行。随后在 PowerShell 依次执行 run.ps1 base、run.ps1 final。运行 stats.py base final 得到 summary.json。run.ps1 默认使用本机 D:/Program/Godot/Standard 下的 4.7.2 控制台版引擎。如需直接审查结果，summary.json 是聚合值，四份原始 JSON 是逐帧/逐步数据，四份 .log 是引擎输出。
