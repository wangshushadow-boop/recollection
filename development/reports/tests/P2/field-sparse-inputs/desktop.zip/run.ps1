param([Parameter(Mandatory)][string]$Label)
$ErrorActionPreference = "Stop"
$base = $PSScriptRoot
$env:APPDATA = Join-Path $base "$Label/appdata"
$env:LOCALAPPDATA = Join-Path $base "$Label/localdata"
New-Item -ItemType Directory -Force $env:APPDATA,$env:LOCALAPPDATA | Out-Null
foreach ($scenario in @("idle","contact")) {
    $env:SPARSE_SCENARIO = $scenario
    $env:SPARSE_CAPTURE = Join-Path $base "$Label-$scenario.json"
    & "D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe" --path (Join-Path $base "$Label/game") --resolution 960x600 --log-file (Join-Path $base "$Label-$scenario.log") --script res://bench.gd -- --profile=client
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $env:SPARSE_CAPTURE)) { exit 1 }
}
