"""Apply the native movement experiment to an isolated game project."""
from pathlib import Path
import shutil
import sys

here = Path(__file__).resolve().parent
repo = here.parents[2]
game = Path(sys.argv[1]).resolve()
if game == (repo / 'game').resolve() or not (game / 'project.godot').is_file():
    sys.exit('expected an isolated game directory')
path = game / 'mission/movement/ports/field_movement.gd'
source = path.read_text(encoding='utf-8')
if 'func _native_motion(' in source:
    sys.exit('native adapter already present')

def replace_once(old, new):
    global source
    if source.count(old) != 1:
        raise RuntimeError('unexpected movement baseline at ' + old[:70])
    source = source.replace(old,new)

replace_once('var _checks := 0','''var _native_ai_tokens := {}
var _native_control := Callable()
var _native_external := {}
var _commit_proof: RefCounted
var _resident_proof: RefCounted
var _resident_lineup: RefCounted
var _resident_tick := -1
var _resident_revision := -1
var _resident_clear := false
var _resident_dirty := {}
var _resident_positions := PackedVector3Array()
var _resident_velocities := PackedVector3Array()
var _resident_headings := PackedVector3Array()
var _resident_targets := PackedVector3Array()
var _resident_radii := PackedFloat64Array()
var _resident_foot := PackedFloat64Array()
var _resident_mode := PackedByteArray()
var _resident_ranges := PackedInt32Array()
var _resident_horses_by_end := {}
var _resident_lists: Array = [[],[]]
var _resident_list_stamps: Array = [null,null]
var _resident_rebuilds := 0
var _resident_refreshes := 0
var _resident_auth_checks := 0
var _resident_grid_orders := 0
var _resident_pose_writes := 0
var _kernel_ready := false
var _kernel_checked := false
var _native_batches := 0
var _native_rows := 0
var _native_foot_rows := 0
var _native_skipped_rows := 0
var _native_pack_us := 0
var _native_solve_us := 0
var _native_apply_us := 0
var _checks := 0''')
replace_once('_draft._had_drives = _had_drives','''_draft._had_drives = _had_drives
	_draft._native_ai_tokens = _native_ai_tokens
	_draft._native_control = _native_control
	_draft._native_external = _native_external.duplicate()
	_draft._commit_proof = null''')
replace_once('_drivers = _draft._drivers','_drivers = _draft._drivers\n\t_native_external = _draft._native_external')
replace_once('_draft._had_drives = true','''if b.drive==null or not is_same(b.drive.context,context) or b.drive.direction!=direction or b.drive.fraction!=drive.fraction:
		_draft._resident_dirty[b.index]=true
	if _draft._native_ai_tokens.has(context): _draft._native_external.erase(b.index)
	else: _draft._native_external[b.index]=true
	_draft._had_drives = true''')
replace_once('_drivers.erase(handle.index)','_drivers.erase(handle.index)\n\t_native_external.erase(handle.index)')
replace_once('_drivers.erase(b.drive.handle.index)','_drivers.erase(b.drive.handle.index)\n\t\t\t\t_native_external.erase(b.index)')
replace_once('b.airborne = true','_draft._resident_dirty[b.index]=true\n\tb.airborne = true')
replace_once('b.leg = leg','_resident_dirty[b.index]=true\n\t\tb.leg = leg')
replace_once('b.profile = profile\n\tb.profile_tick','_draft._resident_dirty[b.index]=true\n\tb.profile = profile\n\tb.profile_tick')
replace_once('if profile=="foot": b.velocity = b.velocity.limit_length(3.4)','''if profile=="foot": b.velocity = b.velocity.limit_length(3.4)
	if _stage_ready and is_same(_draft._resident_lineup,_draft._lineup):
		_draft._resident_velocities[b.grid_order]=b.velocity''')
replace_once('_zones = zones.duplicate(true)','''_resident_lineup=null
	if _draft!=null: _draft._resident_lineup=null
	_zones = zones.duplicate(true)''')
replace_once('_routes[group] = _corridor(origin,goal,profile)','''if _draft!=null: _draft._resident_lineup=null
	_routes[group] = _corridor(origin,goal,profile)''')
replace_once('if b.group != group or b.offset != slot_offset:\n\t\t_members_ready', '''if b.group != group or b.offset != slot_offset:
		if _draft!=null: _draft._resident_lineup=null
		_resident_dirty[b.index]=true
		_members_ready''')
replace_once('func rollback_step(stage: Variant) -> Dictionary:\n\tif _busy or _stage == null or not is_same(stage,_stage): return R.fail("InvalidState","movement_stage")','''func rollback_step(stage: Variant) -> Dictionary:
	if _busy or _stage == null or not is_same(stage,_stage): return R.fail("InvalidState","movement_stage")
	_draft._resident_lineup=null
	_draft._resident_proof=null''')
replace_once('for id in _draft._drivers:\n\t\tvar b: Body = _draft._bodies[id]', '''# External principals are evaluated in their original insertion order. Their
	# callbacks can change control mode, so re-read the proof after each call.
	var trusted: bool = _draft._commit_proof!=null and is_same(_draft._commit_proof,_native_control.call())
	for id in ([] if trusted and _draft._native_external.is_empty() else _draft._drivers.keys()):
		var b: Body = _draft._bodies[id]
		var internal:=_native_ai_tokens.has(b.drive.context)
		if internal and trusted:continue''')
replace_once('return R.fail("Unauthorized","movement_control")\n\t_busy = false\n\tvar previous', '''return R.fail("Unauthorized","movement_control")
		if not internal and _draft._commit_proof!=null:
			trusted=is_same(_draft._commit_proof,_native_control.call())
	_busy = false
	var previous''')
replace_once('var weak_token: WeakRef','var full_lineup: RefCounted\n\tvar weak_token: WeakRef')
replace_once('for id in _bindings.keys():','''if bodies.size()==handles.size() and bodies.keys()==Array(roster.indices):
		roster.full_lineup=_lineup if stage==null else _draft._lineup
	for id in _bindings.keys():''')
replace_once('var count := roster.indices.size()','''if stage!=null and _stage_ready and roster.full_lineup!=null and is_same(roster.full_lineup,_draft._lineup) and is_same(_draft._resident_lineup,_draft._lineup) and _draft._resident_tick==_stage_tick:
		# Callers own their returned arrays and may keep them across future transactions.
		if not full:return R.ok(_draft._resident_positions.duplicate())
		return R.ok({"positions":_draft._resident_positions.duplicate(),"velocities":_draft._resident_velocities.duplicate(),"headings":_draft._resident_headings.duplicate()})
	var count := roster.indices.size()''')
replace_once('var bodies := _bodies.values()\n\t_prepare_grid(bodies)','''if not is_same(_resident_list_stamps[_buffer_slot],_buffer_stamp):
		_resident_lists[_buffer_slot]=_bodies.values()
		_resident_list_stamps[_buffer_slot]=_buffer_stamp
	var bodies: Array=_resident_lists[_buffer_slot]
	_prepare_grid(bodies)''')
replace_once('if not _had_drives and _airborne_count==0:\n\t\tfor b: Body in bodies:', '''_native_batches = 0
	_native_rows = 0
	_native_foot_rows = 0
	_native_skipped_rows = 0
	_native_pack_us = 0
	_native_solve_us = 0
	_native_apply_us = 0
	_resident_rebuilds = 0
	_resident_refreshes = 0
	_resident_auth_checks = 0
	_resident_grid_orders = 0
	_resident_pose_writes = 0
	_commit_proof=null
	if not _kernel_checked:
		_kernel_checked = true
		_kernel_ready = ClassDB.class_exists("FieldMoveKernel")
	if _kernel_ready and _had_drives and bodies.size()>=16 and _zones.is_empty() and not _native_ai_tokens.is_empty():
		var advanced: Dictionary
		if _native_external.is_empty() or _native_control.is_valid():
			advanced = _resident_motion(bodies,tick,dt)
		else:
			_resident_lineup = null
			advanced = _native_motion(bodies,tick,dt)
		if not advanced.ok: return advanced
	elif not _had_drives and _airborne_count==0:
		for b: Body in bodies:''')
replace_once('"neighbour_checks":_checks,"yielding":_yields}', '''"neighbour_checks":_checks,"yielding":_yields,
		"native_batches":_native_batches,"native_rows":_native_rows,"native_foot_rows":_native_foot_rows,
		"native_mounted_rows":_native_rows-_native_foot_rows,"native_skipped_rows":_native_skipped_rows,
		"native_fallback_rows":bodies.size()-_native_rows-_native_skipped_rows,"native_pack_us":_native_pack_us,
		"native_solve_us":_native_solve_us,"native_apply_us":_native_apply_us,
		"resident_rebuilds":_resident_rebuilds,"resident_input_rows":_resident_refreshes,
		"resident_auth_checks":_resident_auth_checks,"resident_pose_rows":_resident_pose_writes,
		"resident_order_rows":_resident_grid_orders,"resident_steps":int(_resident_lineup!=null and _resident_tick==tick)}''')

# Reuse the precise script and engine arithmetic for mounted turn integration.
predict = source[source.index('\tvar direction := delta.normalized()',source.index('func _advance(')):source.index('\n\tfor passage in b.passages:',source.index('func _advance('))]
source += (here/'adapter.gd.inc').read_text(encoding='utf-8').replace('@@PREDICT@@',predict)
source += (here/'resident.gd.inc').read_text(encoding='utf-8')
path.write_text(source,encoding='utf-8')
path = game / 'mission/runtime/field_pipeline.gd'
source = path.read_text(encoding='utf-8')
replace_once('if not setup.ok: return setup','''if not setup.ok: return setup
	# Only the production reader's locally issued AI credentials have no external callback.
	if get_script().resource_path=="res://mission/runtime/field_mission.gd":
		for token in _credentials: _move._native_ai_tokens[token]=true
		_move._native_ai_tokens.make_read_only()
		_move._native_control=_movement_grant_stamp''')
source += '''
var _native_grant_rows := {}
var _native_grant_player: Variant
var _native_grant_delegate := false
var _native_grant_stamp: RefCounted

func _movement_grant_stamp() -> RefCounted:
	var rows: Dictionary=_draft.get("rows",_frame.get("rows",{}))
	var player: Variant=_draft.get("player",_user_handle)
	var delegated: bool=_rules.view().control_mode=="delegate"
	if _native_grant_stamp==null or not is_same(rows,_native_grant_rows) or player!=_native_grant_player or delegated!=_native_grant_delegate:
		_native_grant_rows=rows
		_native_grant_player=player
		_native_grant_delegate=delegated
		_native_grant_stamp=RefCounted.new()
	return _native_grant_stamp
'''
path.write_text(source,encoding='utf-8')
native = game / 'native'
native.mkdir(exist_ok=True)
for name in ('field_move.dll','field_move.gdextension'):
    shutil.copy2(here.parent/'kernel'/name,native/name)
extensions = game/'.godot'/'extension_list.cfg'
extensions.parent.mkdir(exist_ok=True)
lines = extensions.read_text(encoding='utf-8').splitlines() if extensions.exists() else []
if 'res://native/field_move.gdextension' not in lines:
    extensions.write_text('\n'.join(lines+['res://native/field_move.gdextension'])+'\n',encoding='utf-8')
