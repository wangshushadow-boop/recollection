
func _native_candidate(b: Body,target: Vector3,dt: float,fraction: float) -> Vector3:
	var direct := true
	var delta := target-b.position
	var distance := delta.length()
@@PREDICT@@
	return candidate

func _native_check_drive(b: Body,tick: int) -> void:
	if b.drive!=null and not _authorized(b.drive.handle,b.drive.context,tick):
		_drivers.erase(b.drive.handle.index)
		_native_external.erase(b.index)
		b.drive=null
		b.leg=null
		b.revoked=true

func _native_reference_step(b: Body,tick: int,dt: float) -> Dictionary:
	_native_check_drive(b,tick)
	if b.airborne: return _move_airborne(b,dt,tick)
	if b.drive!=null or b.revoked: _move_direct(b,dt)
	else: _move(b,_routes.get(b.route_key),dt)
	return R.ok()

func _native_motion(bodies: Array,tick: int,dt: float) -> Dictionary:
	var begin := Time.get_ticks_usec()
	var count := bodies.size()
	var positions := PackedVector3Array()
	var candidates := PackedVector3Array()
	var radii := PackedFloat64Array()
	var foot := PackedFloat64Array()
	positions.resize(count)
	candidates.resize(count)
	radii.resize(count)
	foot.resize(2*count)
	for i in count:
		var b: Body = bodies[i]
		positions[i]=b.position
		radii[i]=-b.radius
		foot[2*i]=-1.0
	_native_pack_us+=Time.get_ticks_usec()-begin
	var first := 0
	while first<count:
		var end := first
		while end<count:
			var b: Body = bodies[end]
			if b.airborne or not b.passages.is_empty() or b.drive==null or not _native_ai_tokens.has(b.drive.context): break
			end+=1
		if end-first<8:
			var limit := maxi(first+1,end)
			for i in range(first,limit):
				var b: Body=bodies[i]
				var result := _native_reference_step(b,tick,dt)
				if not result.ok:return result
				positions[i]=b.position
			first=limit
			continue
		begin=Time.get_ticks_usec()
		for i in range(first,end):
			var b: Body=bodies[i]
			_native_check_drive(b,tick)
			b.blocked=""
			b.arrived=false
			if b.drive==null or _needs_leg(b) or b.leg_cursor>=b.leg.points.size():
				b.velocity=Vector3.ZERO
				b.blocked="control_revoked" if b.revoked else ("no_route" if b.drive.fraction>0 else "")
				_native_skipped_rows+=1
				continue
			var fraction:=0.0 if _braking_turn(b) else b.drive.fraction
			var target:=b.leg.points[b.leg_cursor]
			if b.profile=="foot":
				candidates[i]=target
				foot[2*i]=fraction
				foot[2*i+1]=-1.0 if _legs_clear_scenery else b.scene_travel
				_native_foot_rows+=1
			else:
				candidates[i]=_native_candidate(b,target,dt,fraction)
			radii[i]=b.radius
			_native_rows+=1
		var order:=PackedInt32Array()
		if first>0 and not _unsorted_cells.is_empty():
			order.resize(count)
			var n:=0
			for bucket: Array in _cells.values():
				for b: Body in bucket:
					order[n]=b.grid_order
					n+=1
		_native_pack_us+=Time.get_ticks_usec()-begin
		begin=Time.get_ticks_usec()
		var response: Array=ClassDB.class_call_static(&"FieldMoveKernel",&"advance",positions,candidates,radii,order,first,end,foot,dt)
		_native_solve_us+=Time.get_ticks_usec()-begin
		_native_batches+=1
		if response.size()!=2:return R.fail("InvalidState","native_movement")
		var resolved: PackedInt32Array=response[0]
		var rebuilt: PackedVector3Array=response[1]
		var span:=end-first
		if resolved.size()!=2*span+1 or rebuilt.size()!=2*span:return R.fail("InvalidState","native_movement")
		begin=Time.get_ticks_usec()
		_checks+=resolved[resolved.size()-1]
		for i in range(first,end):
			var code:=resolved[i-first]
			if code==-3:continue
			var b: Body=bodies[i]
			var next:=candidates[i]
			if foot[2*i]>=0.0:
				next=rebuilt[2*(i-first)]
				var flat:=rebuilt[2*(i-first)+1]
				if not flat.is_zero_approx():b.heading=flat
				if resolved[span+i-first]!=0:b.blocked="scene"
			b.last_drive_block=null
			if code==-1:
				b.wait=0.0
			else:
				next=b.position
				b.wait+=dt
				b.blocked="yield"
				_yields+=1
			b.velocity=(next-b.position)/dt
			b.position=next
			var cell:=_cell(next)
			if cell!=b.grid_cell:_relocate(b,cell)
			if next.distance_squared_to(b.leg.points[b.leg_cursor])<.000001:b.leg_cursor+=1
			positions[i]=next
		_native_apply_us+=Time.get_ticks_usec()-begin
		first=end
	return R.ok()
