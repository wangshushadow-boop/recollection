
# Slots follow MOV insertion order for this exact lineup. The speculative MOV
# object survives commits; its packed poses are the next step's opening poses.
# A discard invalidates them before that speculative object can be reused.
var _resident_grants: Array = []
var _resident_pending := {}
var _resident_ranges_dirty := false

func _resident_open(bodies: Array) -> void:
	var n:=bodies.size()
	_resident_positions.resize(n)
	_resident_velocities.resize(n)
	_resident_headings.resize(n)
	_resident_targets.resize(n)
	_resident_radii.resize(n)
	_resident_foot.resize(2*n)
	_resident_mode.resize(n)
	_resident_mode.fill(0)
	_resident_grants.resize(n)
	_resident_grants.fill(null)
	_resident_ranges_dirty=true
	for i in n:
		var b: Body=bodies[i]
		_resident_positions[i]=b.position
		_resident_velocities[i]=b.velocity
		_resident_headings[i]=b.heading
		_resident_radii[i]=-b.radius
		_resident_foot[2*i]=-1.0
	_resident_rebuilds+=1

func _resident_refresh(b: Body) -> void:
	var i:=b.grid_order
	var mode:=0
	if b.drive!=null and _native_ai_tokens.has(b.drive.context) and not b.airborne and b.passages.is_empty():
		if _resident_proof==null or not is_same(_resident_grants[i],b.drive.context):
			_resident_pending[i]=true
		if b.drive!=null:
			mode=1
			if not _needs_leg(b) and b.leg_cursor<b.leg.points.size():
				var target:=b.leg.points[b.leg_cursor]
				if b.profile=="foot":
					mode=2
					_resident_targets[i]=target
					_resident_foot[2*i]=b.drive.fraction
					_resident_foot[2*i+1]=-1.0 if _legs_clear_scenery else b.scene_travel
				else:
					mode=3
					_resident_foot[2*i]=-1.0
					# Filled at the start of the actual native span, after prior fallbacks.
	if (_resident_mode[i]==0)!=(mode==0) or (_resident_mode[i]==3)!=(mode==3): _resident_ranges_dirty=true
	_resident_mode[i]=mode
	_resident_radii[i]=b.radius if mode>=2 else -b.radius
	_resident_refreshes+=1

func _resident_ranges_for(bodies: Array) -> void:
	_resident_ranges.clear()
	_resident_horses_by_end.clear()
	var first:=0
	while first<bodies.size():
		var active:=_resident_mode[first]!=0
		var end:=first+1
		while end<bodies.size() and (_resident_mode[end]!=0)==active:end+=1
		_resident_ranges.append(end if active and end-first>=8 else -end)
		if active and end-first>=8:
			var horse_slots:=PackedInt32Array()
			for i in range(first,end):
				if _resident_mode[i]==3:horse_slots.append(i)
			_resident_horses_by_end[end]=horse_slots
		first=end
	_resident_ranges_dirty=false

func _resident_note_pose(b: Body,i: int) -> void:
	if _resident_positions[i]!=b.position or _resident_velocities[i]!=b.velocity or _resident_headings[i]!=b.heading:
		_resident_positions[i]=b.position
		_resident_velocities[i]=b.velocity
		_resident_headings[i]=b.heading
		_resident_pose_writes+=1

func _resident_motion(bodies: Array,tick: int,dt: float) -> Dictionary:
	var started:=Time.get_ticks_usec()
	var rebuild:=not is_same(_resident_lineup,_lineup) or _resident_tick!=tick-1
	if rebuild:_resident_open(bodies)
	var proof: RefCounted=_native_control.call() if _native_control.is_valid() else null
	var grants_changed:=proof==null or not is_same(proof,_resident_proof)
	_resident_proof=proof
	_resident_pending.clear()
	if grants_changed:_resident_grants.fill(null)
	if rebuild or grants_changed or _resident_revision!=_revision or not _legs_clear_scenery or _resident_clear!=_legs_clear_scenery:
		for b: Body in bodies:_resident_refresh(b)
	else:
		for id in _resident_dirty:
			var b: Body=_bodies.get(id)
			if b!=null:_resident_refresh(b)
	_resident_dirty.clear()
	_resident_clear=_legs_clear_scenery
	_resident_revision=_revision
	if _resident_ranges_dirty:_resident_ranges_for(bodies)
	_native_pack_us+=Time.get_ticks_usec()-started
	var first:=0
	for stop in _resident_ranges:
		var end:=absi(stop)
		if stop<0:
			for i in range(first,end):
				var b: Body=bodies[i]
				var external:=b.drive!=null and not _native_ai_tokens.has(b.drive.context)
				var result:=_native_reference_step(b,tick,dt)
				if not result.ok:return result
				_resident_note_pose(b,i)
				# Airborne landing and short reference spans can advance/clear their route.
				if b.drive!=null or _resident_mode[i]!=0:_resident_dirty[b.index]=true
				if external and not is_same(proof,_native_control.call()):
					# The earlier external callback changed rights. Do not use a
					# precomputed grant or span for any actor still waiting to move.
					_resident_lineup=null
					for later in range(i+1,bodies.size()):
						result=_native_reference_step(bodies[later],tick,dt)
						if not result.ok:return result
					return R.ok()
		else:
			started=Time.get_ticks_usec()
			if not _resident_pending.is_empty():
				# Admission can revoke a drive. Preserve the original order, and
				# perform these side effects only after preceding external callbacks.
				for i in range(first,end):
					if not _resident_pending.erase(i):continue
					var b: Body=bodies[i]
					_resident_auth_checks+=1
					_native_check_drive(b,tick)
					_resident_grants[i]=null if b.drive==null else b.drive.context
					if b.drive==null:
						_resident_mode[i]=1
						_resident_radii[i]=-b.radius
						_resident_dirty[b.index]=true
			for i: int in _resident_horses_by_end[end]:
				var b: Body=bodies[i]
				if b.drive==null:continue
				b.blocked=""
				var fraction:=0.0 if _braking_turn(b) else b.drive.fraction
				_resident_targets[i]=_native_candidate(b,b.leg.points[b.leg_cursor],dt,fraction)
				if b.leg.direction.dot(b.drive.direction)<.99985:_resident_dirty[b.index]=true
			var order:=PackedInt32Array()
			if first>0 and not _unsorted_cells.is_empty():
				order.resize(bodies.size())
				var n:=0
				for bucket: Array in _cells.values():
					for b: Body in bucket:
						order[n]=b.grid_order
						n+=1
				_resident_grid_orders+=n
			_native_pack_us+=Time.get_ticks_usec()-started
			started=Time.get_ticks_usec()
			var response: Array=ClassDB.class_call_static(&"FieldMoveKernel",&"advance",_resident_positions,_resident_targets,_resident_radii,order,first,end,_resident_foot,dt)
			_native_solve_us+=Time.get_ticks_usec()-started
			_native_batches+=1
			var span:=end-first
			if response.size()!=2:return R.fail("InvalidState","native_movement")
			var flags: PackedInt32Array=response[0]
			var output: PackedVector3Array=response[1]
			if flags.size()!=2*span+1 or output.size()!=2*span:return R.fail("InvalidState","native_movement")
			started=Time.get_ticks_usec()
			_checks+=flags[2*span]
			for j in span:
				var i:=first+j
				var b: Body=bodies[i]
				b.arrived=false
				if flags[j]==-3:
					b.velocity=Vector3.ZERO
					b.blocked="control_revoked" if b.revoked else ("no_route" if b.drive.fraction>0 else "")
					_native_skipped_rows+=1
					_resident_note_pose(b,i)
					continue
				_native_rows+=1
				var next:=output[2*j]
				if _resident_mode[i]==2:
					_native_foot_rows+=1
					var flat:=output[2*j+1]
					if not flat.is_zero_approx():b.heading=flat
					b.blocked="scene" if flags[span+j]!=0 else ""
				b.last_drive_block=null
				if flags[j]==-1:b.wait=0.0
				else:
					next=b.position
					b.wait+=dt
					b.blocked="yield"
					_yields+=1
				b.velocity=(next-b.position)/dt
				b.position=next
				var cell:=_cell(next)
				if cell!=b.grid_cell:_relocate(b,cell)
				if next.distance_squared_to(b.leg.points[b.leg_cursor])<.000001:
					b.leg_cursor+=1
					_resident_dirty[b.index]=true
				_resident_note_pose(b,i)
			_native_apply_us+=Time.get_ticks_usec()-started
		first=end
	_resident_lineup=_lineup
	_resident_tick=tick
	_commit_proof=proof
	return R.ok()
