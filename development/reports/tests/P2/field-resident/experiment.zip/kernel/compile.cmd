@echo off
setlocal
pushd "%~dp0" || exit /b 1
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /O2 /fp:precise /MT /LD field_move.cpp /link /out:field_move.dll
exit /b %errorlevel%
