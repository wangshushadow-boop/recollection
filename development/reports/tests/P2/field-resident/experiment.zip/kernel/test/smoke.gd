extends SceneTree

var failures := 0
func check(condition: bool, label: String) -> void:
	if not condition:
		failures += 1
		printerr("FAIL ",label)

func _initialize() -> void:
	if not ClassDB.class_exists(&"FieldMoveKernel"):
		printerr("FieldMoveKernel missing")
		quit(1)
		return
	var pos := PackedVector3Array([Vector3.ZERO,Vector3(0.8,0,0),Vector3(-1,0,0)])
	var cand := PackedVector3Array([Vector3(0.3,0,0),Vector3(1.3,0,0),Vector3(-0.2,0,0)])
	var radii := PackedFloat64Array([0.3,0.3,0.3])
	var order := PackedInt32Array()
	var hit: PackedInt32Array=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",pos,cand,radii,order,0,3)
	check(hit.size()==4 and hit[0]==1 and hit[1]==-1 and hit[2]==0,"ordered contacts")
	var moved: Array=ClassDB.class_call_static(&"FieldMoveKernel",&"advance",pos,cand,radii,order,0,3,PackedFloat64Array([1,-1,0.5,0.01,-1,-1]),1.0/60)
	check(moved.size()==2 and moved[0].size()==7 and moved[0][4]==1 and moved[1][0]==Vector3.RIGHT*(3.4/60.0) and moved[1][1]==Vector3.RIGHT,"native direct step and scene clamp")
	var invalid: PackedInt32Array=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",pos,cand,radii,PackedInt32Array([0,0,1]),0,3)
	check(invalid.is_empty(),"duplicate cell order rejected")
	var random := RandomNumberGenerator.new()
	random.seed=41414
	pos.clear()
	cand.clear()
	radii.clear()
	var params := PackedFloat64Array()
	for i in 256:
		var p := Vector3(i*2.0,random.randf_range(-1,1),random.randf_range(-1,1))
		pos.append(p)
		cand.append(p+Vector3(random.randf_range(-3,3),random.randf_range(-3,3),random.randf_range(-3,3)))
		radii.append(0.3)
		params.append(random.randf())
		params.append(-1)
	var out: Array=ClassDB.class_call_static(&"FieldMoveKernel",&"advance",pos,cand,radii,order,0,pos.size(),params,1.0/60)
	for i in pos.size():
		var delta := cand[i]-pos[i]
		var dir := delta.normalized()
		var want := pos[i] + dir * minf(delta.length(),3.4*params[i*2]*(1.0/60.0))
		check(out[1][2*i]==want and out[1][2*i+1]==Vector3(dir.x,0,dir.z).normalized(),"exact foot vector "+str(i))
	check(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")==3,"only successful batches counted")
	print("FIELD_MOVE_NATIVE failures=",failures)
	quit(int(failures!=0))
