extends SceneTree

func _initialize() -> void:
	var version := Engine.get_version_info()
	if version.hex != 0x040702 or not ClassDB.class_has_method(&"FieldMoveKernel", &"parallel_count"):
		printerr("Expected the resident FieldMoveKernel for Godot 4.7.2")
		quit(1)
		return
	var workers: int = ClassDB.class_call_static(&"FieldMoveKernel", &"worker_count")
	var before: int = ClassDB.class_call_static(&"FieldMoveKernel", &"call_count")
	var result: Array = ClassDB.class_call_static(&"FieldMoveKernel", &"advance",
		PackedVector3Array([Vector3.ZERO]), PackedVector3Array([Vector3.RIGHT]),
		PackedFloat64Array([0.28]), PackedInt32Array(), 0, 1, PackedFloat64Array([1.0, -1.0]), 1.0 / 60)
	var calls: int = ClassDB.class_call_static(&"FieldMoveKernel", &"call_count")
	var valid := calls == before + 1 and workers == OS.get_environment("RECOLLECTION_MOVE_WORKERS").to_int()
	valid = valid and result.size() == 2 and result[0][0] == -1 and result[1][0].x > 0
	print("Resident kernel startup check ", "PASS" if valid else "FAIL", " (workers=", workers, ")")
	quit(0 if valid else 1)
