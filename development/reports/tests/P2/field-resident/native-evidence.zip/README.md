# Godot 4.7.2 原生移动候选计算试验

平台为 Windows x86-64、单精度 Godot Standard、MSVC 2022 x64。对照使用同一 DLL。启动 Godot 前设置环境变量 `RECOLLECTION_MOVE_WORKERS=1` 或 `4`。缺省为 1。跨度达到 128 的四分片批次使用 Godot 的常驻 WorkerThreadPool；较小批次走同一逐行函数的串行路径。候选生成使用前一版的浮点计算和 Godot Vector3.normalized。主线程准备按原序插入的空间格，并等待任务完成，再依次裁决邻居、修改位置与所属格。输入和工作区寿命持续到整批结束。每次 `advance` 返回后即可丢弃全部中间结果。

`solve`、`advance` 和 `call_count` 保持原 ABI。只读计数器 `worker_count`、`parallel_count` 提供配置和实际并行批次数。原始候选步行的转速、避让、裁决均保持原语义，骑兵候选仍由适配器提供。

## 真实输入短基准

从原生试验版的 500 名士兵、100 匹马、有指令行军回放中截取第 161–176 步。16 个调用都带 500 行名册，其中每步实际裁决 499 个槽位，399 个槽位产生新步兵候选；其余按冻结的输入提供骑兵候选或保留原地。每次将输入与**旧版 DLL 的完整输出**落盘，测量时留在内存。按 1、4、4、1 顺序分别启动独立 Godot 进程；每份输入预热一次并计时 24 次，记录的是整个 `ClassDB.class_call_static` 墙钟时间，包含准备原生输入、生成返回列、调度、等待、归并和有序裁决。GDScript 构造战场列、载入样本、回写运动组件和显示均在这项短基准之外。每进程在首次和末次回放校验每份输出，128/128 份输出的序列化字节与旧 DLL 一致。

| 模式 | 调用次数 | 平均 µs | P50 µs | P95 µs |
|---|---:|---:|---:|---:|
| 串行 | 768 | 106.17 | 103 | 127 |
| 四分片 | 768 | 104.49 | 103 | 113 |

单次墙钟差异非常小，各轮与每次采样保存在 `real-1.json` 至 `real-4.json`。此处含原生求解，不含整场客户端其余计算。

## 复跑

在本目录执行 `compile.cmd` 生成 DLL（需要 VS 2022 Community C++ x64 工具链）。将 `field_move.dll` 与 `field_move.gdextension` 复制到 `test/native/`，先用 Godot 4.7.2 执行 `--headless --path test --import`。烟测命令为 `--headless --path test --script res://smoke.gd`。

短基准设置 `MOVE_CAPTURE_DIR` 为解压后的 `real-batches` 绝对路径，设置 `RECOLLECTION_MOVE_WORKERS` 为 1 或 4，`MOVE_BENCH_RESULT` 为结果绝对路径；运行 `--headless --path test --script res://real_bench.gd`。每个结果保留逐次微秒样本与实派发计数。

若需重新采集真实输入，执行 `python prepare_capture.py --project <原版已导入的原生试验工程/game> --scenario <原始QA behavior.gd>`，设置 `RECOLLECTION_QA_COUNT=500` 和 `MOVE_CAPTURE_DIR`，再用 `--headless --fixed-fps 60 --path capture-game --script <capture.gd绝对路径>`。数据包中已附 16 份原始输入，可直接复跑。
