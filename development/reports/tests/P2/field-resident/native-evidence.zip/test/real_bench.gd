extends SceneTree

func _initialize() -> void:
	var folder := OS.get_environment("MOVE_CAPTURE_DIR")
	var names := DirAccess.get_files_at(folder)
	names.sort()
	var batches := []
	var soldiers := 0
	var eligible := 0
	for name in names:
		if not name.ends_with(".var"):continue
		var file := FileAccess.open(folder.path_join(name),FileAccess.READ)
		var row: Array=file.get_var()
		if row[0].size()!=500:
			printerr("Expected 500 soldiers, got ",row[0].size());quit(1);return
		for i in range(row[4],row[5]):
			soldiers+=1
			if row[2][i]>=0 and row[6][i*2]>=0:eligible+=1
		batches.append(row)
	if batches.is_empty():quit(1);return
	var samples: Array[int]=[]
	var expected := int(OS.get_environment("RECOLLECTION_MOVE_WORKERS"))
	var workers: int=ClassDB.class_call_static(&"FieldMoveKernel",&"worker_count")
	if workers!=expected:quit(1);return
	for rep in 25:
		for row in batches:
			var begin:=Time.get_ticks_usec()
			var actual: Array=ClassDB.class_call_static(&"FieldMoveKernel",&"advance",row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7])
			if rep>0:samples.append(Time.get_ticks_usec()-begin)
			if rep==0 or rep==24:
				if var_to_bytes(actual)!=var_to_bytes(row[8]):
					printerr("Output diverged from original DLL");quit(1);return
	samples.sort()
	var parallel: int=ClassDB.class_call_static(&"FieldMoveKernel",&"parallel_count")
	if (expected==4)!=(parallel>0):quit(1);return
	var out:=FileAccess.open(OS.get_environment("MOVE_BENCH_RESULT"),FileAccess.WRITE)
	var summary:={"workers":workers,"parallel_calls":parallel,"batches":batches.size(),"rows":soldiers,"foot_predictions":eligible,
		"p50_us":samples[ceili(samples.size()*.5)-1],"p95_us":samples[ceili(samples.size()*.95)-1],"samples_us":samples}
	out.store_string(JSON.stringify(summary))
	out.close()
	print("REAL_BATCH bench=",workers," batches=",batches.size()," p50=",summary.p50_us," p95=",summary.p95_us,
		" measured=",samples.size()," checked=",batches.size()*2," jobs=",parallel)
	quit(0)
