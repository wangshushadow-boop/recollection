"""Capture original native inputs/outputs from a disposable river battle project."""
from pathlib import Path
import argparse
import shutil

here=Path(__file__).resolve().parent
repo=here.parents[2]
cli=argparse.ArgumentParser()
cli.add_argument("--project",type=Path,default=repo/"out/native-move/preview/game")
cli.add_argument("--scenario",type=Path,default=repo/"out/native-move/qa/behavior.gd")
args=cli.parse_args()
dest=here/"capture-game"
shutil.copytree(args.project,dest)
captures=here/"real-batches"
captures.mkdir(exist_ok=True)
movement=dest/"mission/movement/ports/field_movement.gd"
s=movement.read_text(encoding="utf-8")
anchor='\t\t_native_solve_us+=Time.get_ticks_usec()-begin'
assert s.count(anchor)==1
s=s.replace(anchor,'''		if _tick>=161 and _tick<=176:
			var file:=FileAccess.open(OS.get_environment("MOVE_CAPTURE_DIR").path_join("%03d-%04d.var"%[_tick,first]),FileAccess.WRITE)
			file.store_var([positions,candidates,radii,order,first,end,foot,dt,response])
			file.close()
'''+anchor)
movement.write_text(s,encoding="utf-8")
s=args.scenario.read_text(encoding="utf-8")
anchor='\t\tvar calls_this_tick := native_counter()-before_commit'
assert s.count(anchor)==1
s=s.replace(anchor,'''		if tick>=177:
			print("CAPTURE_COMPLETE tick=",tick)
			app.shutdown()
			quit(0)
			return
'''+anchor)
(here/"capture.gd").write_text(s,encoding="utf-8")
