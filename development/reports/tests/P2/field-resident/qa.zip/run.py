"""Run one deterministic candidate batch using the actual extension and the frozen Godot reference."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import zipfile

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("--engine",type=Path,default=Path("D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe"))
parser.add_argument("--workers",type=int,choices=(1,4),default=4)
parser.add_argument("--only", choices=["boundary", "behavior", "workers"])
args=parser.parse_args()
project=args.project.resolve()
target=here/"observed"
target.mkdir(exist_ok=True)
profile=target/"profile"
profile.mkdir(exist_ok=True)
env=dict(os.environ,RECOLLECTION_MOVE_WORKERS=str(args.workers),APPDATA=str(profile),LOCALAPPDATA=str(profile),RECOLLECTION_QA_COUNT="500",
         RECOLLECTION_BEHAVIOR_PROOF=str(target/"behavior.json"),RECOLLECTION_QA_MOV_REFERENCE=str(here/"reference_movement.gd"))
summary_path=target/"summary.json"
data=json.loads(summary_path.read_text()) if summary_path.exists() and args.only else {}
data["project"]=str(project)
data["reference"]="bbcdc93675f69e26927e802430048e299ea39394 (MOV identical to 5277bd4; prior accepted trace 8f52df5f89f6d652ff9beaa6cdc7ee0132c90bf2056f3de366747d6c1b8405a8)"
data["source_sha256"]={str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
                       (project/"mission/movement/ports/field_movement.gd",project/"mission/runtime/field_pipeline.gd",project/"native/field_move.dll",project/"native/field_move.gdextension")}
for script in ([args.only] if args.only else ["boundary","behavior","workers"]):
    if script=="workers":
        runs=[]
        for workers in [1,4]:
            cmd=[str(args.engine),"--headless","--path",str(project),"--log-file",str(target/f"workers-{workers}-engine.log"),"--script",str(here/"workers.gd")]
            r=subprocess.run(cmd,cwd=target,env=dict(env,RECOLLECTION_MOVE_WORKERS=str(workers)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
            (target/f"workers-{workers}.log").write_bytes(r.stdout)
            raw=r.stdout.decode("utf-8","replace")
            matches=[json.loads(line[8:]) for line in raw.splitlines() if line.startswith("WORKERS ")]
            record={"command":cmd,"exit_code":r.returncode,"mode":workers,"passed":r.returncode==0 and len(matches)==1 and matches[0]["pass"] and "ERROR:" not in raw,"result":matches[0] if matches else {}}
            runs.append(record)
        ok=all(r["passed"] for r in runs) and runs[0]["result"]["hash"]==runs[1]["result"]["hash"]
        data["workers"]={"runs":runs,"output_identical":ok}
        summary_path.write_text(json.dumps(data,indent=2),encoding="utf-8")
        print(data["workers"],flush=True)
        if not ok:sys.exit(1)
        continue
    command=[str(args.engine),"--headless","--fixed-fps","60","--path",str(project),"--log-file",str(target/(script+"-engine.log")),"--script",str(here/(script+".gd"))]
    proc=subprocess.run(command,cwd=target,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
    (target/(script+".log")).write_bytes(proc.stdout)
    lines=proc.stdout.decode("utf-8","replace").splitlines()
    markers=["NATIVE_BOUNDARY_SUMMARY","pass=true"] if script=="boundary" else ["PERF_Q PASS","NATIVE_REPLAY","ROLLBACK PASS"]
    log="\n".join(lines)
    passed=proc.returncode==0 and all(m in log for m in markers) and not any(m in log for m in ["SCRIPT ERROR:","ERROR:","FAIL "])
    row={"requested_workers":args.workers,"passed":passed,"exit_code":proc.returncode,"command":command,"observations":[s for s in lines if s.startswith(("NATIVE_","PERF_Q ","ROLLBACK ","FAIL "))]}
    if script=="behavior" and passed:
        old=json.loads((here/"baseline/behavior.json").read_text())
        new=json.loads((target/"behavior.json").read_text())
        a,b=old.pop("checksums"),new.pop("checksums")
        first=next((i+1 for i,(x,y) in enumerate(zip(a,b)) if x!=y),None)
        row["same_ticks"]=sum(x==y for x,y in zip(a,b))
        row["first_mismatch"]=first
        row["checksum"]=hashlib.sha256(("\n".join(b)+"\n").encode()).hexdigest()
        row["observables_equal"]=old==new
        row["passed"]=old==new and a==b and len(b)==1260
    data[script]=row
    summary_path.write_text(json.dumps(data,indent=2),encoding="utf-8")
    print(script,row,flush=True)
    if not row["passed"]:
        sys.exit(1)
with zipfile.ZipFile(here/"qa.zip","w",zipfile.ZIP_DEFLATED) as z:
    for name in ["reference_movement.gd","behavior.gd","workers.gd","QA-README.txt","developer_selftest/smoke.gd","developer_selftest/proofs.log","developer_selftest/reference.gd","before_terrain_fix/terrain-repro.log","before_terrain_fix/summary.json","before_terrain_fix/behavior.log","observed/workers-1.log","observed/workers-4.log","boundary.gd","run.py","baseline/behavior.json","baseline/summary.json",
                 "observed/summary.json","observed/boundary.log","observed/behavior.log","observed/behavior.json"]:
        if (here/name).is_file():z.write(here/name,name)
