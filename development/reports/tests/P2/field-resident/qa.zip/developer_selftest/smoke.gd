extends SceneTree
const Move=preload("res://mission/movement/ports/field_movement.gd")
const Reference=preload("res://reference.gd")
const R=preload("res://contracts/result.gd")
var token:=RefCounted.new()
var external_token:=RefCounted.new()
var proof:=RefCounted.new()
var allowed:=true
var change_on_external:=false
var revoked_index:=-1
var errors:=0
var checks:=0

class Terrain:
	func sync_navigation(_scope):return R.ok({"status":"applied","applied_revision":1})
	func field_scenery_top(_scope,_mask):return 0.0
	func query_path_batch(batch,revision,_scope):
		var solved:=[]
		for q in batch:solved.append({"nav_revision":revision,"reachable":true,"points":[q.from,q.to]})
		return R.ok(solved)
	func query_sweep_batch(_q,_context):return R.ok([])

func check(ok:bool,label:String):
	checks+=1
	if not ok:
		errors+=1
		printerr("FAIL ",label)

func auth(_s,h,ctx,_t):
	if change_on_external and ctx==external_token:
		change_on_external=false
		proof=RefCounted.new()
		revoked_index=7
	return allowed and h.index!=revoked_index
func stamp():return proof
func issue(m,st,h):return m.apply_move_intent(st,{"actor_handle":h,"stance":null,"speed_fraction":1,"desired_direction":[1000,0,0]},token)
func short_revoke():
	var world:=Terrain.new()
	var target=Move.new(world,"short",auth)
	var reference=Reference.new(world,"short",auth)
	target._native_ai_tokens[token]=true
	target._native_control=stamp
	allowed=true
	revoked_index=-1
	proof=RefCounted.new()
	var hs:=[]
	for i in 64:
		var h={"index":i,"generation":1}
		hs.append(h)
		for m in [target,reference]:m.spawn(h,Vector3(0,0,i*2),"foot",Vector3.RIGHT)
	for tick in range(1,6):
		var a=target.begin_step(tick).value
		var b=reference.begin_step(tick).value
		if tick==1:
			for h in hs:
				issue(target,a,h)
				issue(reference,b,h)
		if tick==2:
			var stop:={"actor_handle":hs[4],"stance":null,"speed_fraction":0,"desired_direction":[0,0,0]}
			target.apply_move_intent(a,stop,external_token)
			reference.apply_move_intent(b,stop,external_token)
			# Four preceding AI movers now form a short reference span.
			revoked_index=1
			proof=RefCounted.new()
		if tick==3:
			issue(target,a,hs[4])
			issue(reference,b,hs[4])
		if tick==4:
			# Revoke another mover in the long native span.
			revoked_index=16
			proof=RefCounted.new()
		var got=target.stage_step(tick,1.0/60.0,a)
		var ref=reference.stage_step(tick,1.0/60.0,b)
		check(got.ok and ref.ok and got.value.native_batches>0,"short-span transition "+str(tick))
		for idx in [1,4,16]:
			check(target.view(hs[idx],a).value==reference.view(hs[idx],b).value,"revoked/renewed actor "+str([tick,idx]))
		check(target.commit_step(a).ok and reference.commit_step(b).ok,"post-revoke commit "+str(tick))
func _initialize():
	var world:=Terrain.new()
	var target=Move.new(world,"proofs",auth)
	var reference=Reference.new(world,"proofs",auth)
	target._native_ai_tokens[token]=true
	target._native_control=stamp
	var handles:=[]
	for i in 64:
		var h={"index":i,"generation":1}
		handles.append(h)
		for m in [target,reference]:m.spawn(h,Vector3(0,0,i*2),"mounted" if i>=56 else "foot",Vector3.RIGHT)
	var ticket=target.bind_roster(handles).value
	var ref_ticket=reference.bind_roster(handles).value
	var stable_refresh:=-1
	for tick in range(1,27):
		if tick==23:
			check(target.set_terrain([]).ok and reference.set_terrain([]).ok,"change terrain on committed MOV")
		if tick==25:
			for m in [target,reference]:
				check(m.set_corridor("lane",Vector3.ZERO,Vector3.RIGHT*4).ok and m.assign(handles[0],"lane").ok,"change corridor and assignment between ticks")
		var a=target.begin_step(tick).value
		var b=reference.begin_step(tick).value
		if tick==1:
			for h in handles:
				issue(target,a,h)
				issue(reference,b,h)
		if tick==14:
			var stop:={"actor_handle":handles[0],"stance":null,"speed_fraction":0,"desired_direction":[0,0,0]}
			for item in [[target,a],[reference,b]]:
				check(item[0].apply_move_intent(item[1],stop,external_token).ok,"external player zero-speed command")
		if tick==18:
			target.despawn(handles[14],a)
			reference.despawn(handles[14],b)
			var h={"index":14,"generation":2}
			target.spawn(h,Vector3(0,0,-20),"foot",Vector3.RIGHT,a)
			reference.spawn(h,Vector3(0,0,-20),"foot",Vector3.RIGHT,b)
			issue(target,a,h)
			issue(reference,b,h)
			check(not target.read_positions(ticket,a).ok,"abandoned roster order invalid")
			handles.remove_at(14)
			handles.append(h)
			ticket=target.bind_roster(handles,a).value
			ref_ticket=reference.bind_roster(handles,b).value
		if tick==20 or tick==21:
			var profile="mounted" if tick==20 else "foot"
			target.set_profile(handles[0],profile,a)
			reference.set_profile(handles[0],profile,b)
		if tick==16:change_on_external=true
		var got=target.stage_step(tick,1.0/60.0,a)
		if tick==16:
			change_on_external=true
			revoked_index=-1
		var ref=reference.stage_step(tick,1.0/60.0,b)
		if tick==16:
			check(got.ok and ref.ok and got.value.resident_steps==0 and got.value.native_batches==0 and revoked_index==7,"side-effectful player barrier revokes a later internal mover in order")
		else:
			check(got.ok and ref.ok and got.value.resident_steps==1 and got.value.native_batches>0,"native "+str(tick))
		if tick==13:stable_refresh=got.value.resident_input_rows
		if tick==23 or tick==25:check(got.value.resident_rebuilds==1,"outside-stage changes invalidate dormant draft")
		var packed=target.read_poses(ticket,a).value
		check(packed==reference.read_poses(ref_ticket,b).value,"staged poses "+str(tick))
		packed.positions[0]=Vector3(50,0,80)
		check(target.read_positions(ticket,a).value[0]!=packed.positions[0],"owned output")
		if tick==15:
			allowed=false
			proof=RefCounted.new()
			check(not target.commit_step(a).ok and not reference.commit_step(b).ok,"mid-step authority change")
			allowed=true
			proof=RefCounted.new()
			a=target.begin_step(tick).value
			b=reference.begin_step(tick).value
			got=target.stage_step(tick,1.0/60.0,a)
			ref=reference.stage_step(tick,1.0/60.0,b)
			check(got.ok and ref.ok and got.value.resident_rebuilds==1 and target.read_poses(ticket,a).value==reference.read_poses(ref_ticket,b).value,"discarded columns are rebuilt on retry")
		check(target.commit_step(a).ok and reference.commit_step(b).ok,"commit "+str(tick))
	check(stable_refresh==0,"steady legs need zero control refreshes")
	short_revoke()
	print("RESIDENT_BRIDGE checks=",checks," failures=",errors," stable_input_rows=",stable_refresh)
	quit(int(errors>0))
