extends SceneTree
## The exact same mixed packed input in two independent engine processes.
func _initialize() -> void:
	var requested := int(OS.get_environment("RECOLLECTION_MOVE_WORKERS"))
	if not ClassDB.class_exists(&"FieldMoveKernel") or not ClassDB.class_has_method(&"FieldMoveKernel",&"parallel_count"):quit(1);return
	var workers: int = ClassDB.class_call_static(&"FieldMoveKernel",&"worker_count")
	var prior_calls: int = ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")
	var prior_jobs: int = ClassDB.class_call_static(&"FieldMoveKernel",&"parallel_count")
	var positions := PackedVector3Array()
	var targets := PackedVector3Array()
	var radii := PackedFloat64Array()
	var foot := PackedFloat64Array()
	for i in 1024:
		var p := Vector3((i%32-16)*0.74,0,(floori(i/32.0)-16)*1.19)
		positions.append(p)
		var mounted := i%7==0
		targets.append(p+Vector3(0.12,0,.04) if mounted else p+Vector3(5-i%11,0,4-i%9))
		radii.append(.47 if mounted else .28)
		foot.append(-1.0 if mounted else 0.25+(i%4)*.25)
		foot.append(-1.0 if i%5 else .013)
	var response: Array = ClassDB.class_call_static(&"FieldMoveKernel",&"advance",positions,targets,radii,PackedInt32Array(),0,1024,foot,1.0/60.0)
	var jobs: int = int(ClassDB.class_call_static(&"FieldMoveKernel",&"parallel_count"))-prior_jobs
	var calls: int = int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))-prior_calls
	var digest:=HashingContext.new()
	digest.start(HashingContext.HASH_SHA256)
	digest.update(var_to_bytes(response))
	var equal_mode := requested==workers and calls==1 and (jobs==0 if workers==1 else jobs>0)
	var ok: bool = equal_mode and response.size()==2 and response[0].size()==2049 and response[1].size()==2048
	print("WORKERS ",JSON.stringify({"mode":workers,"parallel_dispatches":jobs,"calls":calls,"rows":1024,"hash":digest.finish().hex_encode(),"pass":ok}))
	quit(0 if ok else 1)
