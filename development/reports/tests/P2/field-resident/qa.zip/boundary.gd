extends SceneTree
const Move = preload("res://mission/movement/ports/field_movement.gd")
const Adapter = preload("res://infrastructure/engine/adapter.gd")
const Pipeline = preload("res://mission/runtime/field_pipeline.gd")
const COUNT := 72
const DT := 1.0/60.0
var engine: RefCounted
var pipe: RefCounted
var credential := RefCounted.new()
var second_credential := RefCounted.new()
var external_player := RefCounted.new()
var external_allowed := true
var mutate_on_auth := false
var callback_mutations := 0
var rejected_external := 0
var rejected_commits := 0
var stale_rosters := 0
var rejected_replacements := 0
var bound_at_spawn := {}
var scope := ""
var handles: Array = []
var checks := 0
var failed := false

func _initialize() -> void:
	run.call_deferred()

func verify(ok: bool, label: String) -> bool:
	checks+=1
	if not ok and not failed:
		failed = true
		printerr("FAIL ",label)
	return ok

func count_calls() -> int:
	return int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))

func origin(i: int) -> Vector3:
	if i<54: return Vector3(-10,0,-10)
	if i==54: return Vector3(1.19,0,-4)
	if i==55: return Vector3(1.79,0,-4)
	return Vector3(-14.42+(i-56)%4*5.0,0,3+floori((i-56)/4.0)*4)

func resolve_player(token: Variant) -> Dictionary:
	if mutate_on_auth and is_same(token,external_player):
		mutate_on_auth=false
		callback_mutations+=1
		pipe._user_handle=handles[67]
	return {"ok":true,"value":{"issuer_id":"player","team_key":0}} if is_same(token,external_player) and external_allowed else {"ok":false}

func drive_for(field:RefCounted, stage:RefCounted, h:Dictionary, token:RefCounted) -> bool:
	var input := {"actor_handle":h,"speed_fraction":1.0,"desired_direction":[1000000,0,0],"stance":null}
	return verify(field.apply_move_intent(stage,input,token).ok,"move for "+str(h))

func staged(field: RefCounted,tick: int) -> Dictionary:
	if tick in [17,18]:pipe._user_handle=handles[4]
	if tick==17:mutate_on_auth=true
	var opened: Dictionary = field.begin_step(tick)
	if tick==20:
		if not drive_for(field,opened.value,handles[4],credential):return {}
	if tick==18:
		if not drive_for(field,opened.value,handles[4],external_player) or not drive_for(field,opened.value,handles[67],credential):return {}
	if not verify(opened.ok,"open "+str(tick)): return {}
	if tick==0:
		for i in COUNT:
			if not drive_for(field,opened.value,handles[i],credential):return {}
	if tick in [12,22]:
		for i in [4,11]:
			if not drive_for(field,opened.value,handles[i],(external_player if i==4 else second_credential) if tick==12 else credential):return {}
	if tick==25 or tick==28:
		var profile := "mounted" if tick==25 else "foot"
		if not verify(field.set_profile(handles[62],profile,opened.value).ok,"profile "+profile):return {}
	if tick==40:
		var stale := {"index":61,"generation":1}
		var committed := var_to_bytes(field.read_poses(bound_at_spawn[field]))
		if not verify(field.despawn(stale,opened.value).ok and field.spawn(handles[61],Vector3(27,0,-38),"mounted",Vector3.LEFT,opened.value).ok,"speculative replacement"):return {}
		if not drive_for(field,opened.value,handles[61],credential):return {}
		if not verify(field.stage_step(tick,DT,opened.value).ok and field.rollback_step(opened.value).ok,"rollback staged replacement"):return {}
		if not verify(var_to_bytes(field.read_poses(bound_at_spawn[field]))==committed and field.view(stale).ok and not field.view(handles[61]).ok,"restored original generation after rejected replacement"):return {}
		rejected_replacements+=1
		opened=field.begin_step(tick)
		if not verify(opened.ok,"retry replacement"):return {}
		if not verify(field.despawn(stale,opened.value).ok,"retire actor"):return {}
		if not verify(field.spawn(handles[61],Vector3(-20,0,34),"foot",Vector3.RIGHT,opened.value).ok,"replace same slot"):return {}
		if not verify(not field.read_poses(bound_at_spawn[field],opened.value).ok and not field.view(stale,opened.value).ok,"retired generation read"):return {}
		stale_rosters+=1
		if not drive_for(field,opened.value,handles[61],credential):return {}
	if tick==43:
		if not verify(field.spawn(handles.back(),Vector3(11.99,0,-34),"foot",Vector3.RIGHT,opened.value).ok,"new reinforcement"):return {}
		if not drive_for(field,opened.value,handles.back(),credential):return {}
	if tick==38:
		if not drive_for(field,opened.value,handles[67],credential):return {}
	if tick==24:
		var brake := {"actor_handle":handles[58],"speed_fraction":0.0,"desired_direction":[0,0,0],"stance":null}
		if not verify(field.apply_move_intent(opened.value,brake,credential).ok,"stop"): return {}
		if not verify(field.request_jump(handles[57],credential,opened.value).ok,"jump"): return {}
	var moved: Dictionary = field.stage_step(tick,DT,opened.value)
	if not verify(moved.ok,"stage "+str(moved.get("error"))):return {}
	if tick==89:
		var ordered := handles.duplicate()
		ordered.remove_at(61)
		ordered.insert(ordered.size()-1,handles[61])
		var fresh: Dictionary = field.bind_roster(ordered,opened.value)
		if not verify(fresh.ok,"full roster with replacement's insertion order"):return {}
		var before_dismount: Dictionary=field.read_poses(fresh.value,opened.value).value
		var original_speed: float=before_dismount.velocities[56].length()
		if not verify(original_speed>3.4 and field.set_profile(handles[56],"foot",opened.value).ok,"moving rider dismounts after stage"):return {}
		var fresh_pose: Dictionary=field.read_poses(fresh.value,opened.value).value
		if not verify(fresh_pose.velocities[56]==field.view(handles[56],opened.value).value.velocity and fresh_pose.velocities[56].length()<3.401 and before_dismount.velocities[56].length()==original_speed,"held snapshot, updated mounted velocity"):return {}
		fresh_pose.positions[56]=Vector3(2000,2000,2000)
		if not verify(field.read_positions(fresh.value,opened.value).value[56]==field.view(handles[56],opened.value).value.position,"returned packed poses are caller-owned"):return {}
	if tick in [16,32]:
		var before: Dictionary = field.read_poses(bound_at_spawn[field])
		var old_bytes := var_to_bytes(before)
		if tick==16: external_allowed=false
		else:pipe._rules._status.control_mode="direct"
		var denied: Dictionary = field.commit_step(opened.value)
		if tick==16:
			external_allowed=true
			rejected_external+=1
		else:pipe._rules._status.control_mode="delegate"
		if not verify(not denied.ok and denied.error.code=="Unauthorized" and var_to_bytes(field.read_poses(bound_at_spawn[field]))==old_bytes,"revoke after stage discards all candidate writes"):return {}
		if not verify(not field.read_poses(bound_at_spawn[field],opened.value).ok,"denied stage expired"):return {}
		rejected_commits+=1
		opened=field.begin_step(tick)
		if not verify(opened.ok,"retry begin"):return {}
		moved=field.stage_step(tick,DT,opened.value)
		if not verify(moved.ok,"retry stage"):return {}
	if not verify(field.commit_step(opened.value).ok,"commit"):return {}
	return moved.value

func geometry() -> bool:
	var crowd := PackedVector3Array()
	var radii := PackedFloat64Array()
	crowd.resize(50)
	radii.resize(50)
	radii.fill(0.28)
	var before := count_calls()
	var result: PackedInt32Array = ClassDB.class_call_static(&"FieldMoveKernel",&"solve",crowd,crowd,radii,PackedInt32Array(),0,1)
	if not verify(result==PackedInt32Array([-2,48]),"zero-displacement dense cap: "+str(result)):return false
	var positions := PackedVector3Array([Vector3(0,0,0),Vector3(.5,0,0),Vector3(.52,0,0)])
	var candidates := positions.duplicate()
	candidates[0]=Vector3(.1,0,0)
	radii.resize(3)
	for chosen in [[0,1,2],[0,2,1]]:
		result=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",positions,candidates,radii,PackedInt32Array(chosen),0,1)
		if not verify(result==PackedInt32Array([chosen[1],1]),"ordered equal-cell blockers: "+str(result)):return false
	positions=PackedVector3Array([Vector3(1.18,0,0),Vector3.ZERO])
	candidates=PackedVector3Array([Vector3(2.38,0,0),Vector3(1.23,0,0)])
	radii.resize(2)
	result=ClassDB.class_call_static(&"FieldMoveKernel",&"solve",positions,candidates,radii,PackedInt32Array(),0,2)
	return verify(result.size()==3 and result[0]==-1 and result[1]==-1 and count_calls()==before+4,"later actor sees vacated grid cell: "+str(result))

func probe() -> bool:
	var reference_script: Script = load(OS.get_environment("RECOLLECTION_QA_MOV_REFERENCE"))
	if not verify(reference_script!=null,"reference script"):return false
	var reference: RefCounted = reference_script.new(engine,scope,pipe._drive_authorized)
	var candidate: RefCounted = Move.new(engine,scope,pipe._drive_authorized)
	candidate._native_control=Callable(pipe,"_movement_grant_stamp")
	candidate._native_ai_tokens[credential] = true
	candidate._native_ai_tokens.make_read_only()
	var rows := {}
	var profile := ""
	for i in COUNT:
		var h := {"index":i,"generation":1}
		handles.append(h)
		profile = "mounted" if i==56 else "foot"
		for field in [reference,candidate]:
			if not verify(field.spawn(h,origin(i),profile,Vector3.RIGHT).ok,"spawn"):return false
		rows[i]={"handle":h,"source_slot":i,"components":{"team_key":0}}
	for field in [reference,candidate]:
		bound_at_spawn[field]=field.bind_roster(handles).value
	pipe._frame={"rows":rows}
	pipe._credentials[credential]={"issuer_id":"ai","team_key":0}
	pipe._credentials[second_credential]={"issuer_id":"second_ai","team_key":0}
	var calls := 0
	var native_rows := 0
	var yielded := 0
	var moved_cells := 0
	var last_cell := Vector2i.ZERO
	var was_airborne := false
	var landed := false
	var jumped := 0
	var mixed_jump_ticks := 0
	var stopped_at := Vector3.ZERO
	var saddle_travel := 0.0
	var order_asymmetry := false
	var mixed_short := 0
	var reused := 0
	var rebuilds := 0
	var lineup_rebuild_ticks := []
	var resident_ticks := 0
	var prior_resident := false
	var terrain_replaced := false
	for tick in 94:
		if tick==12:pipe._user_handle=handles[4]
		if tick==19:pipe._user_handle=handles[6]
		if tick in [20,22]:pipe._user_handle=null
		if tick==32:
			pipe._user_handle=handles[66]
			pipe._rules._status.control_mode="delegate"
		if tick==33:
			pipe._user_handle=null
			pipe._rules._status.control_mode="direct"
		if tick==36:pipe._user_handle=handles[67]
		if tick==38:pipe._user_handle=null
		if tick in [40,43]:
			rows=rows.duplicate(true)
			pipe._frame.rows=rows
		if tick==40:
			handles[61]={"index":61,"generation":2}
			rows[61].handle=handles[61]
		if tick==43:
			var reinforcement := {"index":123,"generation":1}
			handles.append(reinforcement)
			rows[123]={"handle":reinforcement,"source_slot":123,"components":{"team_key":0}}
		if tick==92:
			if not verify(prior_resident,"committed resident step before out-of-stage terrain replacement"):return false
			for owner in [reference,candidate]:
				if not verify(owner.set_terrain([]).ok,"out-of-stage terrain replacement"):return false
			terrain_replaced=true
		var before := count_calls()
		var old := staged(reference,tick)
		if failed or not verify(count_calls()==before,"reference invoked native"): return false
		var current := staged(candidate,tick)
		if failed:return false
		var delta := count_calls()-before
		calls+=delta
		prior_resident=int(current.get("resident_steps",0))>0
		if prior_resident:
			resident_ticks+=1
			rebuilds+=int(current.resident_rebuilds)
			if current.resident_rebuilds==0:reused+=1
			elif tick in [40,43]:lineup_rebuild_ticks.append(tick)
		native_rows+=int(current.get("native_rows",0))
		if not verify(current.yielding==old.yielding and current.nav_revision==old.nav_revision and current.total_queried==old.total_queried,"budget/yield differences at "+str(tick)):return false
		yielded+=int(old.yielding)
		if tick>12 and tick<23 and delta>0 and int(current.get("native_fallback_rows",0))>=12:mixed_short+=1
		for i in handles.size():
			var a: Dictionary = reference.view(handles[i]).value
			var b: Dictionary = candidate.view(handles[i]).value
			if not verify(var_to_bytes(a)==var_to_bytes(b),"pose mismatch tick=%d actor=%d old=%s candidate=%s"%[tick,i,str(a),str(b)]):return false
			if i==62 and not verify(b.profile==("mounted" if tick>=25 and tick<28 else "foot"),"profile round trip"):return false
			if tick in [19,20,21] and i==6 and not verify(b.blocked=="control_revoked" and b.velocity==Vector3.ZERO,"short revoked actor stays stopped when neighbouring runs join"):return false
			if tick==17 and i in [4,67] and not verify(b.blocked=="control_revoked" and b.velocity==Vector3.ZERO,"external callback changed grant before later actor"):return false
			if i==67 and tick in [36,37] and not verify(b.blocked=="control_revoked" and b.velocity==Vector3.ZERO,"revoke stopped movement"):return false
			if i==56:
				var cell := Vector2i(floori(b.position.x/1.2),floori(b.position.z/1.2))
				if tick>0 and cell!=last_cell:moved_cells+=1
				last_cell=cell
				saddle_travel=b.position.distance_to(origin(i))
			if i==57:
				if b.airborne:
					jumped+=1
					if delta>0 and int(current.get("native_fallback_rows",0))>0:mixed_jump_ticks+=1
				if was_airborne and not b.airborne:landed=true
				was_airborne=b.airborne
			if i==58 and tick==23:stopped_at=b.position
			if i==58 and tick>=24 and not verify(b.position==stopped_at and b.velocity==Vector3.ZERO,"zero-travel stop"):return false
		var rear: Dictionary = reference.view(handles[54]).value
		var front: Dictionary = reference.view(handles[55]).value
		if rear.blocked=="yield" and front.velocity.length()>0:order_asymmetry=true
	var results={"checks":checks,"native_calls":calls,"native_rows":native_rows,"ticks":94,"roster":COUNT,"yielding":yielded,
		"crossed_cells_mounted":moved_cells,"mounted_m":saddle_travel,"jump_ticks":jumped,"mixed_jump_ticks":mixed_jump_ticks,
		"landed":landed,"out_of_stage_terrain":terrain_replaced,"resident_ticks":resident_ticks,"reused":reused,"rebuilds":rebuilds,"lineup_rebuilt":lineup_rebuild_ticks,"short_fallback_ticks":mixed_short,"revoked_commits_retried":rejected_commits,"external_revocations":rejected_external,"callback_mutations":callback_mutations,"stale_tickets_rejected":stale_rosters,"rolled_back_replacements":rejected_replacements,"final_count":handles.size(),"order_asymmetry":order_asymmetry}
	print("NATIVE_BOUNDARY ",JSON.stringify(results))
	return verify(calls>0 and native_rows>0 and yielded>0 and moved_cells>0 and saddle_travel>2.0 and jumped>0 and mixed_jump_ticks>0 and landed and order_asymmetry and terrain_replaced and reused>10 and lineup_rebuild_ticks==[40,43] and mixed_short>0 and rejected_commits==4 and rejected_external==2 and callback_mutations==2 and stale_rosters==2 and rejected_replacements==2 and handles.size()==COUNT+1,"boundary coverage "+str(results))

func run() -> void:
	if not verify(ClassDB.class_exists(&"FieldMoveKernel") and ClassDB.class_has_method(&"FieldMoveKernel",&"call_count"),"unavailable native extension"):quit(1);return
	engine=Adapter.new(root,true)
	pipe=Pipeline.new(null,engine,"fixture",null,resolve_player,Callable())
	pipe._local={"issuer_id":"player","team_key":0}
	pipe._rules=preload("res://mission/rules/ports/field_rules.gd").new()
	pipe._rules._status={"control_mode":"direct"}
	scope=pipe._mission
	var opened: Dictionary = engine.open_scope(scope)
	if not verify(opened.ok and engine.load_scene({"id":"base:scene/qa_native","simulation_scene":"res://content/base/field/river_plain.tscn"},opened.value).ok,"river navigation"): quit(1);return
	var ready := false
	for unused in 120:
		await physics_frame
		var synced: Dictionary = engine.sync_navigation(scope)
		if not synced.ok or synced.value.status!="applied":continue
		var sample: Dictionary = engine.query_path_batch([{"from":[-10000,0,0],"to":[-8000,0,0]}],synced.value.applied_revision,scope)
		if sample.ok and sample.value[0].reachable:ready=true;break
	var passed := verify(ready,"navigation ready") and geometry() and probe()
	engine.release_scope(scope)
	print("NATIVE_BOUNDARY_SUMMARY checks=",checks," pass=",passed)
	quit(0 if passed else 1)
