import io
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
import argparse

here = Path(__file__).resolve().parent
repo = here.parents[2]
args=argparse.ArgumentParser()
args.add_argument("label")
args.add_argument("commit")
args.add_argument("--installer", type=Path)
args.add_argument("--kernel",type=Path,default=Path("out/resident/kernel"))
options=args.parse_args()
label = options.label
dest = here / label / "game"
commit = options.commit
assert label!="base" or commit=="bbcdc93"
revision = "HEAD" if commit=="worktree" else commit
archive = subprocess.check_output(["git", "archive", "--format=zip", revision, "game"], cwd=repo)
zipfile.ZipFile(io.BytesIO(archive)).extractall(dest.parent)
if commit=="worktree":
    dirty = subprocess.check_output(["git","diff","--name-only","HEAD","--","game"],cwd=repo,text=True).splitlines()
    for rel in dirty:
        shutil.copy2(repo/rel,dest.parent/rel)
    (here/f"{label}.patch").write_bytes(subprocess.check_output(["git","diff","--binary","HEAD","--","game"],cwd=repo))
shutil.copytree(repo/"game/.godot",dest/".godot")
if label=="base":
    reference=here/"archived"
    with zipfile.ZipFile(repo/"development/reports/tests/P2/field-native-move/experiment.zip") as z:
        for f in z.namelist():
            if f.startswith(("adapter/","kernel/")):
                z.extract(f,reference)
        (reference/"kernel/field_move.dll").write_bytes(z.read("game/native/field_move.dll"))
    options.installer=reference/"adapter/install.py"
    options.kernel=reference/"kernel"
    assert hashlib.sha256((options.kernel/"field_move.dll").read_bytes()).hexdigest()=="8da02c3c41b147be23a9a8727b52a33897d62fc6e559d46f6c41f8d1471240e6"
if options.installer:
    subprocess.run([sys.executable,str(options.installer.resolve()),str(dest)],check=True,cwd=repo)
    release=options.kernel.resolve()
    native=dest/"native"
    assert "res://native/field_move.gdextension" in (dest/".godot/extension_list.cfg").read_text(encoding="utf-8").splitlines()
    files=[*sorted(release.glob("*.cpp")),*sorted(release.glob("*.h")),native/"field_move.dll",native/"field_move.gdextension",options.installer,*sorted(options.installer.parent.glob("*.gd.inc"))]
    (here/f"{label}-build.json").write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2),encoding="utf-8")
(here/f"{label}-commit.txt").write_text(subprocess.check_output(["git","rev-parse",revision],cwd=repo,text=True).strip(),encoding="utf-8")
sources = {str(p.relative_to(dest)).replace('\\','/'):hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest() for p in dest.rglob('*.gd')}
(here/f"{label}-sources.json").write_text(json.dumps(sources,indent=2),encoding="utf-8")

def replace(path, old, new):
    p = dest / path
    src = p.read_text(encoding="utf-8")
    assert src.count(old) == 1, (p, old)
    p.write_text(src.replace(old, new), encoding="utf-8")

root = "bootstrap/composition_root.gd"
sig = "func field_step() -> Dictionary:"
replace(root, sig, sig + '''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench_field_step()
	var elapsed := Time.get_ticks_usec() - begin_us
	if reply.ok: Engine.get_main_loop().call("step_complete",self,reply.value,elapsed)
	return reply

func _bench_field_step() -> Dictionary:''')
pipeline = "mission/runtime/field_pipeline.gd"
for name in ["_think","_walk","_fight"]:
    ctx = "ctx" if name == "_fight" else "_ctx"
    sig = f"func {name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:"
    replace(pipeline, sig, sig+f'''
	var begin_us := Time.get_ticks_usec()
	var reply := _bench{name}({ctx},batch)
	var elapsed := Time.get_ticks_usec()-begin_us
	Engine.get_main_loop().call("phase_result","{name}",elapsed)
	return reply

func _bench{name}({ctx}: Dictionary, batch: Dictionary) -> Dictionary:''')
brains = "mission/runtime/field_brains.gd"
replace(brains, 'var published := _index(tick,nav,rows)', 'Engine.get_main_loop().call("member_rows",rows.size())\n\tvar published := _index(tick,nav,rows)')
replace(pipeline, 'return _brains.decide(tick,_draft.nav,units,_draft.com,player)', 'Engine.get_main_loop().call("member_rows",units.size())\n\treturn _brains.decide(tick,_draft.nav,units,_draft.com,player)')
mov = "mission/movement/ports/field_movement.gd"
def record(name,expr):
    return 'Engine.get_main_loop().call("phase_result","'+name+'",'+expr+')'
def timed(path, marker, next_marker, key):
    replace(path,marker,'var bench_'+key+' := Time.get_ticks_usec()\n\t'+marker)
    replace(path,next_marker,record(key,'Time.get_ticks_usec()-bench_'+key)+'\n\t'+next_marker)
timed(mov,'var ready := _prepare(tick)','_tick = tick\n\t_checks = 0','prepare')
grid='var bodies := _bodies.values()\n\t_prepare_grid(bodies)'
if grid not in (dest/mov).read_text(encoding="utf-8"):
    src=(dest/mov).read_text(encoding="utf-8")
    begin=src.index('if not is_same(_resident_list_stamps[_buffer_slot],_buffer_stamp):')
    end=src.index('_prepare_grid(bodies)',begin)+len('_prepare_grid(bodies)')
    grid=src[begin:end]
replace(mov,grid,'var bench_grid := Time.get_ticks_usec()\n\t'+grid+'\n\t'+record('grid','Time.get_ticks_usec()-bench_grid')+'\n\tvar bench_advance := Time.get_ticks_usec()')
finish='var shared: int = _queue.attempts_at(tick)'
replace(mov,finish,record('advance','Time.get_ticks_usec()-bench_advance')+'\n\t'+finish)
replace(mov, 'var shared: int = _queue.attempts_at(tick)', record('neighbor_checks','_checks')+'\n\t'+record('yielding','_yields')+'\n\tvar shared: int = _queue.attempts_at(tick)')
timed(pipeline,'var moved_poses:Dictionary=_move.read_poses(_draft.token,_draft.stage)','_draft["motion"]=moved_poses.value','read_poses')
bodies = "infrastructure/engine/field_bodies.gd"
sync='func _sync(next: Dictionary) -> void:'
replace(bodies,sync,sync+'\n\tvar placed_count := 0')
replace(bodies,'\t\t_place(index,row)\n\t_current = next','\t\tplaced_count += 1\n\t\t_place(index,row)\n\t'+record('physics_writebacks','placed_count')+'\n\t_current = next')
signature='func stage(rows: Array) -> Dictionary:'
replace(bodies,signature,signature+'\n\tvar begin := Time.get_ticks_usec()\n\tvar result := _bench_stage(rows)\n\t'+record('physics_stage','Time.get_ticks_usec()-begin')+'\n\treturn result\n\nfunc _bench_stage(rows: Array) -> Dictionary:')
replace(pipeline, '_draft["metrics"]=decision.value.metrics', '_draft["metrics"]=decision.value.metrics\n\tEngine.get_main_loop().call("ai_metrics",decision.value.metrics)')
if options.installer:
    replace(pipeline,'if not walk.ok: return walk','if not walk.ok: return walk\n\tEngine.get_main_loop().call("native_metrics",walk.value)')
shutil.copyfile(here/"bench.gd",dest/"bench.gd")
exec((here/"display_probe.py").read_text(encoding="utf-8"))
