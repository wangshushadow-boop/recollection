# 河原野战常驻移动数据桌面对照

Godot 4.7.2 Standard，Windows 桌面 NVIDIA RTX 3090 / Core Ultra 9 285K，960×600，Forward+。原版 DLL 取自仓库 field-native-move/experiment.zip，校验 SHA-256 8da02c3c41b147be23a9a8727b52a33897d62fc6e559d46f6c41f8d1471240e6。采样从 bbcdc93 提取 game，再将归档或候选安装器应用到隔离项目。常驻串行和四分片复用同一副本、同一份 DLL，运行前设置 RECOLLECTION_MOVE_WORKERS=1/4。

每组进行两次独立启动，均由主菜单进入河原，部署 45 显示帧后开始。500 士兵和 100 匹马，种子 241124、60 Hz、每显示帧最多补算两步。idle 为站立不发令样本 121–440 步。另一场第 1 步后向四个部队发移动令，第 900 步发自由攻击，march 为 121–440 步，contact 为第 986 步首次有效命中到 1260 步。所有帧指标均只取完整落入各窗口的 post_draw 间隔，用实际步数和墙钟求 FPS、每现实秒战斗步。

在 checkout 的 out/resident/bench/ 展开桌面包。新候选置于 out/resident/adapter 和 out/resident/kernel。本地 game/.godot 应已导入。使用未创建过的副本目录，依序运行：

```powershell
python out/resident/bench/prepare.py base bbcdc93
& ./out/resident/bench/run.ps1 base
python out/resident/bench/prepare.py serial bbcdc93 --installer out/resident/adapter/install.py
& ./out/resident/bench/run.ps1 serial serial 1
& ./out/resident/bench/run.ps1 parallel serial 4
python out/resident/bench/stats.py base serial parallel
python out/resident/bench/package.py base serial parallel
```

summary.json 包含推进（含准备/内核调用/合并）、完整战斗步、各帧 P50/P95、真实 DLL 参与数及工作量。检查每个战斗步的已调度个体数、让行数、实际代理写回数与战斗事件，并比较相同的命令、首击与机器。

outside_exclusive_ms_per_frame 按完整显示帧独占归因。逐帧从墙钟扣去完整战斗步、步前输入 before_input、步后客户端 after_step、present_frame、插值和脚本采样回调。步后再拆为 hud_read 与其余。present_frame 中的 visual_read 拆成可见性、COM 读取、角色装配和其余；其余显示工作分为 apply、hud_refresh 以及 present_other。稳定战斗 HUD 只由 present_frame 刷新。other_wall 是剩余墙钟（含引擎调度、展示/等待等）；gpu_ms 和 viewport_cpu_ms 是引擎独立渲染测量，与这些 CPU 工作可能重叠，不能加入墙钟分账。所有帧都检查各分项为非负且总和等于实际帧时间。

native 中 resident_rebuilds 为重建名册布局次数，其它 resident_* 是适配器的重填输入、重新验权、写回位姿、重编网格次序工作量；同时记录每帧步的 resident_steps、真实 DLL 批次数及分片调用。worker_count 为内核实际配置，parallel_batches 为 DLL 的 parallel_count 每步增量。串行与分片的结果均以真实桌面进程衡量，每版每场景只有一轮。
