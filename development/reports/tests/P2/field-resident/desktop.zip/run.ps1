param([Parameter(Mandatory)][string]$Label,[string]$ProjectLabel=$Label,[int]$Workers=1,[ValidateSet("both","idle","contact")][string]$Scenario="both")
$ErrorActionPreference = "Stop"
$base = $PSScriptRoot
$env:RECOLLECTION_MOVE_WORKERS="$Workers"
$env:APPDATA = Join-Path $base "$Label/appdata"
$env:LOCALAPPDATA = Join-Path $base "$Label/localdata"
New-Item -ItemType Directory -Force $env:APPDATA,$env:LOCALAPPDATA | Out-Null
foreach ($case in $(if($Scenario -eq "both") {@("idle","contact")} else {@($Scenario)})) {
    $env:SPARSE_SCENARIO = $case
    $env:SPARSE_CAPTURE = Join-Path $base "$Label-$case.json"
    & "D:/Program/Godot/Standard/Godot_v4.7.2-stable_win64_console.exe" --path (Join-Path $base "$ProjectLabel/game") --resolution 960x600 --log-file (Join-Path $base "$Label-$case.log") --script res://bench.gd -- --profile=client
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $env:SPARSE_CAPTURE)) { exit 1 }
}
