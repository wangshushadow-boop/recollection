# Runs from prepare.py on the isolated project, using its checked replace() helper.
scene="bootstrap/field_desktop.gd"
mission="mission/runtime/field_mission.gd"
visuals="presentation/visuals/ports/field_visuals.gd"
def stamp(key): return 'Engine.get_main_loop().call("display_span","'+key+'",Time.get_ticks_usec()-clock_'+key+')'
def wrap_span(path,method,params,args,return_type,key):
    signature='func '+method+'('+params+') -> '+return_type+':'
    impl='func _probe_'+method+'('+params+') -> '+return_type+':'
    body=signature+'\n\tvar clock_'+key+' := Time.get_ticks_usec()\n\t'
    if return_type!='void': body+='var value: '+return_type+' = '
    body+='_probe_'+method+'('+args+')\n\t'+stamp(key)
    if return_type!='void': body+='\n\treturn value'
    replace(path,signature,body+'\n\n'+impl)
def linespan(path,begin,end,key):
    replace(path,begin,'var clock_'+key+' := Time.get_ticks_usec()\n\t'+begin)
    replace(path,end,stamp(key)+'\n\t'+end)
wrap_span(scene,'before_step','tick: int','tick','Dictionary','before_input')
wrap_span(scene,'after_step','','','Dictionary','after_step')
wrap_span(scene,'present_frame','delta: float','delta','Dictionary','present')
wrap_span(visuals,'render_interpolated','alpha: float, eye: Vector3, near_radius: float = 22.0','alpha,eye,near_radius','void','interpolate')
wrap_span('presentation/ui/ports/field_hud.gd','refresh','','','Dictionary','hud_refresh')
linespan(scene,'var hud: Dictionary = application.field_view("hud")','if not hud.ok: return hud','hud_read')
linespan(scene,'var visual: Dictionary = application.field_view("visual")','if not visual.ok: return visual','visual_read')
linespan(scene,'var accepted := _visuals.apply_snapshot(_visual_state)','if not accepted.ok: return accepted\n\taccepted = _visuals.consume','apply')
linespan(mission,'var handles := []\n\tvar live_rows := _entities.rows()','var read: Dictionary=_com.field_view(_mission,handles)','visibility')
linespan(mission,'var read: Dictionary=_com.field_view(_mission,handles)','if not read.ok:return read\n\tvar actors := []','com_read')
linespan(mission,'var actors := []\n\tfor a in read.value.actors:','var visible_shots: Array=','actors')
replace(root,'if reply.ok: Engine.get_main_loop().call("step_complete",self,reply.value,elapsed)','var clock_harness := Time.get_ticks_usec()\n\tif reply.ok: Engine.get_main_loop().call("step_complete",self,reply.value,elapsed)\n\t'+stamp('harness'))
