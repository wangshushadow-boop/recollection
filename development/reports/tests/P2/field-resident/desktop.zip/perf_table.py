import json
from pathlib import Path

d=json.loads(Path(__file__).with_name("summary.json").read_text(encoding="utf-8"))
for scene in ("idle","march","contact"):
    for mode in ("base","serial","parallel"):
        s=d[mode][scene]
        n=s['native']
        print(scene,mode,'FPS/SPS',s['fps'],s['steps_per_second'],'field',s['field_step_ms']['p50'],s['field_step_ms']['p95'],'advance',s['advance_ms']['mean'],
              'pack/solve/merge',*[n[k]['mean'] for k in ('native_pack_ms','native_solve_ms','native_apply_ms')],
              'rebuild/input/pose/order/auth',*[n.get(k,{}).get('mean') for k in ('resident_rebuilds','resident_input_rows','resident_pose_rows','resident_order_rows','resident_auth_checks')],
              'resident/dispatched',n.get('total_resident_steps'),n.get('total_parallel_batches'))
