param([string]$ProjectLabel="revised")
$ErrorActionPreference="Stop"
foreach ($workers in @(1,4)) {
    $mode=if($workers -eq 1) {"serial"} else {"parallel"}
    & (Join-Path $PSScriptRoot "run.ps1") $mode $ProjectLabel $workers
    if ($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
}
