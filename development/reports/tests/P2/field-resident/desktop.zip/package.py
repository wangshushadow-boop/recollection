import hashlib
import json
import shutil
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
labels = sys.argv[1:] or ["base", "serial","parallel"]
if "parallel" in labels:
    for suffix in ("sources.json","build.json","commit.txt"):
        shutil.copyfile(here/f"serial-{suffix}",here/f"parallel-{suffix}")
files = ["prepare.py","display_probe.py","run.ps1","compare_workers.ps1","stats.py","bench.gd","table.py","perf_table.py","package.py","summary.json","README.md"]
for f in ("scout-build.json","scout-sources.json","scout-idle.log","scout-idle.json"):
    if (here/f).exists(): files.append(f)
for label in labels:
    files += [*(f"{label}-{case}.{ext}" for case in ["idle","contact"] for ext in ["json","log"])]
    files += [f"{label}-commit.txt",f"{label}-sources.json"]
    if (here/f"{label}-build.json").is_file(): files.append(f"{label}-build.json")
    if (here/f"{label}.patch").is_file(): files.append(f"{label}.patch")
manifest = {"frozen_project":{"base":"base","serial":"finalmove","parallel":"finalmove"},
            "git_baselines":{label:(here/f"{label}-commit.txt").read_text().strip() for label in labels},
            "sha256":{f:hashlib.sha256((here/f).read_bytes()).hexdigest() for f in files}}
(here/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
with zipfile.ZipFile(here/"desktop.zip","w",zipfile.ZIP_DEFLATED) as z:
    for f in ["manifest.json",*files]: z.write(here/f,f)
with zipfile.ZipFile(here/"desktop.zip") as z:
    assert z.testzip() is None
