import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path

here = Path(__file__).resolve().parent
def dist(rows):
    samples = sorted(rows)
    return {"mean":round(statistics.mean(samples),3), **{f"p{q}":round(samples[math.ceil(len(samples)*q/100)-1],3) for q in (50,95)}}

def segment(data, lo, hi):
    ticks = [s for s in data["steps"] if lo <= s[0] <= hi]
    assert [s[0] for s in ticks] == list(range(lo,hi+1))
    by_tick = {s[0]: s[1] for s in ticks}
    frames = [(b[1]-a[1],b[2],b[3],sum(by_tick[t] for t in range(a[1]+1,b[1]+1)),b[4],b[5]) for a,b in zip(data["frames"],data["frames"][1:]) if b[0]=="battle" and lo-1<=a[1]<=b[1]<=hi]
    assert frames and max(f[0] for f in frames)<=2
    seconds = sum(f[1] for f in frames)/1e6
    metrics = {"range":[lo,hi],"frames":len(frames),"per_frame_steps":Counter(f[0] for f in frames),
        "frame_ms":dist(f[1]/1000 for f in frames),"gpu_ms":dist(f[2] for f in frames),
        "outside_field_step_ms_per_frame":dist((f[1]-f[3])/1000 for f in frames),
        "fps":round(len(frames)/seconds,3),"steps_per_second":round(sum(f[0] for f in frames)/seconds,3),
        "field_step_ms":dist(s[1]/1000 for s in ticks), **{k+"_ms":dist(s[2][k]/1000 for s in ticks) for k in ["_think","_walk","_fight","prepare","grid","advance","read_poses","physics_stage"]},
        **{k:dist(s[2][k] for s in ticks) for k in ["neighbor_checks","yielding","physics_writebacks"]},
        "full_ai_rows_per_step":dist(s[2].get("full_rows",0) for s in ticks),"steps_with_full_ai_rows":sum(bool(s[2].get("full_rows")) for s in ticks),
        "admitted_individuals_per_step":dist(s[2]["due"] for s in ticks),"positive_hits":sum(s[3] for s in ticks),"damage":sum(s[4] for s in ticks),"shots":sum(s[5] for s in ticks)}
    budgets=[]
    for _,wall,_,step,display,_ in frames:
        s=Counter(display)
        budget={k:s[k] for k in ("before_input","hud_read","visibility","com_read","actors","apply","interpolate","hud_refresh","harness")}
        budget["after_step_other"]=s["after_step"]-s["hud_read"]
        budget["visual_read_other"]=s["visual_read"]-s["visibility"]-s["com_read"]-s["actors"]
        budget["present_other"]=s["present"]-s["visual_read"]-s["apply"]-s["hud_refresh"]
        budget["other_wall"]=wall-step-sum(budget.values())
        assert sum(budget.values())+step==wall
        assert all(x>=0 for x in budget.values()),budget
        budgets.append(budget)
    metrics["outside_exclusive_ms_per_frame"]={k:dist(row[k]/1000 for row in budgets) for k in budgets[0]}
    metrics["viewport_cpu_ms"]=dist(f[5] for f in frames)
    if "native_batches" in ticks[0][2]:
        fields=["native_batches","native_rows","native_fallback_rows","native_skipped_rows","native_foot_rows","native_mounted_rows"]
        stats={k:dist(s[2][k] for s in ticks) for k in fields}
        stats["steps_running_native"]=sum(s[2]["native_batches"]>0 for s in ticks)
        stats["total_batches"]=sum(s[2]["native_batches"] for s in ticks)
        native = sum(s[2]["native_rows"] for s in ticks)
        processed = sum(s[2]["native_rows"]+s[2]["native_fallback_rows"]+s[2]["native_skipped_rows"] for s in ticks)
        assert all(s[2]["native_rows"]==s[2]["native_foot_rows"]+s[2]["native_mounted_rows"] for s in ticks)
        stats["total_movement_rows"]=processed
        stats["native_active_rows"]=native
        stats["native_active_share_of_movement_rows"]=round(native/processed,5) if processed else 0
        for k in ("native_pack","native_solve","native_apply"):
            stats[k+"_ms"]=dist(s[2][k+"_us"]/1000 for s in ticks)
        if "resident_steps" in ticks[0][2]:
            for k in ("resident_rebuilds","resident_input_rows","resident_auth_checks","resident_pose_rows","resident_order_rows","resident_steps","worker_count","parallel_batches"):
                stats[k]=dist(s[2][k] for s in ticks)
                stats["total_"+k]=sum(s[2][k] for s in ticks)
        metrics["native"]=stats
    return metrics

def load(label,scenario):
    path=here/f"{label}-{scenario}.json"
    d=json.loads(path.read_text(encoding="utf-8"))
    assert d["cap"]==2 and d["window"]=="(960, 600)" and d["hz"]==60 and d["soldiers"]==500 and d["entities"]==600
    assert len(d["commands"]) == (5 if scenario=="contact" else 0)
    return d

def summarize(label):
    data={}
    for scenario in ["idle","contact"]:
        d=load(label,scenario)
        bounds=[121,440] if scenario=="idle" else [d["first_hit"],1260]
        if scenario=="contact":
            assert 1<bounds[0]<1260
        data[scenario]=dict(first_hit=d["first_hit"],cpu=d["cpu"],gpu=d["gpu"],**segment(d,*bounds))
        if scenario=="contact":
            assert d["first_hit"]>440
            data["march"]=dict(first_hit=d["first_hit"],cpu=d["cpu"],gpu=d["gpu"],**segment(d,121,440))
    return data

if __name__=="__main__":
    labels=sys.argv[1:]
    all_data={label:summarize(label) for label in labels}
    valid=True
    for candidate in labels[1:]:
        checks={}
        for scenario in ["idle","contact"]:
            a,b=[load(label,scenario) for label in [labels[0],candidate]]
            n=440 if scenario=="idle" else 1260
            check={"same_commands":a["commands"]==b["commands"],"same_first_hit":a["first_hit"]==b["first_hit"],"same_machine":a["gpu"]==b["gpu"] and a["cpu"]==b["cpu"]}
            for field in ("due","yielding","physics_writebacks","combat"):
                def observation(s): return s[3:] if field=="combat" else s[2][field]
                check[field+"_first_different_tick"]=next((x[0] for x,y in zip(a["steps"][:n],b["steps"][:n],strict=True) if observation(x)!=observation(y)),None)
            checks[scenario]=check
            valid &= all(value is True if name.startswith("same_") else value is None for name,value in check.items())
        activated=all(all_data[candidate][scenario].get("native",{}).get("total_batches",0)>0 for scenario in ("idle","march","contact"))
        for scenario in ("idle","march","contact"):
            probe=all_data[candidate][scenario]["native"]
            activated &= probe.get("total_resident_steps",0)>0
            if candidate in ("serial","parallel"):
                activated &= probe["worker_count"]["mean"]==(1 if candidate=="serial" else 4)
                activated &= (probe["total_parallel_batches"]>0)==(candidate=="parallel")
        valid &= activated
        all_data.setdefault("workload_check",{})[candidate]={"status":"PASS" if valid else "FAIL","activation":activated,"scenarios":checks}
    out=json.dumps(all_data,indent=2,ensure_ascii=False)
    (here/("summary.json" if len(labels)>1 else labels[0]+"-summary.json")).write_text(out,encoding="utf-8")
    print(out)
    sys.exit(int(not valid))
