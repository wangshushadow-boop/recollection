"""Measure the actual primary menu button in two PNGs by its solid brass leading border."""
import json
from pathlib import Path
from PIL import Image
import sys

def run(folder):
    evidence=json.loads((folder/"result.json").read_bytes())
    lengths=[]
    for tag in ("960","1800"):
        image=Image.open(folder/("menu-"+tag+".png")).convert("RGB")
        x,y,w,h=evidence["metrics"]["menu_"+tag]["logical"]
        sx,sy=evidence["metrics"]["menu_"+tag]["scale"]
        col=round((x+1)*sx)
        mid=round((y+h*.5)*sy)
        colour=image.getpixel((col,mid))
        assert colour==(211,173,113),("button border color",colour)
        first=last=mid
        while first>0 and image.getpixel((col,first-1))==colour:first-=1
        while last+1<image.height and image.getpixel((col,last+1))==colour:last+=1
        lengths.append(last-first+1)
    assert lengths[0]>=44 and 1.70<=lengths[1]/lengths[0]<=1.99,lengths
    print("Primary menu button raster heights in 960x600 and 1800x1350:",*lengths)
    (folder/"pixel-heights.json").write_text(json.dumps({"menu_button_height":lengths,"ratio":lengths[1]/lengths[0]}))

if __name__=="__main__":
    run(Path(sys.argv[1]))
