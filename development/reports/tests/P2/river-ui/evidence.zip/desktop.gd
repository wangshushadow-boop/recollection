extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)

func dimensions(n: Control, tag: String):
	verify(visible(n),"control inside visible canvas "+tag, n.get_global_rect())
	metrics[tag]=geom(n)

func compare_size(name: String):
	var s: Dictionary=metrics[name+"_960"]
	var b: Dictionary=metrics[name+"_1800"]
	var ratio:float=b.height/s.height
	verify(ratio>=1.55 and ratio<=2.5,"physical control height follows window scale "+name,ratio)

func current_map() -> Dictionary:
	return scene._hud._view.get("tactical_map",{})

func check_contacts(map: Control):
	for i in 45:
		await process_frame
		var sample:=current_map()
		var visual:Dictionary=scene._visual_state
		if sample.get("sample_tick",-1)!=visual.get("tick",-2):continue
		var own:=PackedVector2Array()
		var foes:=PackedVector2Array()
		var read:Dictionary=scene._hud_state
		for row in visual.get("actors",[]):
			if row.handle==read.actor_handle or row.role=="mount" or row.hp<=0 or row.phase=="Downed":continue
			var pos:Vector3=row.position
			if row.team==read.player.team:own.append(Vector2(pos.x,pos.z))
			else:foes.append(Vector2(pos.x,pos.z))
		verify(sample.allies==own and sample.enemies==foes and own.size()>0,
			"all contacts exactly match the player's authorised visual snapshot",[visual.tick,own.size(),foes.size(),sample.allies.size(),sample.enemies.size()])
		verify(map.get("_allies")==own and map.get("_enemies")==foes,"drawn contacts match the authorised projection")
		var camps:PackedVector2Array=sample.get("rallies",PackedVector2Array())
		var goals:PackedVector2Array=sample.get("objectives",PackedVector2Array())
		verify(camps.size()==1 and camps[0].is_equal_approx(Vector2(-52,0)) and goals.size()==1 and goals[0].is_equal_approx(Vector2.ZERO)
			and map.get("_rallies")==camps and map.get("_objectives")==goals,"river map shows friendly camp and central objective only",[camps,goals,map.get("_rallies"),map.get("_objectives")])
		return
	verify(false,"sampled a matching map/visual tick within 45 display frames")

func labels() -> String:
	var copy:=PackedStringArray()
	for n in scene._hud.find_children("*","Label",true,false):
		if n.is_visible_in_tree():copy.append(n.text)
	return "|".join(copy)

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(DisplayServer.get_name()!="headless" and root.size==SMALL,"real 960x600 window",root.size):return
	if not verify(main._desktop!=null,"menu mounted"):return
	var entry: Button = main._desktop._buttons.field
	if not verify(visible(entry),"field action immediately visible"):return
	var art:=find_node("CampaignLandscape") as TextureRect
	if not verify(visible(art) and art.texture!=null,"painted campaign landscape imported and visible"):return
	dimensions(entry,"menu_960")
	await snapshot("menu-960")
	await resize(BIG)
	dimensions(entry,"menu_1800")
	await snapshot("menu-1800")
	compare_size("menu")
	if not verify(await click(entry),"click menu action at resized resolution"):return
	scene=main._field_scene
	if not verify(scene!=null and not scene.running,"deployment scene"):return
	var settings:=find_node("Settings") as Button
	if not verify(visible(settings) and settings.size.x>=settings.get_theme_font("font").get_string_size(settings.text,HORIZONTAL_ALIGNMENT_LEFT,-1,settings.get_theme_font_size("font_size")).x+8,
		"deployment settings button fits its caption",[settings.size,settings.text]):return
	var begin:=find_node("Deploy")
	if not verify(visible(begin),"default start inscreen"):return
	dimensions(begin,"deploy_1800")
	await snapshot("deploy-1800")
	await resize(SMALL)
	if not verify(await click(settings) and visible(find_node("BackMenu")),"open deployment settings from labelled button"):return
	if not verify(await click(find_node("BackMenu")) and visible(begin),"return to deployment from settings"):return
	dimensions(begin,"deploy_960")
	await snapshot("deploy-960")
	compare_size("deploy")
	if not verify(await click(begin),"default placement accepted"):return
	for i in 100:
		await process_frame
		if scene.running and not current_map().is_empty():break
	if not verify(scene.running and not current_map().is_empty(),"live tactical map projection",main._last_tick):return
	var map:=find_node("TacticalMap")
	var gear:=find_node("Equipment")
	var meter:=find_node("HealthBar") as ProgressBar
	if not verify(visible(map) and visible(gear) and visible(meter),"visible tactical map and health block"):return
	await check_contacts(map)
	var read:Dictionary=scene._hud_state
	if not verify(meter.value==float(read.player.hp),"health bar from controlled actor",meter.value):return
	var words:=labels()
	verify(str(read.player.morale) in words and str(read.player.ammo) in words,"current morale and ammo visible",words)
	verify(not map.get_global_rect().intersects(gear.get_global_rect()),"map and character stats do not overlap")
	dimensions(map,"map_960")
	dimensions(gear,"status_960")
	await snapshot("battle-960")
	var first:=current_map()
	var before:Vector3=first.origin
	var head:Vector3=first.heading
	move_mouse(root.get_visible_rect().get_center(),Vector2(60,0))
	key(KEY_W,true)
	for i in 125:
		await process_frame
		var current:=current_map()
		if not current.is_empty() and (current.origin as Vector3).distance_to(before)>.3 and (current.heading as Vector3).distance_to(head)>.02:break
	key(KEY_W,false)
	var end:=current_map()
	verify(not end.is_empty() and (end.origin as Vector3).distance_to(before)>.3,"moving player updates minimap centre",[before,end.get("origin")])
	verify(not end.is_empty() and (end.heading as Vector3).distance_to(head)>.02,"turning player updates minimap heading",[head,end.get("heading")])
	await resize(BIG)
	dimensions(map,"map_1800")
	dimensions(gear,"status_1800")
	compare_size("map")
	compare_size("status")
	await snapshot("battle-1800")
	tap(KEY_ESCAPE)
	await frames(3)
	var resume:=find_node("Resume")
	if not verify(visible(resume) and Input.mouse_mode==Input.MOUSE_MODE_VISIBLE and not map.is_visible_in_tree(),"Esc opens menu and hides combat map"):return
	dimensions(resume,"resume_1800")
	await snapshot("esc-1800")
	if not verify(await click(resume),"click scaled Resume control"):return
	verify(Input.mouse_mode==Input.MOUSE_MODE_CAPTURED and visible(map),"resume restores player HUD")
	var native := OS.get_environment("RIVER_NATIVE")=="1"
	verify(ClassDB.class_exists(&"FieldMoveKernel")==native,"expected native loader")
	if native:verify(int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))>0,"native DLL executed")
	tap(KEY_ESCAPE)
	await frames(3)
	if not verify(await click(find_node("Withdraw")) and await click(find_node("Confirm")),"leave battle via confirmation"):return
	for i in 80:
		await process_frame
		if main._root.session().query().value.state=="Results":break
	await frames(3)
	verify(not map.is_visible_in_tree(),"map cleared from results")
	if not verify(await click(find_node("Leave")),"close results"):return
	verify(main._field_scene==null and visible(entry),"title menu restored")

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("RIVER_UI_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))
