import ctypes as C
from ctypes import wintypes as W
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

root = Path.cwd()
out = root / "out/river-ui-build"
profile = out / ("wrappers-" + uuid.uuid4().hex[:8])
profile.mkdir()
env = os.environ | {"APPDATA": str(profile), "LOCALAPPDATA": str(profile)}
user = C.windll.user32
user.SetProcessDPIAware()
k = C.windll.kernel32
k.OpenProcess.restype = W.HANDLE
k.QueryFullProcessImageNameW.argtypes = (W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD))
k.CloseHandle.argtypes = (W.HANDLE,)
engine = Path(r"D:\Program\Godot\Standard\Godot_v4.7.2-stable_win64.exe")
normal = root / "启动游戏.cmd"
native = root / "development/reports/tests/P2/field-resident/试玩常驻版野战.cmd"
evidence = []

def windows():
    found = {}
    @C.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
    def each(hwnd, unused):
        b = C.create_unicode_buffer(512)
        user.GetWindowTextW(hwnd, b, len(b))
        if not b.value.lower().startswith("recollection") or not user.IsWindowVisible(hwnd):
            return True
        pid = W.DWORD()
        user.GetWindowThreadProcessId(hwnd, C.byref(pid))
        h = k.OpenProcess(0x1000, False, pid.value)
        if h:
            path = C.create_unicode_buffer(4096)
            count = W.DWORD(len(path))
            if k.QueryFullProcessImageNameW(h, 0, path, C.byref(count)) and Path(path.value) == engine:
                found[pid.value] = hwnd
            k.CloseHandle(h)
        return True
    user.EnumWindows(each, 0)
    return found

def until(call, seconds=50):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        result = call()
        if result:
            return result
        time.sleep(.15)
    raise AssertionError(f"timed out at {call}")

def launch(script, tag):
    before = windows()
    with (profile/(tag+".log")).open("wb") as log:
        p = subprocess.Popen([os.environ["COMSPEC"], "/d", "/c", script.name], cwd=script.parent,
                             env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                             creationflags=subprocess.CREATE_NO_WINDOW)
        code = p.wait(timeout=90)
        assert code == 0, (tag, code)
    hwnd = until(lambda: next((h for pid,h in windows().items() if pid not in before), 0))
    time.sleep(1.8)
    return hwnd

def size(hwnd, outer=False):
    r = W.RECT()
    assert (user.GetWindowRect if outer else user.GetClientRect)(hwnd,C.byref(r))
    return r.right-r.left,r.bottom-r.top

def record(hwnd, phase):
    evidence.append({"action":phase, "client":size(hwnd), "maximized":bool(user.IsZoomed(hwnd))})
    print(evidence[-1],flush=True)

def close(hwnd):
    assert user.PostMessageW(hwnd,0x10,0,0)
    until(lambda: not user.IsWindow(hwnd))
    time.sleep(.5)

h = launch(normal, "normal-first")
try:
    record(h,"normal-first")
    a,b = size(h)
    x,y = size(h, True)
    assert user.SetWindowPos(h,0,0,0,1272+x-a,792+y-b,0x16)
    until(lambda: size(h)==(1272,792))
    time.sleep(.4)
    record(h,"normal-resized")
finally:
    close(h)
h = launch(native, "native-reopen")
try:
    record(h,"native-reopen")
    assert size(h)==(1272,792) and not user.IsZoomed(h)
    user.ShowWindowAsync(h,3)
    until(lambda:user.IsZoomed(h))
    time.sleep(.5)
    record(h,"native-maximized")
finally:
    close(h)
h = launch(normal, "normal-reopen")
try:
    record(h,"normal-reopen")
    assert user.IsZoomed(h)
    user.ShowWindowAsync(h,9)
    until(lambda:size(h)==(1272,792))
    record(h,"normal-restored")
finally:
    close(h)
(out/"launcher-window.json").write_text(json.dumps(evidence,indent=2),encoding="utf8")
