extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var model: Node3D
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func button_down(code: MouseButton, pressed:bool):
	var e:=InputEventMouseButton.new()
	e.button_index=code;e.pressed=pressed
	e.position=root.get_visible_rect().get_center()
	e.global_position=e.position
	root.push_input(e,true)

func flat(v:Vector3)->Vector3:
	return Vector3(v.x,0,v.z).normalized()

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	var app:RefCounted=main._root
	var setup:Dictionary=preload("res://bootstrap/field_setup.gd").build(app._services.content,"custom",2,2,241124)
	if not verify(setup.ok,"valid two-person field fixture",setup.get("error",{})):return
	var spec:Dictionary=setup.value.spec
	spec.reserved_sources[0].loadout_snapshot_id="field:equipment/cavalry"
	var session:RefCounted=app.session()
	if not verify(session.start_session("custom",{}).ok,"custom session opened"):return
	app._field_launch=true
	app._field_authority=RefCounted.new()
	var opened:Dictionary=session.prepare_mission(spec,setup.value.scene,setup.value.rules)
	app._field_launch=false
	if not verify(opened.ok,"equipped hero on real river mission",opened.get("error",{})):return
	scene=load("res://bootstrap/field_desktop.gd").new()
	main._field_scene=scene
	main.add_child(scene)
	scene.leave_requested.connect(main._leave_field)
	if not verify(scene.mount(app,opened.value).ok,"mounted desktop field controller"):return
	main._desktop.hide()
	await frames(6)
	if not verify(await click(find_node("Deploy")),"begin battle"):return
	print("MOUNT begin running=",scene.running," tick=",main._last_tick," state=",session.query().value.state)
	await ticks(12)
	var mount_handle:Variant=scene._hud_state.player.mount_handle
	if not verify(mount_handle!=null and scene._camera.state().mode=="mounted","real controlled mounted hero",scene._hud_state.player):return
	var horse=scene._visuals._actors[mount_handle.index]
	if not verify(horse.figure!=null and horse.figure.root.is_visible_in_tree(),"horse has live rendered rig"):return
	model=horse.figure.root
	var forward:=flat(model.global_basis.z)
	var start: Vector3=model.global_position
	move_mouse(root.get_visible_rect().get_center(),Vector2(630,0))
	await ticks(12)
	var look_after:=flat(-scene._camera.global_basis.z)
	verify(forward.dot(flat(model.global_basis.z))>.99 and forward.dot(look_after)<.3,"turning camera leaves horse pointing in its original direction",[forward,flat(model.global_basis.z),look_after])
	key(KEY_W,true)
	await ticks(55)
	var end:Vector3=model.global_position
	var displacement:=end-start
	var speed_w:float=horse.speed
	verify(displacement.length()>1 and flat(displacement).dot(forward)>.9,"W rides in horse's facing with camera looking sideways",displacement)
	key(KEY_W,false)
	var hold:=await trace_horse("coast",48)
	verify(hold.path_m>.8 and hold.average_mps>speed_w*.8,"horse keeps gait with W released",hold)
	var before:Vector3=flat(model.global_basis.z)
	key(KEY_A,true)
	var turn_l:Dictionary=await trace_horse("left_turn",55)
	verify(turn_l.stalled_ticks<turn_l.ticks/2 and turn_l.average_mps>hold.average_mps*.5,"left turn retains movement",turn_l)
	var left:Vector3=flat(model.global_basis.z)
	verify(before.signed_angle_to(left,Vector3.UP)>.1,"A steers the horse left while riding",[before,left])
	key(KEY_A,false)
	key(KEY_D,true)
	var turn_r:Dictionary=await trace_horse("right_turn",65)
	verify(turn_r.stalled_ticks<turn_r.ticks/2 and turn_r.average_mps>hold.average_mps*.5,"right turn retains movement",turn_r)
	var right:Vector3=flat(model.global_basis.z)
	verify(left.signed_angle_to(right,Vector3.UP)<-.1,"D steers the horse right while riding",[left,right])
	key(KEY_D,false)
	key(KEY_W,false)
	var before_brake:Vector3=model.global_position
	key(KEY_S,true)
	await trace_horse("braking",90)
	var brake_speed:float=horse.speed
	verify(brake_speed<speed_w-.1,"S slows the horse",[speed_w,brake_speed])
	key(KEY_S,false)
	metrics["horse"]={"start":str(start),"after_w":str(end),"w_forward":str(forward),"camera":str(look_after),"left":str(left),"right":str(right),"before_brake":str(before_brake),"fast":speed_w,"braked":brake_speed}
	await snapshot("mounted")
	var native:=OS.get_environment("RIVER_NATIVE")=="1"
	verify(ClassDB.class_exists(&"FieldMoveKernel")==native,"expected build")
	if native: metrics["native_calls_in_two_person_fixture"] = int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count")) # Only 8+ consecutive eligible AI riders/foot soldiers are batched; default 500-person field verifies the DLL runs.

func trace_horse(label:String,n:int)->Dictionary:
	var since:int=main._last_tick
	var last:Vector3=model.global_position
	var start_face:Vector3=flat(model.global_basis.z)
	var last_face:=start_face
	var turn:=0.0
	var path:=0.0
	var min_speed:=INF
	var step_sample:=since
	var stalls:=0
	while main._last_tick<since+n:
		await RenderingServer.frame_post_draw
		var now:int=main._last_tick
		var dt:=now-step_sample
		if dt<=0:continue
		var at:Vector3=model.global_position
		var f:=flat(model.global_basis.z)
		var dist:=at.distance_to(last)
		var speed:=dist*60.0/dt
		min_speed=minf(speed,min_speed)
		if speed<.2:stalls+=dt
		path+=dist
		turn+=last_face.signed_angle_to(f,Vector3.UP)
		last=at
		last_face=f
		step_sample=now
	var data:={"path_m":path,"ticks":main._last_tick-since,"average_mps":path*60.0/(main._last_tick-since),"turn_deg":rad_to_deg(turn),"min_rendered_mps":min_speed,"stalled_ticks":stalls}
	metrics[label]=data
	return data

func ticks(n:int):
	var until_tick:int=main._last_tick+n
	var t:=Time.get_ticks_msec()
	while main._last_tick<until_tick and Time.get_ticks_msec()-t<6000:await process_frame
	verify(main._last_tick>=until_tick,"battle advances required steps",[main._last_tick,until_tick])

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("DIRECTION_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

