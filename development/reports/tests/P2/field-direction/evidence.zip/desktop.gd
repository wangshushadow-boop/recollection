extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var model: Node3D
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func button_down(code: MouseButton, pressed:bool):
	var e:=InputEventMouseButton.new()
	e.button_index=code;e.pressed=pressed
	e.position=root.get_visible_rect().get_center()
	e.global_position=e.position
	root.push_input(e,true)

func flat(v:Vector3)->Vector3:
	return Vector3(v.x,0,v.z).normalized()

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(DisplayServer.get_name()!="headless" and root.size==SMALL,"real 960x600 window",root.size):return
	if not verify(await click(main._desktop._buttons.field),"enter field via main menu"):return
	scene=main._field_scene
	if not verify(await click(find_node("Deploy")),"start field via deployment button"):return
	for i in 180:
		await process_frame
		if scene.running and main._last_tick>8:break
	if not verify(scene.running and main._last_tick>8,"field running",main._last_tick):return
	var actor: Dictionary = scene._hud_state.actor_handle
	var proxy = scene._visuals._actors[actor.index]
	if not verify(proxy.figure!=null and proxy.figure.root.is_visible_in_tree(),"live rendered player model",actor):return
	model = proxy.figure.root
	var native := OS.get_environment("RIVER_NATIVE")=="1"
	verify(ClassDB.class_exists(&"FieldMoveKernel")==native,"expected renderer build native status",native)
	var forward := flat(-scene._camera.global_basis.z)
	var right := flat(scene._camera.global_basis.x)
	verify(flat(model.global_basis.z).dot(forward)>.99,"starting actor faces ahead of camera",model.global_basis.z)
	key(KEY_A,true)
	var start_z:float=model.global_position.z
	var approach_tick:int=main._last_tick
	while model.global_position.z>start_z-10.0 and main._last_tick-approach_tick<320:
		await process_frame
	key(KEY_A,false)
	key(KEY_W,true)
	await ticks(56)
	key(KEY_W,false)
	await ticks(5)
	verify(model.global_position.z<start_z-8.0,"walked out of the crowded starting formation",model.global_position)
	var cases := [
		["S",[KEY_S],-forward],["A",[KEY_A],-right],["D",[KEY_D],right],["S_D",[KEY_S,KEY_D],(-forward+right).normalized()],["W_A",[KEY_W,KEY_A],(forward-right).normalized()],
		["W",[KEY_W],forward],["W_D",[KEY_W,KEY_D],(forward+right).normalized()],["S_A",[KEY_S,KEY_A],(-forward-right).normalized()]
	]
	for c: Array in cases:
		var label:String=c[0]
		var goal:Vector3=c[2]
		var start_tick:int=main._last_tick
		var start_pos:Vector3=model.global_position
		var start_face:=flat(model.global_basis.z)
		for code in c[1]:key(code,true)
		var middle:=false
		var last:=start_face
		var max_rate:=0.0
		var prior:int=start_tick
		while main._last_tick-start_tick<52:
			await RenderingServer.frame_post_draw
			var body:=flat(model.global_basis.z)
			if body.dot(start_face)<.98 and body.dot(goal)<.98:middle=true
			var elapsed:int=main._last_tick-prior
			if elapsed>0:
				max_rate=maxf(max_rate,rad_to_deg(last.angle_to(body))/elapsed)
				last=body; prior=main._last_tick
		var displacement:=model.global_position-start_pos
		var face:=flat(model.global_basis.z)
		var hdg:=flat(scene._hud_state.heading)
		var cam:=flat(-scene._camera.global_basis.z)
		var m:={"tick":main._last_tick,"displacement":str(displacement),"model":str(face),"camera":str(cam),"towards_motion":face.dot(goal),"towards_camera_forward":face.dot(cam),"turn_deg":rad_to_deg(start_face.angle_to(face)),"mid_turn":middle,"max_observed_deg_per_tick":max_rate}
		metrics[label]=m
		verify(displacement.length()>.3 and flat(displacement).dot(goal)>.8,label+" moved along input",displacement)
		verify(face.dot(goal)>.98,label+" rendered character faces travel",m)
		verify(face.dot(hdg)>.98,label+" rendered character agrees with battle heading",hdg)
		verify(cam.dot(forward)>.999,label+" camera maintained original heading",cam)
		if label in ["S","A","D"]:
			verify(middle and max_rate<12,label+" visible intermediate rotation",max_rate)
			await snapshot(label)
		for code in c[1]:key(code,false)
		await ticks(4)
		verify(flat(model.global_basis.z).dot(face)>.99,label+" kept facing after release")
	button_down(MOUSE_BUTTON_RIGHT,true)
	key(KEY_D,true)
	await ticks(15)
	verify(scene._hud_state.player.phase=="Guard" and flat(model.global_basis.z).dot(forward)>.99,"guard stays on sight while strafing",model.global_basis.z)
	button_down(MOUSE_BUTTON_RIGHT,false)
	key(KEY_D,false)
	await ticks(8)
	tap(KEY_R)
	key(KEY_S,true)
	await ticks(15)
	verify(scene._camera.state().mode=="first" and flat(scene._hud_state.heading).dot(forward)>.99,"first-person backward travel keeps aim",scene._hud_state.heading)
	key(KEY_S,false)
	tap(KEY_R)
	await ticks(8)
	if native: verify(int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))>0,"native movement executed")
	tap(KEY_ESCAPE)
	await frames(3)
	if not verify(await click(find_node("Withdraw")) and await click(find_node("Confirm")),"withdraw through battle menu"):return
	await frames(4)
	verify(await click(find_node("Leave")) and main._field_scene==null,"return to main menu")

func ticks(n:int):
	var until_tick:int=main._last_tick+n
	while main._last_tick<until_tick:await process_frame

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("DIRECTION_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

