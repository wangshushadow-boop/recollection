extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var model: Node3D
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func button_down(code: MouseButton, pressed:bool):
	var e:=InputEventMouseButton.new()
	e.button_index=code;e.pressed=pressed
	e.position=root.get_visible_rect().get_center()
	e.global_position=e.position
	root.push_input(e,true)

func flat(v:Vector3)->Vector3:
	return Vector3(v.x,0,v.z).normalized()

func wait_phase(wanted:String, budget:=48) -> bool:
	var deadline:int=main._last_tick+budget
	while main._last_tick<deadline and str(scene._hud_state.player.phase)!=wanted: await process_frame
	return str(scene._hud_state.player.phase)==wanted

func figure():
	return scene._visuals._actors[scene._hud_state.actor_handle.index].figure

func sample_pose() -> Array:
	var skel:Skeleton3D=figure().skeleton
	var joints:=[]
	for name_ in ["Spine","LeftArm","LeftForeArm","LeftHand","RightArm","RightForeArm","RightHand"]:
		var id:=skel.find_bone(name_)
		if id>=0: joints.append(skel.get_bone_global_pose(id).basis.get_rotation_quaternion().normalized())
	return joints

func pose_gap(a:Array,b:Array) -> float:
	var maximum:=0.0
	for i in range(mini(a.size(),b.size())):
		maximum=maxf(maximum,a[i].angle_to(b[i]))
	return maximum

func compare_directions(samples:Dictionary,kind:String):
	var dirs:=samples.keys()
	for i in dirs.size():
		for j in range(i):
			var diff:=pose_gap(samples[dirs[i]],samples[dirs[j]])
			verify(diff>.23,kind+" distinct upper-body pose "+dirs[i]+"/"+dirs[j],rad_to_deg(diff))

func set_aim(yaw:float,pitch:float):
	var current:Vector2=scene._input_port.view().preview_aim
	var delta:=Vector2(-angle_difference(current.x,yaw),current.y-pitch)/.0025
	move_mouse(root.get_visible_rect().get_center(),delta)

func release_and_trace() -> Dictionary:
	var origin_tick:int=main._last_tick
	var actor:Dictionary=scene._hud_state.actor_handle
	var suffix:=":%s:%s"%[actor.index,actor.generation]
	var result:={}
	button_down(MOUSE_BUTTON_LEFT,false)
	var end:int=main._last_tick+56
	while main._last_tick<end:
		await RenderingServer.frame_post_draw
		for id:String in scene._visuals._shots:
			if result.is_empty() and id.ends_with(suffix) and int(id.get_slice(":",0))>=origin_tick:
				var shot:Dictionary=scene._visuals._shots[id]
				result={"direction":shot.direction,"position":shot.position,"id":id}
	return result

func nearest_enemy() -> Dictionary:
	var player:Dictionary=scene._hud_state.player
	var pos:Vector3=figure().root.global_position
	var nearest:={}
	var distance:=INF
	for row:Dictionary in scene._visual_state.actors:
		if row.team==player.team or row.phase=="Downed" or row.role=="mount": continue
		var gap:=pos.distance_to(row.position)
		if gap<distance:
			distance=gap
			nearest=row
	return nearest

func test_field_hit():
	var target:=nearest_enemy()
	if not verify(not target.is_empty(),"enemy visible in river field"):return
	var start_tick:int=main._last_tick
	var gap:float=figure().root.global_position.distance_to(target.position)
	key(KEY_W,true)
	while gap>20.0 and main._last_tick-start_tick<2200:
		if scene._input_port.view().mode=="ui":
			print("QA: testing window lost focus; resume through the battle menu at ",main._last_tick)
			root.grab_focus()
			if not await click(find_node("Resume")):break
			key(KEY_W,true)
		var toward:Vector3=target.position-figure().root.global_position
		set_aim(atan2(-toward.x,-toward.z),0)
		await ticks(12)
		target=nearest_enemy()
		if target.is_empty():break
		gap=figure().root.global_position.distance_to(target.position)
	key(KEY_W,false)
	if not verify(not target.is_empty() and gap<=20.0,"approached opponent to short range",[gap,scene._input_port.view().mode]):return
	button_down(MOUSE_BUTTON_LEFT,true)
	if not verify(await wait_phase("Hold"),"held draw for aimed shot"):return
	await ticks(3)
	target=nearest_enemy()
	var muzzle:Vector3=scene._hud_state.player.shot_origin
	var aim:Vector3=target.position+Vector3.UP*1.28-muzzle
	set_aim(atan2(-aim.x,-aim.z),atan2(aim.y,Vector2(aim.x,aim.z).length()))
	await ticks(3)
	await snapshot("bow-target")
	var actor:Dictionary=scene._hud_state.actor_handle
	var mission=main._root._field_mission.get_ref()
	var suffix:=":%s:%s"%[actor.index,actor.generation]
	var report:={}
	var deadline:int=main._last_tick+46
	var ammo:int=scene._hud_state.player.ammo
	button_down(MOUSE_BUTTON_LEFT,false)
	while main._last_tick<deadline and report.is_empty():
		await physics_frame
		for h:Dictionary in mission._frame.get("combat_report",{}).get("hits",[]):
			if h.attacker==actor and h.attack_id.ends_with(suffix) and h.damage>0:report=h
	metrics.targeted={"distance_m":gap,"target":target.handle,"hit":report,"ammo_before":ammo,"ammo_after":scene._hud_state.player.ammo}
	verify(not report.is_empty() and scene._hud_state.player.ammo==ammo-1,"short-range field arrow causes confirmed damage",metrics.targeted)

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(DisplayServer.get_name()!="headless" and root.size==SMALL,"real 960x600 window",root.size):return
	if not verify(await click(main._desktop._buttons.field),"enter field via main menu"):return
	scene=main._field_scene
	if not verify(await click(find_node("Deploy")),"start field via deployment button"):return
	await ticks(10)
	if not verify(scene.running and figure()!=null,"controlled hero has a visible high-detail model"):return
	var native:=OS.get_environment("RIVER_NATIVE")=="1"
	verify(native==ClassDB.class_exists(&"FieldMoveKernel"),"expected compiled edition",native)
	key(KEY_A,true)
	await ticks(170)
	key(KEY_A,false)
	key(KEY_W,true)
	await ticks(40)
	key(KEY_W,false)
	await ticks(8)
	tap(KEY_KP_ADD)
	await ticks(3)
	var actors=scene._visuals._actors
	var proxy=actors[scene._hud_state.actor_handle.index]
	var left:=MOUSE_BUTTON_LEFT
	var right:=MOUSE_BUTTON_RIGHT
	var hold:={}
	var guard:={}
	var dirs={"up":Vector2(0,-10),"thrust":Vector2(0,10),"left":Vector2(-10,0),"right":Vector2(10,0)}
	for dir:String in dirs:
		move_mouse(root.get_visible_rect().get_center(),dirs[dir])
		button_down(left,true)
		verify(await wait_phase("Hold"),"melee holds "+dir,scene._hud_state.player)
		await ticks(6)
		await RenderingServer.frame_post_draw
		verify(proxy.direction==dir,"combat direction "+dir,proxy.direction)
		hold[dir]=sample_pose()
		await snapshot("melee-"+dir)
		button_down(left,false)
		var after:=[]
		var swing_angle:=0.0
		var release_tick:int=main._last_tick
		while main._last_tick-release_tick<25:
			await RenderingServer.frame_post_draw
			var phase:String=scene._hud_state.player.phase
			if phase not in after:after.append(phase)
			if phase in ["Active","Recovery"]:
				swing_angle=maxf(swing_angle,pose_gap(hold[dir],sample_pose()))
		verify("Active" in after and "Recovery" in after and "Ready" in after,"melee release goes through swing, recovery and ready "+dir,after)
		verify(swing_angle>.37,"rendered upper body actually swings after "+dir,rad_to_deg(swing_angle))
		button_down(right,true)
		verify(await wait_phase("Guard"),"guard accepted "+dir)
		await ticks(10)
		await RenderingServer.frame_post_draw
		verify(proxy.direction==dir,"guard direction "+dir,proxy.direction)
		guard[dir]=sample_pose()
		await snapshot("guard-"+dir)
		button_down(right,false)
		verify(await wait_phase("Ready"),"release guard "+dir)
	compare_directions(hold,"melee")
	compare_directions(guard,"guard")
	var ammo:int=scene._hud_state.player.ammo
	metrics.initial_ammo=ammo
	button_down(MOUSE_BUTTON_WHEEL_UP,true)
	button_down(MOUSE_BUTTON_WHEEL_UP,false)
	await ticks(8)
	if verify(scene._hud_state.player.weapon_slot==1,"mouse wheel equips the bow",scene._hud_state.player):
		var bow=figure().ranged_weapon
		verify(bow!=null and bow.is_visible_in_tree(),"equipped bow appears in hero's hand")
		var arrow:Node3D=bow.get_node_or_null("NockedArrow") if bow!=null else null
		verify(arrow!=null and not arrow.is_visible_in_tree(),"idle bow has no nocked arrow")
		var relaxed:Vector3=arrow.position if arrow!=null else Vector3.ZERO
		await snapshot("bow-ready")
		var ready_pose:=sample_pose()
		button_down(left,true)
		verify(await wait_phase("Hold"),"bow reaches aiming hold",scene._hud_state.player)
		await ticks(8)
		await RenderingServer.frame_post_draw
		verify(pose_gap(ready_pose,sample_pose())>.35,"nocked bow uses a drawn upper-body pose",rad_to_deg(pose_gap(ready_pose,sample_pose())))
		verify(arrow!=null and arrow.is_visible_in_tree() and arrow.position.distance_to(relaxed)>.15,"arrow is nocked and bowstring draws visibly back",arrow.position if arrow!=null else null)
		verify(scene._hud_state.player.ammo==ammo,"drawing spends no arrows")
		await snapshot("bow-drawn")
		key(KEY_QUOTELEFT,true)
		move_mouse(root.get_visible_rect().get_center(),Vector2(480,0))
		await ticks(4)
		await snapshot("bow-side")
		key(KEY_QUOTELEFT,false)
		await ticks(3)
		tap(KEY_R)
		await ticks(4)
		verify(scene._camera.state().mode=="first" and scene._hud_state.player.phase=="Hold" and bow!=null and bow.is_visible_in_tree(),"held bow remains live in first-person")
		await snapshot("bow-first")
		tap(KEY_R)
		await ticks(4)
		button_down(right,true)
		button_down(right,false)
		await ticks(3)
		button_down(left,false)
		await ticks(28)
		verify(scene._hud_state.player.ammo==ammo and scene._hud_state.player.phase=="Ready","cancel a held draw without shooting",scene._hud_state.player)
		verify(arrow!=null and not arrow.is_visible_in_tree(),"cancel removes the nocked arrow")
		var yaw:float=scene._input_port.view().preview_aim.x
		set_aim(yaw,.34)
		await ticks(2)
		button_down(left,true)
		verify(await wait_phase("Hold"),"can draw again after cancel")
		await ticks(6)
		var high:=await release_and_trace()
		verify(scene._hud_state.player.ammo==ammo-1,"one release spends exactly one arrow",scene._hud_state.player.ammo)
		verify(high.get("direction",Vector3.ZERO).y>.22,"upward aim launches player's visible arrow upward",high)
		set_aim(yaw,-.12)
		await ticks(2)
		button_down(left,true)
		verify(await wait_phase("Hold"),"second draw ready")
		await ticks(6)
		var low:=await release_and_trace()
		verify(scene._hud_state.player.ammo==ammo-2,"second release spends one more arrow",scene._hud_state.player.ammo)
		verify(low.get("direction",Vector3.ZERO).y<-.06,"downward aim launches player's visible arrow downward",low)
		metrics.high=high
		metrics.low=low
		await test_field_hit()
		verify(await wait_phase("Ready"),"bow has recovered before switching back")
		button_down(MOUSE_BUTTON_WHEEL_UP,true)
		button_down(MOUSE_BUTTON_WHEEL_UP,false)
		await ticks(6)
		verify(scene._hud_state.player.weapon_slot==0 and (bow==null or not bow.is_visible_in_tree()),"cycle back to melee",scene._hud_state.player)
	if native: verify(int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))>0,"native movement kernel executed")
func ticks(n:int):
	var until_tick:int=main._last_tick+n
	while main._last_tick<until_tick:await process_frame

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("ACTION_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

