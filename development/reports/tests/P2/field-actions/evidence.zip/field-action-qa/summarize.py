"""Assemble the four desktop execution results without modifying project files."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
summary = {}
for run in ("frozen", "leaders-frozen", "native-frozen", "leaders-native"):
    result = json.loads((root/run/"evidence.json").read_text(encoding="utf8"))
    summary[run] = {
        "checks": len(result["checks"]),
        "passed_checks": sum(x["ok"] for x in result["checks"]),
        "passed": result["passed"] and result["exit_code"] == 0 and not result["errors"] and not result["changed_during_run"],
        "failed": [x for x in result["checks"] if not x["ok"]],
        "changes": result["changed_during_run"],
        "metrics": result["metrics"],
    }
(root/"desktop-summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf8")
for run, row in summary.items():
    print(run, row["passed_checks"], "/", row["checks"], row["passed"], row["changes"])
raise SystemExit(int(not all(row["passed"] for row in summary.values())))
