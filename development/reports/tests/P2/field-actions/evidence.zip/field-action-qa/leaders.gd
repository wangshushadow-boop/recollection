extends SceneTree

const SMALL := Vector2i(960,600)
const BIG := Vector2i(1800,1350)
var out := OS.get_environment("RIVER_UI_OUT")
var model: Node3D
var main: Node
var scene: Node
var checks := []
var metrics := {}
var passed := true

func _initialize():
	start.call_deferred()

func verify(condition: bool, label: String, details: Variant="") -> bool:
	checks.append({"ok":condition,"label":label,"details":str(details)})
	if not condition:
		passed=false
		printerr("FAIL ", label, " ",details)
	return condition

func frames(count: int):
	for i in count: await process_frame

func snapshot(name: String):
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	verify(img.get_size()==root.size and img.save_png(out+"/"+name+".png")==OK,"physical screenshot "+name,img.get_size())

func geom(node: Control) -> Dictionary:
	var rect := node.get_global_rect()
	# Screen-space transform in this client omits the root canvas_items stretch.
	# The PNG is the physical framebuffer; the full-rect desktop is in canvas units.
	var full_canvas:Vector2=main._desktop.size
	var scale := Vector2(root.size)/full_canvas
	return {"width":node.size.x*scale.x,"height":node.size.y*scale.y,"logical":[rect.position.x,rect.position.y,rect.size.x,rect.size.y],"scale":[scale.x,scale.y],"window":[root.size.x,root.size.y],"canvas":[full_canvas.x,full_canvas.y]}

func resize(to: Vector2i):
	root.size=to
	for i in 18:
		await process_frame
		if root.size==to:break
	await frames(4)
	verify(root.size==to,"OS client window resize",root.size)

func find_node(id: String) -> Control:
	return main.find_child(id,true,false) as Control

func visible(n: Control) -> bool:
	return is_instance_valid(n) and n.is_visible_in_tree() and n.size.x>0 and n.size.y>0 and root.get_visible_rect().grow(2.0).encloses(n.get_global_rect())

func move_mouse(pos: Vector2, relative:=Vector2.ZERO):
	var e := InputEventMouseMotion.new()
	e.position=pos;e.global_position=pos;e.relative=relative;e.screen_relative=relative
	root.push_input(e,true)

func click(n: Control) -> bool:
	if not visible(n):return false
	var pos:=n.get_global_rect().get_center()
	move_mouse(pos)
	for down: bool in [true,false]:
		var e:=InputEventMouseButton.new()
		e.position=pos;e.global_position=pos;e.pressed=down;e.button_index=MOUSE_BUTTON_LEFT
		root.push_input(e,true)
	await frames(3)
	return true

func key(code: Key, down: bool):
	var e:=InputEventKey.new()
	e.keycode=code;e.physical_keycode=code;e.pressed=down
	root.push_input(e,true)

func tap(code: Key):
	key(code,true);key(code,false)
func button_down(code: MouseButton, pressed:bool):
	var e:=InputEventMouseButton.new()
	e.button_index=code;e.pressed=pressed
	e.position=root.get_visible_rect().get_center()
	e.global_position=e.position
	root.push_input(e,true)

func flat(v:Vector3)->Vector3:
	return Vector3(v.x,0,v.z).normalized()

func wait_phase(wanted:String, budget:=48) -> bool:
	var deadline:int=main._last_tick+budget
	while main._last_tick<deadline and str(scene._hud_state.player.phase)!=wanted: await process_frame
	return str(scene._hud_state.player.phase)==wanted

func figure():
	return scene._visuals._actors[scene._hud_state.actor_handle.index].figure

func sample_pose() -> Array:
	var skel:Skeleton3D=figure().skeleton
	var joints:=[]
	for name_ in ["Spine","LeftArm","LeftForeArm","LeftHand","RightArm","RightForeArm","RightHand"]:
		var id:=skel.find_bone(name_)
		if id>=0: joints.append(skel.get_bone_global_pose(id).basis.get_rotation_quaternion().normalized())
	return joints

func pose_gap(a:Array,b:Array) -> float:
	var maximum:=0.0
	for i in range(mini(a.size(),b.size())):
		maximum=maxf(maximum,a[i].angle_to(b[i]))
	return maximum

func set_aim(yaw:float,pitch:float):
	var current:Vector2=scene._input_port.view().preview_aim
	var delta:=Vector2(-angle_difference(current.x,yaw),current.y-pitch)/.0025
	move_mouse(root.get_visible_rect().get_center(),delta)

var template:Node3D
var ref_anim:AnimationPlayer
var ref_skel:Skeleton3D

func compare_gait(pose_name:String, minimum_samples:int):
	var f=figure()
	if template==null:
		template=load(f.root.scene_file_path).instantiate()
		template.visible=false
		root.add_child(template)
		ref_anim=template.find_children("*","AnimationPlayer",true,false)[0]
		ref_anim.callback_mode_process=AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
		ref_skel=template.find_children("*","Skeleton3D",true,false)[0]
	var clip:String=f.clip
	ref_anim.play(clip)
	var max_neck:=0.0
	var max_lean:=0.0
	var max_side_lean:=0.0
	var gait_error:=0.0
	var original_side:=0.0
	var clip_matches:=0
	var changed_frame:=false
	var previous_time:float=f.player.current_animation_position
	for i in minimum_samples:
		await RenderingServer.frame_post_draw
		var at:float=f.player.current_animation_position
		if f.clip==("Run" if "run" in pose_name else "Idle"):clip_matches+=1
		if absf(at-previous_time)>.001:changed_frame=true
		previous_time=at
		ref_anim.seek(at,true)
		var skel:Skeleton3D=f.skeleton
		var head_id:=skel.find_bone("Head")
		var spine_id:=skel.find_bone("Spine")
		var neck_id:=skel.find_bone("Neck")
		var trunk:Vector3=skel.get_bone_global_pose(head_id).origin-skel.get_bone_global_pose(spine_id).origin
		var original:Vector3=ref_skel.get_bone_global_pose(head_id).origin-ref_skel.get_bone_global_pose(spine_id).origin
		original_side=maxf(original_side,absf(atan2(original.x,original.y)))
		max_lean=maxf(max_lean,trunk.angle_to(Vector3.UP))
		max_side_lean=maxf(max_side_lean,absf(atan2(trunk.x,trunk.y)))
		max_neck=maxf(max_neck,skel.get_bone_pose_rotation(neck_id).angle_to(skel.get_bone_rest(neck_id).basis.get_rotation_quaternion()))
		for name_ in ["LeftUpLeg","RightUpLeg","LeftLeg","RightLeg"]:
			var id:=skel.find_bone(name_)
			if id>=0: gait_error=maxf(gait_error,skel.get_bone_pose_rotation(id).angle_to(ref_skel.get_bone_pose_rotation(id)))
	var m:={"clip":clip,"samples":minimum_samples,"expected_clip_frames":clip_matches,"neck_deg":rad_to_deg(max_neck),"lean_deg":rad_to_deg(max_lean),"side_lean_deg":rad_to_deg(max_side_lean),"raw_side_lean_deg":rad_to_deg(original_side),"leg_gait_error_deg":rad_to_deg(gait_error)}
	metrics[pose_name]=m
	verify(clip_matches==minimum_samples,pose_name+" sampled consecutive frames of the expected animation",m)
	verify(changed_frame and m.neck_deg<25 and m.side_lean_deg<17 and m.lean_deg<38,pose_name+" head and torso stay balanced through the gait",m)
	verify(gait_error<.05,pose_name+" original lower-body gait preserved",m)

func presentation_tests():
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	root.grab_focus()
	await frames(6)
	if not verify(DisplayServer.get_name()!="headless" and root.size==SMALL,"real desktop river scene",root.size):return
	if not verify(await click(main._desktop._buttons.field),"main menu field button"):return
	scene=main._field_scene
	if not verify(await click(find_node("Deploy")),"start ordinary deployment"):return
	await ticks(9)
	var mission=main._root._field_mission.get_ref()
	var actors:Dictionary=scene._visuals._actors
	var people:=[[],[]]
	var leaders:={}
	var horses:=0
	for row:Dictionary in mission._entities.rows():
		var team:int=row.components.team_key
		if row.source_slot==null:
			horses+=1
			continue
		var pos:Vector3=mission._frame.pose[row.handle.index].position
		var unit:={"id":row.handle.index,"hero":row.components.get("hero_id"),"position":pos}
		people[team].append(unit)
		if unit.hero!=null and unit.hero==mission._spec.sides[team].commander_hero_id:
			verify(not leaders.has(team),"one commander allocated to side "+str(team))
			leaders[team]=unit
	verify(people[0].size()==250 and people[1].size()==250 and horses==100,"unchanged 500 soldiers and 100 horses",[people[0].size(),people[1].size(),horses])
	if not verify(leaders.size()==2 and leaders[0].hero!=leaders[1].hero,"both teams have distinct live commanders",leaders):return
	for team:int in range(2):
		var lead:Dictionary=leaders[team]
		var dir:Vector3=Vector3.RIGHT if team==0 else Vector3.LEFT
		var center:Vector3=Vector3.ZERO
		var front:=-INF
		var zmin:=INF
		var zmax:=-INF
		for member:Dictionary in people[team]:
			if member.id==lead.id: continue
			center+=Vector3(member.position)
			front=maxf(front,member.position.dot(dir))
			zmin=minf(zmin,member.position.z)
			zmax=maxf(zmax,member.position.z)
		var advance:float=lead.position.dot(dir)-front
		var lateral:float=absf(lead.position.z-(zmin+zmax)*.5)
		var info:={"ahead_m":advance,"center_offset_m":lateral,"hero":lead.hero,"index":lead.id,"position":lead.position}
		metrics["team"+str(team)]=info
		verify(advance>=.9 and lateral<.8,"side "+str(team)+" leader front and centered",info)
		verify(actors.has(lead.id) and actors[lead.id].get("model_key")=="commander","side "+str(team)+" uses commander visual",lead.id)
	var own=actors[leaders[0].id]
	var enemy=actors[leaders[1].id]
	verify(own.figure!=null and own.figure.root.scene_file_path.ends_with("/general.glb"),"player actually rendered from general.glb",own.figure.root.scene_file_path)
	var matched_bake:=false
	for group:String in scene._visuals._batches.groups:
		if not group.begins_with("commander"):continue
		var g:Dictionary=scene._visuals._batches.groups[group]
		for transform_:Transform3D in g.transforms:
			if transform_.origin.distance_to(enemy.position)<.5:matched_bake=true
	verify(enemy.figure==null and matched_bake,"enemy general actually present in distant commander mesh batches")
	await snapshot("leaders-start")
	var spawn:Vector3=own.position
	key(KEY_W,true)
	await ticks(322)
	key(KEY_W,false)
	await ticks(8)
	verify(own.position.distance_to(spawn)>14,"walked into the open in front of the formation before sampling",own.position.distance_to(spawn))
	await snapshot("own-general-gear")
	button_down(MOUSE_BUTTON_WHEEL_UP,true)
	button_down(MOUSE_BUTTON_WHEEL_UP,false)
	await ticks(8)
	if not verify(scene._hud_state.player.weapon_slot==1 and own.figure.ranged_weapon!=null,"own general can carry real short bow"):return
	var begin:Vector3=own.figure.root.global_position
	key(KEY_S,true)
	await ticks(42)
	verify(own.figure.clip=="Run" and own.position.distance_to(begin)>1.0,"S runs general toward camera",own.figure.clip)
	await compare_gait("bow-run",12)
	await snapshot("bow-run-front")
	key(KEY_S,false)
	await ticks(12)
	await compare_gait("bow-idle",6)
	await snapshot("bow-idle-front")
	button_down(MOUSE_BUTTON_LEFT,true)
	verify(await wait_phase("Hold"),"general can draw bow")
	await ticks(4)
	key(KEY_QUOTELEFT,true)
	move_mouse(root.get_visible_rect().get_center(),Vector2(480,0))
	await ticks(4)
	await snapshot("general-bow-side")
	key(KEY_QUOTELEFT,false)
	await ticks(3)
	button_down(MOUSE_BUTTON_RIGHT,true)
	button_down(MOUSE_BUTTON_RIGHT,false)
	button_down(MOUSE_BUTTON_LEFT,false)
	await ticks(12)
	key(KEY_S,true)
	await ticks(40)
	await compare_gait("bow-run-after-draw",12)
	await snapshot("bow-run-after-draw")
	key(KEY_S,false)
	await ticks(8)
	# Approach through ordinary input, allowing the visual LOD to pick the enemy's near mesh.
	var gap:float=own.position.distance_to(enemy.position)
	var start_tick:int=main._last_tick
	key(KEY_W,true)
	while gap>5.0 and main._last_tick-start_tick<2200:
		if scene._input_port.view().mode=="ui":
			root.grab_focus()
			if not await click(find_node("Resume")):break
			key(KEY_W,true)
		var v:Vector3=enemy.position-own.position
		set_aim(atan2(-v.x,-v.z),0)
		await ticks(12)
		gap=own.position.distance_to(enemy.position)
	key(KEY_W,false)
	if not verify(gap<=5.0 and enemy.figure!=null and enemy.figure.root.is_visible_in_tree(),"player reached enemy general and LOD switched to a visible near model",gap):return
	verify(enemy.figure.root.scene_file_path.ends_with("/general.glb"),"enemy near model is general.glb",enemy.figure.root.scene_file_path)
	tap(KEY_R)
	key(KEY_SHIFT,true)
	await ticks(5)
	await snapshot("enemy-general")
	key(KEY_SHIFT,false)
	if OS.get_environment("RIVER_NATIVE")=="1":verify(int(ClassDB.class_call_static(&"FieldMoveKernel",&"call_count"))>0,"real native movement executed")
	template.queue_free()
func ticks(n:int):
	var until_tick:int=main._last_tick+n
	while main._last_tick<until_tick:await process_frame

func start():
	await presentation_tests()
	var file:=FileAccess.open(out+"/result.json",FileAccess.WRITE)
	file.store_string(JSON.stringify({"passed":passed,"checks":checks,"metrics":metrics},"  "))
	file.close()
	print("LEADER_DESKTOP checks=",checks.size()," passed=",passed)
	if main!=null and is_instance_valid(main):
		if main._field_scene!=null:main._release_field_scene()
		main.queue_free()
		await process_frame
	quit(int(not passed))

