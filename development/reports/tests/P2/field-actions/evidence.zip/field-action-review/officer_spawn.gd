extends SceneTree
const Composition = preload("res://bootstrap/composition_root.gd")
const Config = preload("res://bootstrap/boot_config.gd")
var failed := false
var app: RefCounted

func expect(criterion: bool, label: String) -> bool:
	print("PASS " if criterion else "FAIL ",label)
	if not criterion: failed=true
	return criterion

func _initialize() -> void:
	test.call_deferred()

func test() -> void:
	var config := Config.resolve([],DisplayServer.get_name(),{})
	app=Composition.new(root)
	if not expect(app.boot(config.value).ok,"boot") or not expect(app.session().start_session("custom",{}).ok,"custom"):
		quit(1);return
	var small := "--small" in OS.get_cmdline_user_args()
	var limit := 3 if small else 20
	var total := 5 if small else 40
	if not expect(app.start_field(limit,total).ok,"river"):quit(1);return
	var opening:Dictionary=app.field_view("hud").value
	if "--manual" in OS.get_cmdline_user_args():
		var site: String=opening.deployment_zones[0].id
		var req: Dictionary
		for i in 60:
			await physics_frame
			req=app.field_command("field.deploy",{"placements":[{"formation_id":2,"zone_id":site,"layout":"line"}]},opening.revision,"review-deploy")
			if req.ok or req.error.field not in ["navigation_sync","nav_revision","field.navigation","deployment.spawn_site"]:break
		if not expect(req.ok,"deploy archers before infantry: "+str(req)):quit(1);return
	var step: Dictionary
	for i in 60:
		await physics_frame
		step=app.field_step()
		if step.ok:break
	if not expect(step.ok,"open"):quit(1);return
	var entities:Array=step.value.entities
	var people:=entities.filter(func(e):return e.source_slot!=null)
	var leaders:=people.filter(func(e):return e.components.hero_id!=null)
	expect(people.size()==limit,"heads: "+str(people.size()))
	if not expect(leaders.size()==2,"two officers: "+str(leaders.size())):quit(1);return
	expect(leaders[0].components.hero_id!=leaders[1].components.hero_id,"two identities")
	var player:Dictionary=app.field_view("input").value.actor_handle
	var officers: Dictionary={}
	for officer in leaders:
		var team:int=officer.components.team_key
		expect(not officers.has(team) and (officer.handle==player)==(team==0),"correct possession and faction: "+str(team))
		officers[team]=officer.handle
		var p:Array=officer.components.spawn_position_mm
		var gap:int=9999999
		for unit in people:
			if unit==officer or unit.components.team_key!=team:continue
			gap=mini(gap,(p[0]-unit.components.spawn_position_mm[0])*(1 if team==0 else -1))
		expect(gap>0,"team %d officer at %s, front margin %s mm"%[team,p,gap])
	for i in 119:
		if not app.field_step().ok:break
	var lived:Array=app.field_view("visual").value.actors
	for team in officers:
		var selected:Array=lived.filter(func(e):return e.handle==officers[team])
		if selected.is_empty():continue
		var gap:float=INF
		for e in lived:
			if e.handle!=officers[team] and e.team==team and e.role!="mount":
				gap=minf(gap,(selected[0].position.x-e.position.x)*(1 if team==0 else -1))
		print("STABLE team ",team," officer=",selected[0].position," margin=",gap,"m")
	app.shutdown()
	quit(int(failed))
