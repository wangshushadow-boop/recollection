from hashlib import sha256
from pathlib import Path
import json
import zipfile
import sys


here = Path(__file__).resolve().parent
root = here.parents[1]
project = Path(sys.argv[1]).resolve()
label = sys.argv[2]
candidate = here / label
baseline = root / "out/pose-qa/final"
files = ["mission/ai/ports/field_ai.gd", "mission/ai/perception/field_perception.gd",
         "mission/ai/individual/ports/field_individual.gd","mission/runtime/field_brains.gd",
         "mission/movement/ports/field_movement.gd"]
hashes = {f:sha256((project/f).read_bytes()).hexdigest() for f in files}
settings = {}
for f in [files[-1], files[-2]]:
    settings[f] = [line for line in (project/f).read_text(encoding="utf-8").splitlines()
                     if line.startswith("const ") and "BATCH" in line]
summary = json.loads((candidate/"summary.json").read_text(encoding="utf-8"))
log = (candidate/"behavior.log").read_text(encoding="utf-8")
assert summary["trace_sha256"]=="8f52df5f89f6d652ff9beaa6cdc7ee0132c90bf2056f3de366747d6c1b8405a8"
assert summary["status"]=="PASS" and summary["comparison"]["same_ticks"]==1260
assert "ROLLBACK PASS attempted_tick=986 last_committed=985 visual_unchanged=true" in log
manifest_path = candidate/"verification.json"
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
else:
    manifest = dict(source_sha256=hashes, mode=settings, snapshot_reject_and_retry=986,
                    desktop=False, behavior_sha256=summary["trace_sha256"])
    manifest_path.write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
with zipfile.ZipFile(here/"qa.zip","w",zipfile.ZIP_DEFLATED) as z:
    for p in ["run.py","behavior.gd","evidence.py"]:
        z.write(here/p,p)
    if (here/"quiet_blocked.log").exists():
        quiet = (here/"quiet_blocked.log").read_text(encoding="utf-8")
        assert "QUIET_BLOCKED checks=12 failures=0" in quiet and "ERROR:" not in quiet
        z.write(here/"quiet_blocked.gd","quiet_blocked.gd")
        z.write(here/"quiet_blocked.log","quiet_blocked.log")
    for p in ["summary.json","behavior.json"]:
        z.write(baseline/p,"baseline/"+p)
    for directory in sorted({candidate,here/"batch2"}):
        for p in ["summary.json","behavior.json","behavior.log","verification.json"]:
            z.write(directory/p,directory.name+"/"+p)
print(manifest)
