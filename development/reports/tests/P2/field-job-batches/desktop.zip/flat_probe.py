"""Add timers to a disposable copy prepared with prepare.py. No game source edits."""
from pathlib import Path
import re
import shutil
import sys

here = Path(__file__).resolve().parent
src, dst = sys.argv[1:]
root = here / dst / "game"
shutil.copytree(here / src / "game", root)

def wrap(rel, func, args, key, frame=False):
    path = root / rel
    source = path.read_text(encoding="utf-8")
    signature, = re.findall(r"^func " + func + r"\([^\n]*\) -> (?:Dictionary|void):$", source, re.M)
    void = signature.endswith("void:")
    body = [signature, "\tvar start_us := Time.get_ticks_usec()",
            "\t" + ("" if void else "var result := ") + "_bench_" + func + "(" + args + ")"]
    hook = '"record_span"' if frame else '"record_work"'
    suffix = "" if frame else ",0,0"
    body.append(f'\tEngine.get_main_loop().call({hook},"{key}",Time.get_ticks_usec()-start_us{suffix})')
    if not void:
        body.append("\treturn result")
    body.extend(["", signature.replace("func ", "func _bench_", 1)])
    path.write_text(source.replace(signature, "\n".join(body)), encoding="utf-8")

for func in ["_walk", "_think", "_fight", "_start", "_snapshot"]:
    wrap("mission/runtime/field_pipeline.gd",func,("_ctx" if func in ["_walk","_think"] else "ctx")+",batch",func)
wrap("mission/movement/ports/field_movement.gd","_scene_clearances","tick,dt","clearance")
for func, args in [("before_step","tick"),("after_step",""),("present_frame","delta"),("_process","_dt")]:
    wrap("bootstrap/field_desktop.gd",func,args,func,True)
path = root / "bootstrap/field_desktop.gd"
source = path.read_text(encoding="utf-8")
for key, anchor in [("visual_view",'var visual: Dictionary = application.field_view("visual")'),
                    ("apply_snapshot","var accepted := _visuals.apply_snapshot(_visual_state)")]:
    assert source.count(anchor)==1
    source=source.replace(anchor,f"var t_{key} := Time.get_ticks_usec()\n\t{anchor}\n\tEngine.get_main_loop().call(\"record_span\",\"{key}\",Time.get_ticks_usec()-t_{key})")
path.write_text(source,encoding="utf-8")
path = root / "mission/movement/ports/field_movement.gd"
source = path.read_text(encoding="utf-8")
marker = "var hits: Dictionary = _engine.query_sweep_batch(requests,"
assert source.count(marker) == 1
source = source.replace(marker,'Engine.get_main_loop().call("record_work","fine",0,requests.size(),requests.size())\n\t'+marker)
path.write_text(source,encoding="utf-8")
