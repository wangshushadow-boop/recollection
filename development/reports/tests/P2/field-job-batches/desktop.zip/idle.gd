extends SceneTree
var spans := {}
var frames := []
var main
var phase := "menu"
var last_us := 0
var phase_frames := 0
var done := false
func record_span(key: String, us: int) -> void:
	if not spans.has(key): spans[key]=[0,0]
	spans[key][0]+=1
	spans[key][1]+=us
var work := {}
var steps := []
func record_work(key: String, us: int, entities: int, units: int) -> void:
	if not work.has(key): work[key]=[0,0,0]
	work[key][0]+=us
	work[key][1]+=entities
	work[key][2]+=units
func record_step(tick: int, us: int) -> void:
	steps.append([tick,us,work])
	work={}
func _initialize() -> void:
	start.call_deferred()
func start() -> void:
	main=load("res://bootstrap/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	RenderingServer.viewport_set_measure_render_time(root.get_viewport_rid(),true)
	RenderingServer.frame_post_draw.connect(on_draw)
func press(caption: String) -> void:
	for n in main.find_children("*","Button",true,false):
		if n.text==caption and n.is_visible_in_tree():
			n.pressed.emit()
			return
	printerr("Missing entry ",caption)
	quit(3)
func on_draw() -> void:
	if done:return
	var now:=Time.get_ticks_usec()
	if last_us:
		frames.append({"phase":phase,"tick":main._last_tick,"us":now-last_us,"gpu_ms":RenderingServer.viewport_get_measured_render_time_gpu(root.get_viewport_rid()),"spans":spans})
	spans={}
	last_us=now
	phase_frames+=1
	if phase=="menu" and phase_frames==12:
		phase="entry"
		phase_frames=0
		press.call_deferred("进入河原野战")
	elif phase=="entry" and phase_frames==2:
		phase="deployment"
		phase_frames=0
	elif phase=="deployment" and phase_frames==45:
		phase="battle"
		phase_frames=0
		press.call_deferred("开始野战")
	elif phase=="battle" and (main._last_tick>=440 or phase_frames>=1200):
		done=true
		save.call_deferred()
func save() -> void:
	var rd=main._root.field_view("visual")
	var roles:={}
	if rd.ok:
		for a in rd.value.actors: roles[a.role]=roles.get(a.role,0)+1
	var file:=FileAccess.open(OS.get_environment("RECOLLECTION_IDLE_CAPTURE"),FileAccess.WRITE)
	file.store_string(JSON.stringify({"steps":steps,"frames":frames,"visible_roles_at_end":roles,"window_size":str(root.size),"cpu":OS.get_processor_name(),"gpu":RenderingServer.get_video_adapter_name(),"tick":main._last_tick}))
	file.close()
	print("IDLE_CAPTURE frames=",frames.size()," tick=",main._last_tick)
	main.notification(Node.NOTIFICATION_WM_CLOSE_REQUEST)
