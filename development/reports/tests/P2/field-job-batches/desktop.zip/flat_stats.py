"""Aggregate idle.gd captures. Only whole display frames inside ticks 121..440."""
import json, statistics, sys
from collections import Counter, defaultdict
from math import ceil
from pathlib import Path

def summarize(files):
    frame, gpu, step, gameplay_by_frame = [], [], [], []
    counts = Counter()
    spans, stages = defaultdict(float), defaultdict(list)
    exact = 0
    for path in files:
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        assert d["window_size"] == "(960, 600)" and sum(d["visible_roles_at_end"].values()) == 600
        ticks = {row[0]:row for row in d["steps"] if 120 < row[0] <= 440}
        assert len(ticks)==320
        for _, us, work in ticks.values():
            step.append(us / 1000)
            for key, (micros,entities,units) in work.items():
                stages[key].append(micros / 1000)
            exact += work.get("fine",[0,0,0])[2]
        for prev, cur in zip(d["frames"],d["frames"][1:]):
            if cur["phase"] != "battle" or prev["tick"] < 120 or cur["tick"] > 440: continue
            frame.append(cur["us"]/1000)
            gpu.append(cur["gpu_ms"])
            durations = [ticks[t][1]/1000 for t in range(prev["tick"]+1,cur["tick"]+1)]
            gameplay_by_frame.append(sum(durations))
            counts[len(durations)] += 1
            for key, (_, us) in cur["spans"].items(): spans[key] += us/1000
    def metrics(seq):
        seq=sorted(seq)
        return [round(statistics.mean(seq),3), round(seq[ceil(.50*len(seq))-1],3), round(seq[ceil(.95*len(seq))-1],3)]
    return dict(files=[Path(p).name for p in files],step_samples=len(step),frame_samples=len(frame),
        frame_step_histogram=counts,step_ms=metrics(step),frame_ms=metrics(frame),
        fps=1000*len(frame)/sum(frame),sps=1000*sum(n*k for k,n in counts.items())/sum(frame),
        field_step_per_frame_ms=statistics.mean(gameplay_by_frame),
        outside_field_step_ms=statistics.mean(frame)-statistics.mean(gameplay_by_frame),
        gpu_viewport_ms=metrics(gpu),scene_exact_per_step=exact/len(step) if stages else None,
        phases_ms={k:metrics(v) for k,v in stages.items() if k!="fine"},
        frame_spans_mean_ms={k:v/len(frame) for k,v in spans.items()})
if __name__ == "__main__":
    print(json.dumps(summarize(sys.argv[1:]),ensure_ascii=False,indent=2))
