"""Prepare a disposable copy of an imported game project for the idle capture."""
from pathlib import Path
import argparse,sys,shutil,subprocess
here=Path(__file__).resolve().parent
def prepare(label,src,detail=False):
 dest=here/label/'game'
 if dest.exists(): raise FileExistsError(dest)
 shutil.copytree(src,dest)
 if detail:
  for typ in ['movement','think']:
   subprocess.run([sys.executable,str(here/(typ+'_probe.py')),str(dest)],check=True)
 p=dest/'bootstrap/composition_root.gd'
 s=p.read_text(encoding='utf-8')
 h='func field_step() -> Dictionary:'
 assert s.count(h)==1
 p.write_text(s.replace(h,h+'''
	var clock_us := Time.get_ticks_usec()
	var result := _capture_field_step()
	var elapsed := Time.get_ticks_usec()-clock_us
	if result.ok: Engine.get_main_loop().call("record_step",result.value.tick,elapsed)
	return result

func _capture_field_step() -> Dictionary:'''),encoding='utf-8')
if __name__=='__main__':
 cli=argparse.ArgumentParser(description=__doc__)
 cli.add_argument('label')
 cli.add_argument('source_game',type=Path)
 cli.add_argument('--detail',action='store_true')
 args=cli.parse_args()
 prepare(args.label,args.source_game,args.detail)
