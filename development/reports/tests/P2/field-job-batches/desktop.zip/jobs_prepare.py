"""Build disposable projects from a frozen integrated game, retaining identical phase timers."""
import sys, subprocess
from pathlib import Path
from prepare import prepare

d=Path(__file__).resolve().parent
def adjust(path,old,new):
    s=path.read_text(encoding="utf-8")
    assert s.count(old)==1,(path,old)
    path.write_text(s.replace(old,new),encoding="utf-8")
for count in (1,2,4):
    label=f"JobsNew{count}"
    prepare(label,Path(sys.argv[1]))
    name=label+"Phase"
    subprocess.run([sys.executable,str(d/"flat_probe.py"),label,name],check=True)
    copy=d/name/"game"
    ai=copy/"mission/runtime/field_brains.gd"
    mov=copy/"mission/movement/ports/field_movement.gd"
    sense=copy/"mission/ai/perception/field_perception.gd"
    adjust(ai,"const AI_BATCHES := 2",f"const AI_BATCHES := {count}")
    adjust(mov,"const MOVE_BATCHES := 2",f"const MOVE_BATCHES := {count}")
    def add_before(p,key,anchor,entities,work):
        hook=f'\tEngine.get_main_loop().call("record_work","{key}",0,{entities},{work})\n'
        adjust(p,anchor,hook+anchor)
    add_before(ai,"quiet_fsm","\tif batches > 1:\n", "members.size()","batches")
    add_before(sense,"candidate_scan","\tvar results := []\n", "jobs.size()","parts")
    add_before(mov,"ground_predict","\tvar parallel := parts>1", "bodies.size()","maxi(parts,1)")
